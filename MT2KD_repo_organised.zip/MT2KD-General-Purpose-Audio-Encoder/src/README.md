# Source

- `mt2kd/` – the three task modules (ASR / WavLM, AT / SSLAM, SV / ReDimNet2) with data loading, teacher target caches, the Zipformer student, losses and evaluation. Every notebook embeds these files unchanged as its "Part 1", so the notebooks and this folder always match.
- `app/` – the web application (FastAPI backend + front end). See `app/README.md`.
- `tools/chunk_audio.py` – splits long recordings into clips at quiet points (used for the mentor's 10-12 minute recordings).
