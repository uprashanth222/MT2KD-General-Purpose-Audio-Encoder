# Data

No audio is stored in this repository. All three datasets are public; we kept the archives and our preprocessed caches on Google Drive (`MyDrive/MT2KD/datasets/`, `cache16k/`) and the notebooks read them from there.

| Task | Dataset | What we used | Evaluation |
|---|---|---|---|
| ASR | LibriSpeech (openslr.org/12) | 30 h subset of train-clean-100 (nested 2 h / 10 h / 30 h subsets, chosen by speaker) | dev-clean (validation), test-clean (official test) |
| AT | FSD50K (zenodo 4060432) | 15,000 clips of the development set, 200 classes | official validation split (4,170 clips) |
| SV | VoxCeleb1 (robots.ox.ac.uk/~vgg/data/voxceleb) | 30,000 training utterances of 1,171 speakers | VoxCeleb1-O cleaned trial list `veri_test2.txt` (37,720 trials) |

## Preprocessing (same for all tasks)

- Decode, mix to mono, resample to 16 kHz.
- 80-bin log-Mel filter bank, 25 ms window, 10 ms hop (Kaldi-compatible, `torchaudio.compliance.kaldi.fbank`).
- Training crops: FSD50K 10 s, VoxCeleb1 at most 20 s (centre). LibriSpeech utterances are used whole.
- No data augmentation.

## Splits and leakage checks

- Subsets are drawn with a fixed seed, so every run sees the same files.
- LibriSpeech train / dev / test speakers and VoxCeleb1 development / test speakers are disjoint by design of the datasets; we only sample inside the official training parts.
- The LM decoding settings were tuned on one half of the dev-clean speakers and reported on the other half and on test-clean.

The exact subset selection and checks are in `src/mt2kd/*_module.py` (`prepare_manifests`, `load_fsd`, `prepare_dataset`) and are printed at the start of every notebook run.
