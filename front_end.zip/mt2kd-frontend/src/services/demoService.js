/**
 * DEMO MODE ONLY.
 * Everything here is simulated, deterministic sample data used to make the
 * interface explorable before the FastAPI backend exists. None of it is a
 * model prediction, and every result carries `isDemo: true` so the UI can
 * label it. This module never makes network requests.
 */
import { config } from '@/config/appConfig';
import { hashUnit } from '@/utils/id';

const DEMO_MODEL = { name: 'MT2KD (demo simulation)', version: 'demo', isDemo: true };

const sleep = (ms, signal) =>
  new Promise((resolve, reject) => {
    if (signal?.aborted) {
      reject(new DOMException('Cancelled', 'AbortError'));
      return;
    }
    const t = setTimeout(resolve, ms);
    signal?.addEventListener(
      'abort',
      () => {
        clearTimeout(t);
        reject(new DOMException('Cancelled', 'AbortError'));
      },
      { once: true },
    );
  });

export async function simulateStages(stages, { onStage, signal, delayMs = config.demoStageDelayMs } = {}) {
  for (let i = 0; i < stages.length; i += 1) {
    onStage?.(i);
    await sleep(delayMs * (0.7 + Math.random() * 0.6), signal);
  }
  onStage?.(stages.length);
}

/* ---------------- ASR ---------------- */

const SAMPLE_TRANSCRIPTS = [
  'This is a sample transcription shown in demo mode. When the backend is connected, the recognised text from the MT2KD speech recognition head will appear here instead of this placeholder paragraph.',
  'Demo mode sample: the quick review meeting moved to Thursday afternoon, and everyone agreed to share their notes before the end of the week so the final report can be prepared on time.',
  'Sample text for demonstration only. A single shared audio encoder can serve speech recognition, sound event tagging and speaker verification, which keeps the overall system compact and efficient.',
];

function demoAsr(audio, options) {
  const text = SAMPLE_TRANSCRIPTS[Math.floor(hashUnit(audio.name + audio.size) * SAMPLE_TRANSCRIPTS.length)];
  return {
    task: 'asr',
    transcription: text,
    decodingMethod: options?.decodingMethod || 'greedy_search',
    language: 'en',
  };
}

/* ---------------- Audio tagging ---------------- */

const SAMPLE_LABELS = [
  ['Speech', 0.86],
  ['Male speech, man speaking', 0.58],
  ['Narration, monologue', 0.44],
  ['Inside, small room', 0.33],
  ['Female speech, woman speaking', 0.24],
  ['Conversation', 0.19],
  ['Music', 0.14],
  ['Background noise', 0.12],
  ['Breathing', 0.09],
  ['Echo', 0.07],
  ['Typing', 0.06],
  ['Laughter', 0.05],
  ['Telephone', 0.04],
  ['Walk, footsteps', 0.035],
  ['Wind', 0.03],
  ['Vehicle', 0.025],
  ['Bird', 0.02],
  ['Applause', 0.018],
  ['Dog', 0.012],
  ['Silence', 0.01],
];

function demoTagging(audio, options) {
  const seed = audio.name + audio.size;
  const predictions = SAMPLE_LABELS.map(([label, base]) => {
    const jitter = (hashUnit(seed + label) - 0.5) * 0.12;
    return { label, score: Math.max(0.001, Math.min(0.99, base + jitter)) };
  }).sort((a, b) => b.score - a.score);
  return { task: 'tagging', predictions, topK: options?.topK || 10 };
}

/* ---------------- Speaker verification ---------------- */

export const DEMO_REGISTERED_SPEAKERS = [
  {
    id: 'DEMO-SPK-001',
    displayName: 'Demo Profile A',
    description: 'Sample registered profile for Demo Mode. Not a real enrolled identity.',
    enrolledUtterances: 3,
    referenceStatus: 'Sample reference (demo)',
    isDemo: true,
  },
  {
    id: 'DEMO-SPK-002',
    displayName: 'Demo Profile B',
    description: 'Second sample profile for Demo Mode. Not a real enrolled identity.',
    enrolledUtterances: 5,
    referenceStatus: 'Sample reference (demo)',
    isDemo: true,
  },
];

function demoSpeaker({ testAudio, referenceAudio, speaker }) {
  let similarity;
  if (referenceAudio && referenceAudio.name === testAudio.name && referenceAudio.size === testAudio.size) {
    similarity = 0.9 + hashUnit(testAudio.name) * 0.08;
  } else {
    const key = `${testAudio.name}|${testAudio.size}|${referenceAudio ? referenceAudio.name + referenceAudio.size : speaker?.id}`;
    similarity = 0.08 + hashUnit(key) * 0.8;
  }
  const threshold = config.demoSvThreshold;
  return {
    task: 'speaker',
    similarity: Number(similarity.toFixed(4)),
    threshold,
    decision: similarity >= threshold ? 'match' : 'non-match',
    metric: 'cosine',
  };
}

/* ---------------- Entry point ---------------- */

/**
 * Run a simulated analysis.
 * @param {object} job  { task, options, audio, referenceAudio, speaker }
 */
export async function runDemoAnalysis(job, { stages, onStage, signal }) {
  const started = performance.now();
  await simulateStages(stages, { onStage, signal });

  let output;
  if (job.task === 'asr') output = demoAsr(job.audio, job.options);
  else if (job.task === 'tagging') output = demoTagging(job.audio, job.options);
  else if (job.task === 'speaker')
    output = demoSpeaker({ testAudio: job.audio, referenceAudio: job.referenceAudio, speaker: job.speaker });
  else throw new Error(`Unknown task "${job.task}"`);

  return {
    ...output,
    isDemo: true,
    model: DEMO_MODEL,
    processingMs: performance.now() - started,
  };
}
