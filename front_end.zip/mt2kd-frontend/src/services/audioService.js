import { ACCEPTED_FORMATS, config } from '@/config/appConfig';
import { createId } from '@/utils/id';
import { formatBytes } from '@/utils/format';

/* ------------------------------------------------------------------
   Validation
   ------------------------------------------------------------------ */

const EXT_TO_FORMAT = { wav: 'wav', wave: 'wav', mp3: 'mp3', flac: 'flac' };

function extensionOf(name = '') {
  const m = /\.([a-z0-9]+)$/i.exec(name);
  return m ? m[1].toLowerCase() : '';
}

/** Inspect the first bytes so a renamed non-audio file is rejected. */
async function sniffFormat(file) {
  try {
    const buf = new Uint8Array(await file.slice(0, 12).arrayBuffer());
    const ascii = (start, len) => String.fromCharCode(...buf.slice(start, start + len));
    if (ascii(0, 4) === 'RIFF' && ascii(8, 4) === 'WAVE') return 'wav';
    if (ascii(0, 4) === 'fLaC') return 'flac';
    if (ascii(0, 3) === 'ID3') return 'mp3';
    if (buf[0] === 0xff && (buf[1] & 0xe0) === 0xe0) return 'mp3';
    return null;
  } catch {
    return null;
  }
}

/**
 * Validate a user-selected file. Returns { ok, format, error }.
 * Errors are written for end users.
 */
export async function validateAudioFile(file) {
  if (!file) return { ok: false, error: 'No file was selected.' };

  const ext = extensionOf(file.name);
  const extFormat = EXT_TO_FORMAT[ext];
  const mimeFormat = Object.keys(ACCEPTED_FORMATS).find((f) => ACCEPTED_FORMATS[f].includes(file.type));

  if (!extFormat && !mimeFormat) {
    return {
      ok: false,
      error: `"${file.name}" is not a supported audio file. Please upload a WAV, MP3 or FLAC file.`,
    };
  }
  if (file.size === 0) {
    return { ok: false, error: `"${file.name}" is empty (0 bytes).` };
  }
  const maxBytes = config.maxFileSizeMB * 1024 * 1024;
  if (file.size > maxBytes) {
    return {
      ok: false,
      error: `"${file.name}" is ${formatBytes(file.size)}. The maximum allowed size is ${config.maxFileSizeMB} MB.`,
    };
  }

  const sniffed = await sniffFormat(file);
  if (!sniffed) {
    return {
      ok: false,
      error: `"${file.name}" does not look like valid WAV, MP3 or FLAC audio. The file may be corrupted or renamed.`,
    };
  }
  return { ok: true, format: sniffed };
}

/* ------------------------------------------------------------------
   Metadata
   ------------------------------------------------------------------ */

/** Read the duration using the browser's own decoder. */
export function readDuration(url, timeoutMs = 15000) {
  return new Promise((resolve, reject) => {
    const audio = new Audio();
    audio.preload = 'metadata';
    let done = false;
    const finish = (fn, value) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      audio.removeAttribute('src');
      audio.load();
      fn(value);
    };
    const timer = setTimeout(() => finish(reject, new Error('Timed out while reading audio metadata.')), timeoutMs);
    audio.addEventListener('loadedmetadata', () => {
      if (Number.isFinite(audio.duration)) {
        finish(resolve, audio.duration);
        return;
      }
      // Some VBR MP3s report Infinity until seeked.
      audio.currentTime = 1e7;
      audio.addEventListener('durationchange', () => {
        if (Number.isFinite(audio.duration)) finish(resolve, audio.duration);
      });
    });
    audio.addEventListener('error', () =>
      finish(reject, new Error('Your browser could not decode this audio file.')),
    );
    audio.src = url;
  });
}

/**
 * Validate + build an in-memory audio entry with an object URL.
 * Caller owns the URL and must release it with `releaseAudioEntry`.
 */
export async function createAudioEntry(file, { id } = {}) {
  const validation = await validateAudioFile(file);
  if (!validation.ok) throw new Error(validation.error);

  const url = URL.createObjectURL(file);
  let duration;
  try {
    duration = await readDuration(url);
  } catch (err) {
    URL.revokeObjectURL(url);
    throw new Error(`"${file.name}" could not be decoded: ${err.message}`);
  }
  if (!(duration > 0)) {
    URL.revokeObjectURL(url);
    throw new Error(`"${file.name}" contains no playable audio.`);
  }

  return {
    id: id || createId('aud'),
    file,
    url,
    name: file.name,
    size: file.size,
    type: file.type || `audio/${validation.format}`,
    format: validation.format.toUpperCase(),
    duration,
    lastModified: file.lastModified,
    addedAt: new Date().toISOString(),
  };
}

export function releaseAudioEntry(entry) {
  if (entry?.url) URL.revokeObjectURL(entry.url);
}

/** Serializable metadata (no File / object URL). */
export function audioMeta(entry) {
  if (!entry) return null;
  const { id, name, size, type, format, duration, lastModified, addedAt } = entry;
  return { id, name, size, type, format, duration, lastModified, addedAt };
}

/* ------------------------------------------------------------------
   Temporary persistence (IndexedDB)
   A File cannot be stored in localStorage. To survive a page refresh we
   keep a copy of the blob in IndexedDB, scoped to the current tab session.
   If it is missing or too large, the UI asks the user to re-select it.
   ------------------------------------------------------------------ */

const DB_NAME = 'mt2kd-session';
const STORE = 'audio';

function openDb() {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      reject(new Error('IndexedDB unavailable'));
      return;
    }
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => req.result.createObjectStore(STORE);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function withStore(mode, fn) {
  const db = await openDb();
  try {
    return await new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, mode);
      const store = tx.objectStore(STORE);
      const result = fn(store);
      tx.oncomplete = () => resolve(result instanceof IDBRequest ? result.result : result);
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error);
    });
  } finally {
    db.close();
  }
}

export async function persistAudioFile(slot, sessionId, entry) {
  if (!entry?.file) return false;
  if (entry.size > config.persistFileLimitMB * 1024 * 1024) return false;
  try {
    await withStore('readwrite', (s) =>
      s.put({ sessionId, blob: entry.file, meta: audioMeta(entry) }, slot),
    );
    return true;
  } catch {
    return false;
  }
}

export async function restoreAudioFile(slot, sessionId) {
  try {
    const record = await withStore('readonly', (s) => s.get(slot));
    if (!record || record.sessionId !== sessionId || !record.blob) return null;
    const file =
      record.blob instanceof File
        ? record.blob
        : new File([record.blob], record.meta.name, { type: record.meta.type, lastModified: record.meta.lastModified });
    return { ...record.meta, file, url: URL.createObjectURL(file) };
  } catch {
    return null;
  }
}

export async function deletePersistedAudio(slot) {
  try {
    await withStore('readwrite', (s) => s.delete(slot));
  } catch {
    /* ignore */
  }
}

export async function clearPersistedAudio() {
  try {
    await withStore('readwrite', (s) => s.clear());
  } catch {
    /* ignore */
  }
}
