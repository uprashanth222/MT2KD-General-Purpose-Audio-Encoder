/**
 * LIVE MODE ONLY – centralised client for the MT2KD FastAPI backend.
 *
 * The request/response shapes below are the *expected* contract (documented
 * in README.md and the in-app Documentation page). Normalisers accept a few
 * common field-name variants, but they never invent values: if a required
 * field is missing the call fails with a clear error instead of showing a
 * fabricated result.
 */
import axios from 'axios';
import { config } from '@/config/appConfig';

export const http = axios.create({
  baseURL: config.apiBaseUrl,
  timeout: config.apiTimeoutMs,
  headers: { Accept: 'application/json' },
});

export const ENDPOINTS = {
  upload: '/api/audio/upload',
  asr: '/api/asr/process',
  tagging: '/api/tagging/process',
  speaker: '/api/speaker/verify',
  registeredSpeakers: '/api/speaker/registered',
  history: '/api/analysis/history',
  analysis: (id) => `/api/analysis/${encodeURIComponent(id)}`,
  modelsStatus: '/api/models/status',
  modelsInfo: '/api/models/info',
  health: '/api/health',
};

/* ------------------------------------------------------------------
   Errors
   ------------------------------------------------------------------ */

export class ApiError extends Error {
  constructor(message, { status = null, isNetwork = false, detail = null, isCancel = false } = {}) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.isNetwork = isNetwork;
    this.detail = detail;
    this.isCancel = isCancel;
  }
}

function detailToText(detail) {
  if (!detail) return null;
  if (typeof detail === 'string') return detail;
  if (Array.isArray(detail)) {
    return detail
      .map((d) => (typeof d === 'string' ? d : [d?.loc?.slice(1).join('.'), d?.msg].filter(Boolean).join(': ')))
      .join('; ');
  }
  if (typeof detail === 'object') return detail.message || detail.msg || JSON.stringify(detail);
  return String(detail);
}

export function normalizeError(err) {
  if (err instanceof ApiError) return err;
  if (axios.isCancel?.(err) || err?.name === 'CanceledError' || err?.name === 'AbortError') {
    return new ApiError('The request was cancelled.', { isCancel: true });
  }
  if (err?.response) {
    const { status, data } = err.response;
    const text = detailToText(data?.detail) || detailToText(data?.error) || detailToText(data?.message);
    return new ApiError(text || `The backend responded with HTTP ${status}.`, { status, detail: data });
  }
  if (err?.code === 'ECONNABORTED') {
    return new ApiError('The backend took too long to respond (request timed out).', { isNetwork: true });
  }
  if (err?.request || err?.code === 'ERR_NETWORK') {
    return new ApiError(
      `Cannot reach the MT2KD backend at ${config.apiBaseUrl}. Check that the FastAPI server is running and that CORS allows this origin.`,
      { isNetwork: true },
    );
  }
  return new ApiError(err?.message || 'Unexpected error.');
}

async function call(promise) {
  try {
    const res = await promise;
    return res.data;
  } catch (err) {
    throw normalizeError(err);
  }
}

/* ------------------------------------------------------------------
   Simple endpoints
   ------------------------------------------------------------------ */

export const getHealth = (signal) => call(http.get(ENDPOINTS.health, { signal, timeout: 8000 }));
export const getModelsStatus = (signal) => call(http.get(ENDPOINTS.modelsStatus, { signal }));
export const getModelsInfo = (signal) => call(http.get(ENDPOINTS.modelsInfo, { signal }));
export const getAnalysis = (id, signal) => call(http.get(ENDPOINTS.analysis(id), { signal }));

export async function getHistory(signal) {
  const data = await call(http.get(ENDPOINTS.history, { signal }));
  const items = Array.isArray(data) ? data : data?.items || data?.history || data?.results || [];
  return items;
}

export async function getRegisteredSpeakers(signal) {
  const data = await call(http.get(ENDPOINTS.registeredSpeakers, { signal }));
  const items = Array.isArray(data) ? data : data?.speakers || data?.items || [];
  return items.map((s) => ({
    id: s.speaker_id ?? s.id,
    displayName: s.name ?? s.display_name ?? s.speaker_id ?? s.id,
    description: s.description ?? null,
    enrolledUtterances: s.num_utterances ?? s.enrolled_utterances ?? null,
    referenceStatus:
      s.reference_available === false ? 'Reference missing' : s.reference_status ?? (s.reference_available ? 'Reference available' : 'Unknown'),
    referenceAvailable: s.reference_available !== false,
    isDemo: false,
  }));
}

export async function uploadAudio(file, { onProgress, signal } = {}) {
  const form = new FormData();
  form.append('file', file, file.name);
  const data = await call(
    http.post(ENDPOINTS.upload, form, {
      signal,
      onUploadProgress: (e) => {
        if (e.total) onProgress?.(e.loaded / e.total);
      },
    }),
  );
  const audioId = data?.audio_id ?? data?.id ?? data?.file_id;
  if (!audioId) throw new ApiError('Upload succeeded but the backend did not return an audio_id.', { detail: data });
  return { audioId, raw: data };
}

/* ------------------------------------------------------------------
   Result normalisers (no fabrication – missing data → error)
   ------------------------------------------------------------------ */

const pick = (obj, ...keys) => {
  for (const k of keys) if (obj?.[k] !== undefined && obj?.[k] !== null) return obj[k];
  return undefined;
};

function normalizeAsr(r) {
  const text = pick(r, 'transcription', 'text', 'transcript', 'hypothesis');
  if (typeof text !== 'string') throw new ApiError('The backend response did not include a transcription.', { detail: r });
  return {
    task: 'asr',
    transcription: text,
    decodingMethod: pick(r, 'decoding_method', 'decodingMethod') ?? null,
    language: pick(r, 'language') ?? null,
  };
}

function normalizeTagging(r) {
  let preds = pick(r, 'predictions', 'tags', 'labels', 'scores');
  if (preds && !Array.isArray(preds) && typeof preds === 'object') {
    preds = Object.entries(preds).map(([label, score]) => ({ label, score }));
  }
  if (!Array.isArray(preds)) throw new ApiError('The backend response did not include predictions.', { detail: r });
  const predictions = preds
    .map((p) => ({
      label: pick(p, 'label', 'name', 'class', 'display_name'),
      score: Number(pick(p, 'score', 'confidence', 'probability', 'prob')),
    }))
    .filter((p) => p.label !== undefined && Number.isFinite(p.score))
    .sort((a, b) => b.score - a.score);
  return { task: 'tagging', predictions, topK: pick(r, 'top_k', 'topK') ?? null };
}

function normalizeSpeaker(r) {
  const similarity = Number(pick(r, 'similarity', 'score', 'cosine_similarity', 'similarity_score'));
  if (!Number.isFinite(similarity)) throw new ApiError('The backend response did not include a similarity score.', { detail: r });

  let decision = pick(r, 'decision', 'result', 'verdict');
  const boolMatch = pick(r, 'is_match', 'match', 'same_speaker', 'accepted');
  if (typeof decision === 'string') {
    const d = decision.toLowerCase().replace(/[\s_]/g, '-');
    decision = ['match', 'accept', 'accepted', 'same', 'same-speaker', 'true'].includes(d) ? 'match' : 'non-match';
  } else if (typeof boolMatch === 'boolean') {
    decision = boolMatch ? 'match' : 'non-match';
  } else {
    throw new ApiError('The backend response did not include a verification decision.', { detail: r });
  }
  const threshold = Number(pick(r, 'threshold', 'decision_threshold'));
  return {
    task: 'speaker',
    similarity,
    threshold: Number.isFinite(threshold) ? threshold : null,
    decision,
    metric: pick(r, 'metric', 'scoring') ?? null,
  };
}

const NORMALIZERS = { asr: normalizeAsr, tagging: normalizeTagging, speaker: normalizeSpeaker };

const TERMINAL_OK = ['completed', 'complete', 'done', 'success', 'succeeded', 'finished'];
const TERMINAL_FAIL = ['failed', 'error', 'cancelled', 'canceled'];

function statusOf(data) {
  return String(pick(data, 'status', 'state') ?? '').toLowerCase();
}

function processingMsOf(data, result) {
  const ms = pick(result, 'processing_time_ms', 'processing_ms') ?? pick(data, 'processing_time_ms', 'processing_ms');
  if (Number.isFinite(Number(ms))) return Number(ms);
  const s = pick(result, 'processing_time', 'processing_time_s', 'duration_s') ?? pick(data, 'processing_time', 'processing_time_s');
  if (Number.isFinite(Number(s))) return Number(s) * 1000;
  return null;
}

/* ------------------------------------------------------------------
   Job runner
   ------------------------------------------------------------------ */

const wait = (ms, signal) =>
  new Promise((resolve, reject) => {
    const t = setTimeout(resolve, ms);
    signal?.addEventListener(
      'abort',
      () => {
        clearTimeout(t);
        reject(new ApiError('The request was cancelled.', { isCancel: true }));
      },
      { once: true },
    );
  });

async function pollJob(jobId, { signal, onStatus }) {
  const deadline = Date.now() + config.pollTimeoutMs;
  for (;;) {
    if (signal?.aborted) throw new ApiError('The request was cancelled.', { isCancel: true });
    const data = await getAnalysis(jobId, signal);
    const status = statusOf(data);
    onStatus?.({
      phase: 'processing',
      backendStatus: status || 'running',
      stage: pick(data, 'stage', 'current_stage') ?? null,
      stageIndex: Number.isFinite(Number(data?.stage_index)) ? Number(data.stage_index) : null,
      progress: Number.isFinite(Number(data?.progress)) ? Number(data.progress) : null,
    });
    if (TERMINAL_OK.includes(status)) return data;
    if (TERMINAL_FAIL.includes(status)) {
      throw new ApiError(detailToText(data?.error) || detailToText(data?.detail) || 'The backend reported that the analysis failed.', {
        detail: data,
      });
    }
    if (Date.now() > deadline) throw new ApiError('Timed out while waiting for the backend to finish the analysis.');
    await wait(config.pollIntervalMs, signal);
  }
}

/**
 * Run a real analysis against the backend.
 * @param job  { task, options, audio, referenceAudio, speaker }
 * @param ctx  { signal, onStatus, getRemoteId(entry), setRemoteId(entry, id) }
 */
export async function runLiveAnalysis(job, { signal, onStatus, getRemoteId, setRemoteId }) {
  const clientStart = performance.now();

  const ensureUploaded = async (entry, label) => {
    const cached = getRemoteId?.(entry);
    if (cached) return cached;
    if (!entry?.file) throw new ApiError(`${label} is not available in this browser session. Please re-select the file.`);
    onStatus?.({ phase: 'uploading', label: `Uploading ${label.toLowerCase()}`, progress: 0 });
    const { audioId } = await uploadAudio(entry.file, {
      signal,
      onProgress: (p) => onStatus?.({ phase: 'uploading', label: `Uploading ${label.toLowerCase()}`, progress: p }),
    });
    setRemoteId?.(entry, audioId);
    return audioId;
  };

  let endpoint;
  let body;
  if (job.task === 'asr') {
    const audioId = await ensureUploaded(job.audio, 'Audio');
    endpoint = ENDPOINTS.asr;
    body = { audio_id: audioId, decoding_method: job.options?.decodingMethod };
  } else if (job.task === 'tagging') {
    const audioId = await ensureUploaded(job.audio, 'Audio');
    endpoint = ENDPOINTS.tagging;
    body = { audio_id: audioId, top_k: job.options?.topK };
  } else if (job.task === 'speaker') {
    const testId = await ensureUploaded(job.audio, 'Test audio');
    endpoint = ENDPOINTS.speaker;
    if (job.speakerMode === 'pair') {
      const refId = await ensureUploaded(job.referenceAudio, 'Reference audio');
      body = { mode: 'pair', test_audio_id: testId, reference_audio_id: refId };
    } else {
      body = { mode: 'registered', test_audio_id: testId, speaker_id: job.speaker?.id };
    }
  } else {
    throw new ApiError(`Unknown task "${job.task}".`);
  }

  onStatus?.({ phase: 'submitting', label: 'Submitting analysis request' });
  let data = await call(http.post(endpoint, body, { signal }));

  const status = statusOf(data);
  const jobId = pick(data, 'job_id', 'analysis_id', 'id');
  if (TERMINAL_FAIL.includes(status)) {
    throw new ApiError(detailToText(data?.error) || 'The backend reported that the analysis failed.', { detail: data });
  }
  // Synchronous backends answer with the result directly (no status, or a terminal status).
  const isDone = TERMINAL_OK.includes(status) || (!status && !data?.job_id);
  if (!isDone) {
    if (!jobId) throw new ApiError('The backend did not return a result or a job id.', { detail: data });
    onStatus?.({ phase: 'processing', backendStatus: status || 'queued', stage: null, stageIndex: null, progress: null });
    data = await pollJob(jobId, { signal, onStatus });
  }

  const resultPayload = data?.result ?? data;
  const normalized = NORMALIZERS[job.task](resultPayload);
  const backendMs = processingMsOf(data, resultPayload);
  return {
    ...normalized,
    isDemo: false,
    analysisId: pick(data, 'analysis_id', 'job_id', 'id') ?? jobId ?? null,
    model: pick(resultPayload, 'model') ?? pick(data, 'model') ?? null,
    processingMs: backendMs ?? performance.now() - clientStart,
    processingSource: backendMs !== null ? 'backend' : 'client-round-trip',
    raw: data,
  };
}

/* ------------------------------------------------------------------
   Backend history
   ------------------------------------------------------------------ */

const TASK_ALIASES = { asr: 'asr', speech_recognition: 'asr', tagging: 'tagging', audio_tagging: 'tagging', at: 'tagging', speaker: 'speaker', speaker_verification: 'speaker', sv: 'speaker' };

/** Map one backend history item to the shape the History page renders. */
export function normalizeHistoryItem(item) {
  const task = TASK_ALIASES[String(pick(item, 'task', 'task_type') ?? '').toLowerCase()] || null;
  return {
    id: String(pick(item, 'analysis_id', 'id', 'job_id') ?? ''),
    task,
    status: statusOf(item) || 'unknown',
    createdAt: pick(item, 'created_at', 'createdAt', 'timestamp') ?? null,
    audioName: pick(item, 'filename', 'audio_name', 'file_name') ?? pick(item?.audio, 'name', 'filename') ?? '—',
    summary: pick(item, 'summary') ?? null,
  };
}

/**
 * Fetch a completed analysis from the backend and convert it into a local
 * history record so the results dashboards can display it.
 */
export async function loadBackendRecord(id) {
  const data = await getAnalysis(id);
  const status = statusOf(data);
  if (status && !TERMINAL_OK.includes(status)) {
    throw new ApiError(`This analysis is not complete (status: ${status}).`, { detail: data });
  }
  const item = normalizeHistoryItem(data);
  if (!item.task) throw new ApiError('The backend record does not say which task it belongs to.', { detail: data });
  const resultPayload = data?.result ?? data;
  const normalized = NORMALIZERS[item.task](resultPayload);
  const backendMs = processingMsOf(data, resultPayload);
  const audioMetaFrom = (a, fallbackName) =>
    a || fallbackName
      ? {
          id: `remote_${pick(a, 'audio_id', 'id') ?? fallbackName}`,
          name: pick(a, 'name', 'filename') ?? fallbackName,
          size: pick(a, 'size', 'size_bytes') ?? null,
          format: pick(a, 'format') ?? null,
          duration: pick(a, 'duration', 'duration_s') ?? null,
        }
      : null;
  return {
    id: item.id || String(id),
    task: item.task,
    mode: 'live',
    source: 'backend',
    isDemo: false,
    status: 'completed',
    createdAt: item.createdAt || new Date().toISOString(),
    audio: audioMetaFrom(data?.audio || data?.test_audio, item.audioName),
    reference: audioMetaFrom(data?.reference_audio, data?.reference_filename),
    speaker: data?.speaker_id ? { id: data.speaker_id, displayName: data.speaker_name || data.speaker_id, isDemo: false } : null,
    speakerMode: item.task === 'speaker' ? (data?.speaker_id ? 'registered' : 'pair') : null,
    options: data?.options || null,
    result: {
      ...normalized,
      isDemo: false,
      model: pick(resultPayload, 'model') ?? pick(data, 'model') ?? null,
      processingMs: backendMs,
      processingSource: backendMs !== null ? 'backend' : null,
    },
    summary: item.summary,
  };
}
