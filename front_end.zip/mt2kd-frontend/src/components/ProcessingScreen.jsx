import { motion } from 'framer-motion';
import { Check, CircleDot, LoaderCircle, X, CloudUpload, Send, Server } from 'lucide-react';
import AnimatedWave from './AnimatedWave';
import Button from './ui/Button';
import { ModeBadge } from './StatusBadge';
import { cn } from '@/utils/format';

function StageRow({ label, state, accent, index }) {
  return (
    <motion.li
      initial={{ opacity: 0, x: -6 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: index * 0.04 }}
      className={cn(
        'flex items-center gap-3 rounded-xl px-3 py-2.5 transition-colors',
        state === 'active' && 'bg-white/[0.04]',
      )}
      data-state={state}
    >
      <span
        className={cn(
          'flex size-7 shrink-0 items-center justify-center rounded-full border text-xs transition-colors',
          state === 'done' && 'border-transparent text-ink-950',
          state === 'active' && 'border-transparent',
          state === 'pending' && 'border-line-strong text-subtle',
        )}
        style={state === 'done' ? { background: accent } : state === 'active' ? { background: `${accent}26` } : undefined}
      >
        {state === 'done' ? (
          <Check className="size-3.5" strokeWidth={3} />
        ) : state === 'active' ? (
          <LoaderCircle className="size-4 animate-spin" style={{ color: accent }} />
        ) : (
          <span className="font-mono">{index + 1}</span>
        )}
      </span>
      <span className={cn('text-sm', state === 'pending' ? 'text-subtle' : 'text-fg', state === 'active' && 'font-medium')}>
        {label}
      </span>
    </motion.li>
  );
}

function IndeterminateBar({ accent }) {
  return (
    <div className="relative h-1.5 overflow-hidden rounded-full bg-white/[0.06]" role="progressbar" aria-busy="true" aria-label="Processing">
      <span
        className="absolute inset-y-0 left-0 w-2/5 rounded-full"
        style={{ background: `linear-gradient(90deg, transparent, ${accent}, transparent)`, animation: 'var(--animate-indeterminate)' }}
      />
    </div>
  );
}

/* ---------------- Live-mode status (real, from client + backend) ---------------- */

function LiveStatus({ job, task }) {
  const live = job.live || { phase: 'starting' };
  const phases = [
    { key: 'uploading', icon: CloudUpload, label: 'Uploading audio to backend' },
    { key: 'submitting', icon: Send, label: 'Submitting analysis request' },
    { key: 'processing', icon: Server, label: 'Backend processing' },
  ];
  const order = ['starting', 'uploading', 'submitting', 'processing'];
  const currentIdx = order.indexOf(live.phase);

  // Map a backend-reported stage onto the task pipeline, if the backend sends one.
  let stageIdx = null;
  if (live.phase === 'processing') {
    if (Number.isInteger(live.stageIndex)) stageIdx = live.stageIndex;
    else if (live.stage) {
      const i = job.stages.findIndex((s) => s.toLowerCase() === String(live.stage).toLowerCase());
      stageIdx = i >= 0 ? i : null;
    }
  }

  return (
    <div className="space-y-5">
      <ul className="space-y-1">
        {phases.map((p) => {
          const idx = order.indexOf(p.key);
          const state = currentIdx > idx ? 'done' : currentIdx === idx ? 'active' : 'pending';
          let detail = null;
          if (p.key === 'uploading' && state === 'active' && Number.isFinite(live.progress)) {
            detail = `${Math.round(live.progress * 100)}% uploaded`;
          }
          if (p.key === 'processing' && state === 'active') {
            detail = live.stage ? `Backend stage: ${live.stage}` : `Backend status: ${live.backendStatus || 'running'}`;
          }
          return (
            <li key={p.key} className="flex items-center gap-3 rounded-xl px-3 py-2.5" data-state={state}>
              <span
                className={cn(
                  'flex size-7 items-center justify-center rounded-full border',
                  state === 'pending' ? 'border-line-strong text-subtle' : 'border-transparent',
                )}
                style={state === 'done' ? { background: task.accent, color: '#080B16' } : state === 'active' ? { background: `${task.accent}26` } : undefined}
              >
                {state === 'done' ? (
                  <Check className="size-3.5" strokeWidth={3} />
                ) : state === 'active' ? (
                  <LoaderCircle className="size-4 animate-spin" style={{ color: task.accent }} />
                ) : (
                  <p.icon className="size-3.5" />
                )}
              </span>
              <div>
                <div className={cn('text-sm', state === 'pending' ? 'text-subtle' : 'text-fg')}>{p.label}</div>
                {detail && <div className="mt-0.5 font-mono text-xs text-muted">{detail}</div>}
              </div>
            </li>
          );
        })}
      </ul>

      {live.phase === 'uploading' && Number.isFinite(live.progress) ? (
        <div className="h-1.5 overflow-hidden rounded-full bg-white/[0.06]" role="progressbar" aria-valuenow={Math.round(live.progress * 100)} aria-valuemin={0} aria-valuemax={100}>
          <div className="h-full rounded-full transition-[width]" style={{ width: `${live.progress * 100}%`, background: task.accent }} />
        </div>
      ) : (
        <IndeterminateBar accent={task.accent} />
      )}

      <div className="rounded-xl border border-line bg-ink-900/50 p-4">
        <div className="eyebrow mb-3">Expected pipeline</div>
        <ol className="space-y-1.5">
          {job.stages.map((s, i) => (
            <li key={s} className={cn('flex items-center gap-2 text-xs', stageIdx === i ? 'text-fg' : stageIdx !== null && i < stageIdx ? 'text-muted' : 'text-subtle')}>
              {stageIdx === i ? <CircleDot className="size-3.5" style={{ color: task.accent }} /> : <span className="w-3.5 text-center font-mono">{i + 1}</span>}
              {s}
            </li>
          ))}
        </ol>
        <p className="mt-3 text-[11px] leading-relaxed text-subtle">
          {stageIdx === null
            ? 'The backend has not reported a per-stage status, so no step-by-step progress is shown.'
            : 'Stage reported by the backend.'}
        </p>
      </div>
    </div>
  );
}

/* ---------------- Main view ---------------- */

export default function ProcessingScreen({ job, task, onCancel }) {
  const isDemo = job.mode === 'demo';
  const step = Math.min(job.stageIndex, job.stages.length - 1);
  const current = isDemo
    ? job.stages[step]
    : job.live?.phase === 'uploading'
      ? job.live.label || 'Uploading audio'
      : job.live?.phase === 'processing'
        ? job.live.stage || 'Waiting for the backend'
        : 'Preparing request';

  return (
    <div>
      <div className="mb-8 flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
        <div>
          <div className="eyebrow mb-3">Step 4 · Processing</div>
          <h1 className="text-[28px] font-semibold sm:text-[34px]">Analyzing Your Audio</h1>
          <p className="mt-2 text-muted">
            {isDemo ? 'Simulating the processing pipeline with sample data.' : 'Your request is being processed by the MT2KD backend.'}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <ModeBadge mode={job.mode} />
          <Button variant="secondary" icon={X} onClick={onCancel}>
            Cancel
          </Button>
        </div>
      </div>

      <div className="grid gap-5 lg:grid-cols-[1.35fr_1fr]">
        <div className="panel relative overflow-hidden p-6 sm:p-8">
          <div className="grid-bg pointer-events-none absolute inset-0" />
          <div
            className="pointer-events-none absolute left-1/2 top-1/2 size-80 -translate-x-1/2 -translate-y-1/2 rounded-full blur-3xl"
            style={{ background: `rgb(${task.accentRgb} / 0.18)` }}
          />
          <div className="relative">
            <div className="flex items-center gap-3">
              <div className="flex size-11 items-center justify-center rounded-xl" style={{ background: `rgb(${task.accentRgb} / 0.16)` }}>
                <task.icon className="size-5" style={{ color: task.accent }} />
              </div>
              <div className="min-w-0">
                <div className="text-sm text-muted">Selected task</div>
                <div className="font-semibold">{task.title}</div>
              </div>
            </div>

            <div className="my-10 flex justify-center sm:my-14">
              <AnimatedWave bars={48} height={96} color={`linear-gradient(180deg, ${task.accent}, rgb(${task.accentRgb} / 0.35))`} />
            </div>

            <div className="text-center" aria-live="polite">
              <div className="eyebrow">Current stage</div>
              <motion.div key={current} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} className="mt-2 font-display text-xl font-semibold">
                {current}…
              </motion.div>
              {isDemo && (
                <div className="mt-1 font-mono text-xs text-muted">
                  Step {step + 1} of {job.stages.length}
                </div>
              )}
            </div>

            <div className="mt-8 grid gap-2 border-t border-white/[0.06] pt-5 text-sm sm:grid-cols-2">
              <div className="min-w-0">
                <div className="text-[11px] uppercase tracking-wider text-subtle">{job.reference ? 'Test audio' : 'Audio file'}</div>
                <div className="truncate font-mono text-[13px]">{job.audio?.name}</div>
              </div>
              {job.reference && (
                <div className="min-w-0">
                  <div className="text-[11px] uppercase tracking-wider text-subtle">Reference audio</div>
                  <div className="truncate font-mono text-[13px]">{job.reference.name}</div>
                </div>
              )}
              {job.speaker && (
                <div className="min-w-0">
                  <div className="text-[11px] uppercase tracking-wider text-subtle">Registered speaker</div>
                  <div className="truncate font-mono text-[13px]">{job.speaker.id}</div>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="panel p-5 sm:p-6">
          <h2 className="mb-4 text-sm font-semibold text-muted">{isDemo ? 'Pipeline (simulated)' : 'Request status'}</h2>
          {isDemo ? (
            <>
              <ol className="space-y-1">
                {job.stages.map((s, i) => (
                  <StageRow
                    key={s}
                    label={s}
                    index={i}
                    accent={task.accent}
                    state={i < job.stageIndex ? 'done' : i === job.stageIndex ? 'active' : 'pending'}
                  />
                ))}
              </ol>
              <p className="mt-5 rounded-xl border border-amber/30 bg-amber/[0.07] p-3 text-xs leading-relaxed text-amber">
                Demo Mode: these stages are simulated with fixed delays. No model is running.
              </p>
            </>
          ) : (
            <LiveStatus job={job} task={task} />
          )}
        </div>
      </div>
    </div>
  );
}
