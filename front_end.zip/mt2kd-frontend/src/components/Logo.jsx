import { useId } from 'react';
import { Link } from 'react-router-dom';

export function LogoMark({ className = 'size-8' }) {
  // Unique gradient id: several logos may exist while one is display:none.
  const gid = `mt2kd-logo-${useId().replace(/[^a-zA-Z0-9_-]/g, '')}`;
  return (
    <svg viewBox="0 0 32 32" className={className} aria-hidden>
      <defs>
        <linearGradient id={gid} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#8B6DFF" />
          <stop offset="1" stopColor="#00C2FF" />
        </linearGradient>
      </defs>
      <rect width="32" height="32" rx="9" fill="#151D32" stroke="rgb(255 255 255 / 0.08)" />
      <g fill={`url(#${gid})`}>
        <rect x="6.5" y="13" width="3" height="6" rx="1.5" />
        <rect x="11.5" y="8" width="3" height="16" rx="1.5" />
        <rect x="16.5" y="11" width="3" height="10" rx="1.5" />
        <rect x="21.5" y="6.5" width="3" height="19" rx="1.5" />
      </g>
    </svg>
  );
}

export default function Logo({ to = '/', compact = false }) {
  return (
    <Link to={to} className="group inline-flex items-center gap-2.5" aria-label="MT2KD home">
      <LogoMark />
      {!compact && (
        <span className="flex flex-col leading-none">
          <span className="font-display text-[17px] font-semibold tracking-tight">MT2KD</span>
          <span className="mt-1 font-mono text-[9.5px] uppercase tracking-[0.2em] text-muted">Audio Intelligence</span>
        </span>
      )}
    </Link>
  );
}
