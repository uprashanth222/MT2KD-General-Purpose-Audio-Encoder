import { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { ArrowRight, Menu, X } from 'lucide-react';
import Logo from './Logo';
import Button from './ui/Button';
import { ModeBadge } from './StatusBadge';
import { useSession } from '@/context/AudioContext';
import { cn } from '@/utils/format';

const LINKS = [
  { to: '/', label: 'Home', end: true },
  { to: '/docs', label: 'Documentation' },
  { to: '/about', label: 'About Project' },
  { to: '/models', label: 'Model Information' },
];

/** Minimal top navigation used before the user enters the app. */
export default function Navbar() {
  const { mode, audio, hasEnteredApp } = useSession();
  const [open, setOpen] = useState(false);
  const canResume = hasEnteredApp && audio;

  const linkCls = ({ isActive }) =>
    cn('rounded-lg px-3 py-2 text-sm transition-colors', isActive ? 'text-fg' : 'text-muted hover:text-fg');

  return (
    <header className="sticky top-0 z-40 border-b border-white/[0.05] bg-ink-950/70 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-7xl items-center gap-6 px-4 sm:px-6">
        <Logo />
        <nav className="hidden items-center gap-1 md:flex" aria-label="Main">
          {LINKS.map((l) => (
            <NavLink key={l.to} to={l.to} end={l.end} className={linkCls}>
              {l.label}
            </NavLink>
          ))}
        </nav>
        <div className="ml-auto flex items-center gap-3">
          <ModeBadge mode={mode} size="sm" className="hidden sm:inline-flex" />
          {canResume && (
            <Button to="/tasks" size="sm" iconRight={ArrowRight} className="hidden sm:inline-flex">
              Resume session
            </Button>
          )}
          <button
            type="button"
            className="flex size-9 items-center justify-center rounded-lg text-muted hover:bg-white/5 hover:text-fg md:hidden"
            onClick={() => setOpen((o) => !o)}
            aria-label={open ? 'Close menu' : 'Open menu'}
            aria-expanded={open}
          >
            {open ? <X className="size-5" /> : <Menu className="size-5" />}
          </button>
        </div>
      </div>
      <AnimatePresence>
        {open && (
          <motion.nav
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden border-t border-white/[0.05] md:hidden"
            aria-label="Mobile"
          >
            <div className="flex flex-col gap-1 px-4 py-3">
              {LINKS.map((l) => (
                <NavLink key={l.to} to={l.to} end={l.end} className={linkCls} onClick={() => setOpen(false)}>
                  {l.label}
                </NavLink>
              ))}
              <div className="flex items-center gap-2 px-3 pt-2">
                <ModeBadge mode={mode} size="sm" />
                {canResume && (
                  <Button to="/tasks" size="sm" iconRight={ArrowRight} onClick={() => setOpen(false)}>
                    Resume session
                  </Button>
                )}
              </div>
            </div>
          </motion.nav>
        )}
      </AnimatePresence>
    </header>
  );
}
