import { useId, useState } from 'react';
import { motion } from 'framer-motion';
import { CircleAlert, FileAudio, RefreshCw, Trash2, LoaderCircle } from 'lucide-react';
import Waveform from './Waveform';
import AudioUploader from './AudioUploader';
import { ACCEPT_ATTR } from '@/config/appConfig';
import { formatBytes, formatDuration, cn } from '@/utils/format';

function Meta({ label, value }) {
  return (
    <div className="min-w-0">
      <div className="text-[11px] uppercase tracking-wider text-subtle">{label}</div>
      <div className="mt-0.5 truncate font-mono text-[13px] text-fg">{value}</div>
    </div>
  );
}

/**
 * File card: metadata, waveform, playback, Replace / Remove.
 * `onReplace(file)` must resolve to { ok, error }.
 */
export default function AudioPlayer({
  entry,
  role,
  accent = '#7C5CFC',
  onReplace,
  onRemove,
  replaceNote,
  waveHeight = 72,
  className,
}) {
  const inputId = useId();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  if (!entry) return null;

  const pick = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file || !onReplace) return;
    setBusy(true);
    setError(null);
    const res = await onReplace(file);
    setBusy(false);
    if (!res?.ok) setError(res?.error || 'This file could not be used.');
  };

  return (
    <motion.div layout initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className={cn('panel p-4 sm:p-5', className)}>
      <div className="flex items-start gap-3.5">
        <div
          className="flex size-11 shrink-0 items-center justify-center rounded-xl border border-white/10"
          style={{ background: `linear-gradient(140deg, ${accent}33, transparent)` }}
        >
          <FileAudio className="size-5" style={{ color: accent }} />
        </div>
        <div className="min-w-0 flex-1">
          {role && <div className="eyebrow mb-1">{role}</div>}
          <div className="truncate font-medium text-fg" title={entry.name}>
            {entry.name}
          </div>
        </div>
        {(onReplace || onRemove) && (
          <div className="flex shrink-0 items-center gap-1">
            {onReplace && (
              <label
                htmlFor={inputId}
                className={cn(
                  'inline-flex h-8 cursor-pointer items-center gap-1.5 rounded-lg border border-line-strong px-2.5 text-xs font-medium text-fg transition hover:bg-white/[0.06]',
                  busy && 'pointer-events-none opacity-50',
                )}
              >
                {busy ? <LoaderCircle className="size-3.5 animate-spin" /> : <RefreshCw className="size-3.5" />}
                <span className="hidden sm:inline">{entry.missingFile ? 'Re-select' : 'Replace'}</span>
                <input id={inputId} type="file" accept={ACCEPT_ATTR} className="sr-only" onChange={pick} />
              </label>
            )}
            {onRemove && (
              <button
                type="button"
                onClick={onRemove}
                aria-label={`Remove ${entry.name}`}
                className="inline-flex h-8 items-center gap-1.5 rounded-lg px-2.5 text-xs font-medium text-muted transition hover:bg-danger/10 hover:text-danger"
              >
                <Trash2 className="size-3.5" />
                <span className="hidden sm:inline">Remove</span>
              </button>
            )}
          </div>
        )}
      </div>

      <div className="mt-4 grid grid-cols-2 gap-x-4 gap-y-3 sm:grid-cols-4">
        <Meta label="Format" value={entry.format || '—'} />
        <Meta label="Size" value={formatBytes(entry.size)} />
        <Meta label="Duration" value={formatDuration(entry.duration)} />
        <Meta label="Type" value={entry.type || '—'} />
      </div>

      <div className="mt-4">
        {entry.missingFile ? (
          <div className="flex items-start gap-2.5 rounded-xl border border-warning/30 bg-warning/10 px-4 py-3 text-sm text-amber-100">
            <CircleAlert className="mt-0.5 size-4 shrink-0 text-warning" />
            <span>
              The page was refreshed and this file could not be restored from temporary browser storage. Its details are kept, but
              please re-select the same file to play or analyse it.
            </span>
          </div>
        ) : (
          <Waveform url={entry.url} accent={accent} height={waveHeight} label={entry.name} />
        )}
      </div>

      {replaceNote && <p className="mt-3 text-xs text-subtle">{replaceNote}</p>}
      {error && (
        <div role="alert" className="mt-3 flex items-start gap-2 rounded-lg border border-danger/30 bg-danger/10 px-3 py-2 text-sm text-red-200">
          <CircleAlert className="mt-0.5 size-4 shrink-0 text-danger" /> {error}
        </div>
      )}
    </motion.div>
  );
}

/** Shows an uploader when empty, the player card once a file is present. */
export function AudioSlot({ entry, onFile, onRemove, role, accent, title, hint, compact, inputId, replaceNote }) {
  if (entry) {
    return <AudioPlayer entry={entry} role={role} accent={accent} onReplace={onFile} onRemove={onRemove} replaceNote={replaceNote} />;
  }
  return <AudioUploader onFile={onFile} title={title} hint={hint} compact={compact} accent={accent} inputId={inputId} />;
}
