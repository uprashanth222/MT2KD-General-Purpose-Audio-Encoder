import { useNavigate } from 'react-router-dom';
import { ArrowRight, ShieldCheck, Server } from 'lucide-react';
import { AudioSlot } from './AudioPlayer';
import Button from './ui/Button';
import { useSession } from '@/context/AudioContext';

/** Upload once → reuse for every task. Shared by Landing and Upload pages. */
export default function UploadPanel({ continueTo = '/tasks' }) {
  const { audio, setAudio, removeAudio, enterApp, isDemo, restoring } = useSession();
  const navigate = useNavigate();
  const canContinue = !!audio && !audio.missingFile && !restoring;

  return (
    <div className="space-y-4">
      <AudioSlot
        entry={audio}
        onFile={setAudio}
        onRemove={removeAudio}
        role="Session audio"
        inputId="primary-audio-input"
        replaceNote={audio ? 'This file is reused for every task in this session — no need to upload it again.' : undefined}
      />
      <div className="flex flex-col-reverse items-stretch gap-3 sm:flex-row sm:items-center sm:justify-between">
        <p className="flex items-center gap-2 text-xs text-subtle">
          {isDemo ? (
            <>
              <ShieldCheck className="size-4 shrink-0 text-success" /> Demo Mode: your audio stays in this browser and is never uploaded.
            </>
          ) : (
            <>
              <Server className="size-4 shrink-0 text-accent" /> Live Mode: audio is sent to the MT2KD backend when you start an analysis.
            </>
          )}
        </p>
        <Button
          size="lg"
          iconRight={ArrowRight}
          disabled={!canContinue}
          onClick={() => {
            enterApp();
            navigate(continueTo);
          }}
        >
          Continue
        </Button>
      </div>
    </div>
  );
}
