/**
 * MT2KD architecture as inline SVG (Stage 1 view: student + task modules + frozen teachers).
 * Architecture facts follow the base paper; no performance numbers are shown.
 */
const C = {
  card: '#151D32',
  card2: '#101729',
  line: '#2F3B5C',
  fg: '#F8FAFC',
  muted: '#94A3B8',
  subtle: '#64748B',
  asr: '#7C5CFC',
  at: '#00C2FF',
  sv: '#F5B544',
};

function Box({ x, y, w, h, title, sub, stroke = C.line, fill = C.card, accent }) {
  return (
    <g>
      <rect x={x} y={y} width={w} height={h} rx={12} fill={fill} stroke={stroke} strokeWidth={1.2} />
      {accent && <rect x={x} y={y + 12} width={3} height={h - 24} rx={1.5} fill={accent} />}
      <text x={x + w / 2} y={y + h / 2 - (sub ? 6 : -4)} textAnchor="middle" fill={C.fg} fontSize="13" fontWeight="600" fontFamily="Sora, Inter, sans-serif">
        {title}
      </text>
      {sub && (
        <text x={x + w / 2} y={y + h / 2 + 13} textAnchor="middle" fill={C.muted} fontSize="10.5" fontFamily="JetBrains Mono, monospace">
          {sub}
        </text>
      )}
    </g>
  );
}

function Arrow({ d, color = C.muted, dashed = false, id }) {
  return <path d={d} fill="none" stroke={color} strokeWidth={1.5} strokeDasharray={dashed ? '5 5' : undefined} markerEnd={`url(#${id})`} />;
}

function Label({ x, y, children, color = C.muted, anchor = 'middle' }) {
  return (
    <text x={x} y={y} textAnchor={anchor} fill={color} fontSize="10.5" fontFamily="JetBrains Mono, monospace">
      {children}
    </text>
  );
}

export default function ArchitectureDiagram() {
  const stacks = [0, 1, 2, 3, 4, 5];
  const blockY = (i) => 392 - i * 58;

  return (
    <div className="overflow-x-auto">
      <svg viewBox="0 0 980 500" className="min-w-[760px]" role="img" aria-labelledby="arch-title arch-desc">
        <title id="arch-title">MT2KD architecture</title>
        <desc id="arch-desc">
          Audio is converted to 80-dimensional filterbank features and encoded by a shared Zipformer-M student. The ASR and audio tagging
          heads read the final encoder stack, the speaker module reads the third stack. Frozen teachers Whisper-large-v3, BEATs and
          ECAPA-TDNN supervise each head through knowledge distillation losses.
        </desc>
        <defs>
          {['m-muted', 'm-asr', 'm-at', 'm-sv'].map((id, i) => (
            <marker key={id} id={id} viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
              <path d="M0,0 L10,5 L0,10 z" fill={[C.muted, C.asr, C.at, C.sv][i]} />
            </marker>
          ))}
          <linearGradient id="enc-grad" x1="0" y1="1" x2="0" y2="0">
            <stop offset="0" stopColor="#7C5CFC" stopOpacity="0.14" />
            <stop offset="1" stopColor="#00C2FF" stopOpacity="0.1" />
          </linearGradient>
        </defs>

        {/* Input → features */}
        <Box x={16} y={385} w={128} h={64} title="Audio input" sub="WAV · MP3 · FLAC" />
        <Arrow id="m-muted" d="M144 417 L172 417" />
        <Box x={176} y={385} w={128} h={64} title="Filterbank" sub="80-D · 10 ms" />
        <Arrow id="m-muted" d="M304 417 L336 417" />

        {/* Shared encoder */}
        <rect x={340} y={44} width={200} height={424} rx={18} fill="url(#enc-grad)" stroke="#7C5CFC" strokeOpacity="0.5" strokeWidth={1.2} />
        <Label x={440} y={36} color={C.fg}>
          Zipformer-M · shared student encoder
        </Label>
        {stacks.map((i) => (
          <g key={i}>
            <rect x={362} y={blockY(i)} width={156} height={44} rx={10} fill={C.card} stroke={i === 2 || i === 5 ? '#4B5A82' : C.line} />
            <text x={440} y={blockY(i) + 27} textAnchor="middle" fill={C.fg} fontSize="12" fontFamily="Inter, sans-serif">
              Encoder stack {i + 1}
            </text>
            {i < 5 && <path d={`M440 ${blockY(i)} L440 ${blockY(i + 1) + 44}`} stroke={C.subtle} strokeWidth={1.2} />}
          </g>
        ))}
        <Label x={440} y={462}>
          512-D · 25 Hz
        </Label>

        {/* Heads */}
        <Arrow id="m-asr" d={`M518 ${blockY(5) + 16} C 560 ${blockY(5) + 16}, 560 92, 596 92`} color={C.asr} />
        <Arrow id="m-at" d={`M518 ${blockY(5) + 30} C 566 ${blockY(5) + 30}, 560 192, 596 192`} color={C.at} />
        <Arrow id="m-sv" d={`M518 ${blockY(2) + 22} C 560 ${blockY(2) + 22}, 560 300, 596 300`} color={C.sv} />

        <Box x={600} y={62} w={160} h={62} title="ASR head" sub="transducer → text" accent={C.asr} />
        <Box x={600} y={162} w={160} h={62} title="Audio tagging head" sub="linear + sigmoid" accent={C.at} />
        <Box x={600} y={270} w={160} h={62} title="Speaker module" sub="attn. pooling → 192-D" accent={C.sv} />

        {/* Teachers (frozen) */}
        {[
          { y: 62, name: 'Whisper-large-v3', sub: 'frozen · ASR', loss: 'L1', color: C.asr, m: 'm-asr' },
          { y: 162, name: 'BEATs', sub: 'frozen · AT', loss: 'BCE', color: C.at, m: 'm-at' },
          { y: 270, name: 'ECAPA-TDNN', sub: 'frozen · SV', loss: '1 − cos', color: C.sv, m: 'm-sv' },
        ].map((t) => (
          <g key={t.name}>
            <Arrow id={t.m} d={`M844 ${t.y + 31} L764 ${t.y + 31}`} color={t.color} dashed />
            <Label x={804} y={t.y + 23} color={t.color}>
              {t.loss}
            </Label>
            <Box x={846} y={t.y} w={124} h={62} title={t.name} sub={t.sub} fill={C.card2} />
          </g>
        ))}

        {/* Legend */}
        <g transform="translate(600 384)">
          <rect width="370" height="84" rx="12" fill={C.card2} stroke={C.line} />
          <path d="M18 26 L58 26" stroke={C.muted} strokeWidth={1.5} />
          <Label x={70} y={30} anchor="start">
            forward pass (student)
          </Label>
          <path d="M18 54 L58 54" stroke={C.muted} strokeWidth={1.5} strokeDasharray="5 5" />
          <Label x={70} y={58} anchor="start">
            KD supervision from frozen teachers (Stage 1)
          </Label>
        </g>
      </svg>
    </div>
  );
}
