import { FileAudio, Info } from 'lucide-react';
import AudioPlayer from './AudioPlayer';
import { cn, formatBytes, formatDateTime, formatDuration, formatMs } from '@/utils/format';

/** Consistent card shell for results dashboards. */
export default function ResultCard({ title, icon: Icon, actions, children, className, bodyClassName, accent }) {
  return (
    <section className={cn('panel overflow-hidden', className)}>
      {(title || actions) && (
        <div className="flex flex-wrap items-center gap-3 border-b border-white/[0.05] px-5 py-4 sm:px-6">
          {Icon && <Icon className="size-4" style={{ color: accent || 'var(--color-muted)' }} />}
          {title && <h2 className="text-sm font-semibold">{title}</h2>}
          {actions && <div className="ml-auto flex flex-wrap items-center gap-1.5">{actions}</div>}
        </div>
      )}
      <div className={cn('p-5 sm:p-6', bodyClassName)}>{children}</div>
    </section>
  );
}

export function DetailList({ items }) {
  return (
    <dl className="divide-y divide-white/[0.05]">
      {items.map(({ label, value, mono = true }) => (
        <div key={label} className="flex items-start justify-between gap-4 py-2.5 first:pt-0 last:pb-0">
          <dt className="shrink-0 text-sm text-muted">{label}</dt>
          <dd className={cn('min-w-0 break-words text-right text-sm text-fg', mono && 'font-mono text-[13px]')}>{value}</dd>
        </div>
      ))}
    </dl>
  );
}

/** Audio card for a result: playable if the file is still in the session, otherwise metadata only. */
export function ResultAudio({ meta, entry, role, accent }) {
  if (entry) return <AudioPlayer entry={entry} role={role} accent={accent} waveHeight={60} />;
  if (!meta) return null;
  return (
    <div className="panel p-5">
      <div className="eyebrow mb-1">{role}</div>
      <div className="flex items-center gap-2 font-medium">
        <FileAudio className="size-4 text-muted" />
        <span className="truncate">{meta.name}</span>
      </div>
      <div className="mt-2 font-mono text-xs text-muted">
        {meta.format} · {formatDuration(meta.duration)} · {formatBytes(meta.size)}
      </div>
      <p className="mt-3 text-xs text-subtle">This file is no longer loaded in the current session, so playback is unavailable.</p>
    </div>
  );
}

export function AnalysisDetails({ record, task }) {
  const r = record.result || {};
  const modelName = r.model?.name || r.model?.id || (typeof r.model === 'string' ? r.model : null);
  return (
    <ResultCard title="Analysis details" icon={Info}>
      <DetailList
        items={[
          { label: 'Analysis ID', value: record.id },
          { label: 'Task', value: task.title, mono: false },
          { label: 'Completed', value: formatDateTime(record.createdAt), mono: false },
          {
            label: 'Processing time',
            value: `${formatMs(r.processingMs)}${r.processingSource === 'client-round-trip' ? ' (round-trip)' : record.isDemo ? ' (simulated)' : ''}`,
          },
          { label: 'Model', value: modelName || 'Not reported by backend', mono: false },
          ...(r.model?.version ? [{ label: 'Model version', value: r.model.version }] : []),
          { label: 'Mode', value: record.isDemo ? 'Demo (simulated)' : 'Live backend', mono: false },
        ]}
      />
    </ResultCard>
  );
}
