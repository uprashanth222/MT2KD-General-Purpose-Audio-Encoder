import { Link } from 'react-router-dom';
import { LoaderCircle } from 'lucide-react';
import { cn } from '@/utils/format';

const VARIANTS = {
  primary:
    'text-white bg-[linear-gradient(135deg,#8B6DFF_0%,#7C5CFC_45%,#5B4BE0_100%)] shadow-[0_8px_28px_-8px_rgb(124_92_252/0.75)] hover:shadow-[0_10px_36px_-6px_rgb(124_92_252/0.9)] hover:brightness-110 border border-white/10',
  secondary: 'text-fg bg-white/[0.04] border border-line-strong hover:bg-white/[0.08] hover:border-white/20',
  ghost: 'text-muted hover:text-fg hover:bg-white/[0.05] border border-transparent',
  danger: 'text-danger bg-danger/10 border border-danger/30 hover:bg-danger/20',
  accent:
    'text-ink-950 bg-accent hover:brightness-110 shadow-[0_8px_28px_-10px_rgb(0_194_255/0.8)] border border-white/10',
};

const SIZES = {
  sm: 'h-8 px-3 text-xs gap-1.5 rounded-lg',
  md: 'h-10 px-4 text-sm gap-2 rounded-xl',
  lg: 'h-12 px-6 text-[15px] gap-2.5 rounded-xl',
};

export default function Button({
  variant = 'primary',
  size = 'md',
  to,
  href,
  loading = false,
  disabled = false,
  icon: Icon,
  iconRight: IconRight,
  className,
  children,
  ...rest
}) {
  const classes = cn(
    'inline-flex select-none items-center justify-center whitespace-nowrap font-medium transition-all duration-200',
    'disabled:pointer-events-none disabled:opacity-40 disabled:shadow-none aria-disabled:pointer-events-none aria-disabled:opacity-40',
    VARIANTS[variant],
    SIZES[size],
    className,
  );
  const content = (
    <>
      {loading ? <LoaderCircle className="size-4 animate-spin" aria-hidden /> : Icon ? <Icon className="size-4 shrink-0" aria-hidden /> : null}
      {children}
      {IconRight && !loading ? <IconRight className="size-4 shrink-0" aria-hidden /> : null}
    </>
  );

  if (to) {
    return (
      <Link to={to} className={classes} aria-disabled={disabled || undefined} tabIndex={disabled ? -1 : undefined} {...rest}>
        {content}
      </Link>
    );
  }
  if (href) {
    return (
      <a href={href} className={classes} {...rest}>
        {content}
      </a>
    );
  }
  return (
    <button type="button" className={classes} disabled={disabled || loading} {...rest}>
      {content}
    </button>
  );
}
