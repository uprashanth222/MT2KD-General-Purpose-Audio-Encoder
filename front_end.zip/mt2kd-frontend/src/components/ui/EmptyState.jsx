export default function EmptyState({ icon: Icon, title, body, action }) {
  return (
    <div className="panel flex flex-col items-center px-6 py-14 text-center">
      {Icon && (
        <div className="flex size-14 items-center justify-center rounded-2xl border border-white/10 bg-white/[0.04]">
          <Icon className="size-6 text-muted" />
        </div>
      )}
      <h2 className="mt-5 text-lg font-semibold">{title}</h2>
      {body && <p className="mt-2 max-w-md text-sm leading-relaxed text-muted">{body}</p>}
      {action && <div className="mt-6 flex flex-wrap justify-center gap-2">{action}</div>}
    </div>
  );
}

export function LoadingBlock({ label = 'Loading…' }) {
  return (
    <div className="flex items-center justify-center gap-3 py-20 text-sm text-muted">
      <span className="size-4 animate-spin rounded-full border-2 border-white/15 border-t-accent" />
      {label}
    </div>
  );
}
