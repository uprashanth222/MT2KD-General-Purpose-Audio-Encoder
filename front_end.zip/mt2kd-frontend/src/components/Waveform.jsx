import { useEffect, useRef, useState } from 'react';
import WaveSurfer from 'wavesurfer.js';
import { Pause, Play, Volume2, VolumeX, TriangleAlert } from 'lucide-react';
import { formatDuration, cn } from '@/utils/format';

/**
 * Interactive waveform + transport controls, backed by WaveSurfer.js.
 * Renders the real decoded audio from a local object URL.
 */
export default function Waveform({ url, accent = '#7C5CFC', height = 72, label = 'audio', className }) {
  const containerRef = useRef(null);
  const wsRef = useRef(null);
  const [ready, setReady] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [muted, setMuted] = useState(false);
  const [time, setTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!url || !containerRef.current) return undefined;
    setReady(false);
    setPlaying(false);
    setTime(0);
    setError(null);

    const ws = WaveSurfer.create({
      container: containerRef.current,
      url,
      height,
      waveColor: 'rgba(148, 163, 184, 0.32)',
      progressColor: accent,
      cursorColor: '#F8FAFC',
      cursorWidth: 1,
      barWidth: 2,
      barGap: 2,
      barRadius: 2,
      normalize: true,
      dragToSeek: true,
    });
    wsRef.current = ws;

    const unsubs = [
      ws.on('ready', (d) => {
        setDuration(d || ws.getDuration());
        setReady(true);
      }),
      ws.on('timeupdate', (t) => setTime(t)),
      ws.on('play', () => setPlaying(true)),
      ws.on('pause', () => setPlaying(false)),
      ws.on('finish', () => setPlaying(false)),
      ws.on('error', (e) => setError(e?.message || 'This audio could not be rendered.')),
    ];

    return () => {
      unsubs.forEach((u) => typeof u === 'function' && u());
      ws.destroy();
      wsRef.current = null;
    };
  }, [url, accent, height]);

  const toggle = () => wsRef.current?.playPause();
  const toggleMute = () => {
    const next = !muted;
    wsRef.current?.setMuted(next);
    setMuted(next);
  };

  return (
    <div className={cn('rounded-xl border border-line bg-ink-900/70 p-3 sm:p-4', className)}>
      <div className="relative">
        <div ref={containerRef} className={cn('w-full transition-opacity duration-300', ready ? 'opacity-100' : 'opacity-0')} />
        {!ready && !error && (
          <div className="absolute inset-0 flex items-center gap-[3px]" aria-hidden>
            {Array.from({ length: 48 }, (_, i) => (
              <span key={i} className="skeleton flex-1 rounded-full" style={{ height: `${25 + ((i * 37) % 60)}%` }} />
            ))}
          </div>
        )}
        {error && (
          <div className="flex items-center gap-2 text-sm text-danger" style={{ minHeight: height }}>
            <TriangleAlert className="size-4 shrink-0" /> {error}
          </div>
        )}
      </div>

      <div className="mt-3 flex items-center gap-3">
        <button
          type="button"
          onClick={toggle}
          disabled={!ready}
          aria-label={playing ? `Pause ${label}` : `Play ${label}`}
          className="flex size-10 shrink-0 items-center justify-center rounded-full text-white transition hover:brightness-110 disabled:opacity-40"
          style={{ background: accent, boxShadow: `0 6px 20px -6px ${accent}` }}
        >
          {playing ? <Pause className="size-4" fill="currentColor" /> : <Play className="ml-0.5 size-4" fill="currentColor" />}
        </button>
        <div className="font-mono text-xs tabular-nums text-muted">
          <span className="text-fg">{formatDuration(time)}</span> / {formatDuration(duration)}
        </div>
        <button
          type="button"
          onClick={toggleMute}
          disabled={!ready}
          aria-label={muted ? 'Unmute' : 'Mute'}
          className="ml-auto flex size-8 items-center justify-center rounded-lg text-muted transition hover:bg-white/5 hover:text-fg disabled:opacity-40"
        >
          {muted ? <VolumeX className="size-4" /> : <Volume2 className="size-4" />}
        </button>
      </div>
    </div>
  );
}
