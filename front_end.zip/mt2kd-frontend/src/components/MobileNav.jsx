import { NavLink } from 'react-router-dom';
import { BookOpen } from 'lucide-react';
import { NAV_ITEMS, BackendStatus } from './Sidebar';
import Logo from './Logo';
import { ModeBadge } from './StatusBadge';
import { useSession } from '@/context/AudioContext';
import { cn } from '@/utils/format';

/** Compact top bar for small screens. */
export function MobileTopBar() {
  const { mode } = useSession();
  return (
    <header className="sticky top-0 z-30 flex h-14 items-center gap-3 border-b border-white/[0.05] bg-ink-950/80 px-4 backdrop-blur-xl lg:hidden">
      <Logo />
      <div className="ml-auto flex items-center gap-3">
        <BackendStatus className="hidden sm:flex" />
        <ModeBadge mode={mode} size="sm" />
        <NavLink to="/docs" aria-label="Documentation" className="flex size-8 items-center justify-center rounded-lg text-muted hover:text-fg">
          <BookOpen className="size-4" />
        </NavLink>
      </div>
    </header>
  );
}

/** Fixed bottom navigation for small screens. */
export default function MobileNav() {
  return (
    <nav
      className="fixed inset-x-0 bottom-0 z-30 border-t border-white/[0.06] bg-ink-900/90 pb-[env(safe-area-inset-bottom)] backdrop-blur-xl lg:hidden"
      aria-label="Application"
    >
      <div className="mx-auto grid max-w-lg grid-cols-6">
        {NAV_ITEMS.map(({ to, short, icon: Icon, end }) => (
          <NavLink
            key={to}
            to={to}
            end={end}
            className={({ isActive }) =>
              cn(
                'flex flex-col items-center gap-1 py-2.5 text-[10px] font-medium transition-colors',
                isActive ? 'text-fg' : 'text-subtle hover:text-muted',
              )
            }
          >
            {({ isActive }) => (
              <>
                <span
                  className={cn(
                    'flex h-7 w-11 items-center justify-center rounded-full transition-colors',
                    isActive && 'bg-primary/20 text-primary-soft',
                  )}
                >
                  <Icon className="size-[18px]" />
                </span>
                {short}
              </>
            )}
          </NavLink>
        ))}
      </div>
    </nav>
  );
}
