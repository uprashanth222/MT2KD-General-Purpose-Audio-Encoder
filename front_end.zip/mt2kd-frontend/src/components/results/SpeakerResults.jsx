import { motion } from 'framer-motion';
import { CircleCheck, CircleX, Download, Gauge, RotateCcw, UserRound, FlaskConical, Info } from 'lucide-react';
import Button from '../ui/Button';
import ResultCard, { AnalysisDetails, ResultAudio } from '../ResultCard';
import { exportPayload } from './AsrResults';
import { baseName, downloadJSON } from '@/utils/download';
import { cn } from '@/utils/format';

/** Linear similarity scale with threshold marker. Cosine similarity spans −1…1; we show 0…1 unless negative. */
function SimilarityScale({ similarity, threshold, isMatch }) {
  const min = Math.min(0, similarity, threshold ?? 0) < 0 ? -1 : 0;
  const pos = (v) => `${((Math.max(min, Math.min(1, v)) - min) / (1 - min)) * 100}%`;
  const color = isMatch ? '#22C55E' : '#EF4444';
  return (
    <div className="pt-8 pb-2">
      <div className="relative h-3 rounded-full bg-white/[0.06]">
        {threshold !== null && (
          <div
            className="absolute inset-y-0 right-0 rounded-r-full bg-success/[0.12]"
            style={{ left: pos(threshold) }}
            aria-hidden
          />
        )}
        <motion.div
          className="absolute inset-y-0 left-0 rounded-full"
          initial={{ width: 0 }}
          animate={{ width: pos(similarity) }}
          transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
          style={{ width: pos(similarity), background: `linear-gradient(90deg, rgb(148 163 184 / 0.3), ${color})` }}
        />
        {threshold !== null && (
          <div className="absolute -top-7 bottom-[-6px] w-px bg-fg/70" style={{ left: pos(threshold) }}>
            <span className="absolute -top-0.5 left-1/2 -translate-x-1/2 whitespace-nowrap rounded bg-ink-900 px-1.5 font-mono text-[10px] text-fg">
              threshold {threshold.toFixed(2)}
            </span>
          </div>
        )}
        <motion.div
          className="absolute top-1/2 size-5 -translate-x-1/2 -translate-y-1/2 rounded-full border-[3px] border-ink-950"
          initial={{ left: pos(min) }}
          animate={{ left: pos(similarity) }}
          transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
          style={{ left: pos(similarity), background: color, boxShadow: `0 0 16px ${color}` }}
        />
      </div>
      <div className="mt-3 flex justify-between font-mono text-[10px] text-subtle">
        <span>{min.toFixed(1)}</span>
        <span>{min < 0 ? '0.0' : '0.5'}</span>
        <span>1.0</span>
      </div>
    </div>
  );
}

function RegisteredSpeakerCard({ speaker }) {
  if (!speaker) return null;
  return (
    <div className="panel p-5">
      <div className="eyebrow mb-3">Reference · registered speaker</div>
      <div className="flex items-center gap-3">
        <div className="flex size-11 items-center justify-center rounded-full bg-white/[0.06]">
          <UserRound className="size-5 text-muted" />
        </div>
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2 font-medium">
            {speaker.displayName}
            {speaker.isDemo && (
              <span className="inline-flex items-center gap-1 rounded-md border border-amber/40 bg-amber/10 px-1.5 py-0.5 font-mono text-[10px] uppercase tracking-wider text-amber">
                <FlaskConical className="size-3" /> Demo sample
              </span>
            )}
          </div>
          <div className="font-mono text-xs text-muted">{speaker.id}</div>
        </div>
      </div>
      <div className="mt-3 text-xs text-muted">Reference: {speaker.referenceStatus || '—'}</div>
    </div>
  );
}

export default function SpeakerResults({ record, task, primaryEntry, referenceEntry }) {
  const { similarity, threshold, decision, metric } = record.result;
  const isMatch = decision === 'match';
  const name = baseName(record.audio?.name);
  const color = isMatch ? 'var(--color-success)' : 'var(--color-danger)';

  return (
    <div className="space-y-5">
      <div className="grid gap-5 lg:grid-cols-[1.6fr_1fr]">
        {/* Verdict */}
        <motion.section
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          className={cn('panel relative overflow-hidden p-6 sm:p-8', isMatch ? 'border-success/40' : 'border-danger/40')}
          data-testid="sv-verdict"
          data-decision={decision}
        >
          <div
            className="pointer-events-none absolute -left-20 -top-24 size-72 rounded-full blur-3xl"
            style={{ background: isMatch ? 'rgb(34 197 94 / 0.16)' : 'rgb(239 68 68 / 0.16)' }}
          />
          <div className="relative flex flex-col gap-6 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-4">
              <motion.div
                initial={{ scale: 0.4, rotate: -20 }}
                animate={{ scale: 1, rotate: 0 }}
                transition={{ type: 'spring', stiffness: 260, damping: 16, delay: 0.1 }}
                className="flex size-16 items-center justify-center rounded-2xl"
                style={{ background: isMatch ? 'rgb(34 197 94 / 0.15)' : 'rgb(239 68 68 / 0.15)' }}
              >
                {isMatch ? <CircleCheck className="size-8 text-success" /> : <CircleX className="size-8 text-danger" />}
              </motion.div>
              <div>
                <div className="eyebrow">Verification decision</div>
                <div className="mt-1 font-display text-4xl font-bold tracking-tight sm:text-5xl" style={{ color }}>
                  {isMatch ? 'MATCH' : 'NON-MATCH'}
                </div>
                <div className="mt-1 text-sm text-muted">
                  {isMatch ? 'Same speaker' : 'Different speakers'} according to the {record.isDemo ? 'demo' : 'backend'} decision.
                </div>
              </div>
            </div>
            <div className="sm:text-right">
              <div className="eyebrow">Similarity score</div>
              <div className="mt-1 font-mono text-4xl font-medium tabular-nums">{similarity.toFixed(3)}</div>
              <div className="mt-1 font-mono text-xs text-muted">{metric ? `${metric} similarity` : 'similarity'}</div>
            </div>
          </div>

          <div className="relative mt-4">
            <SimilarityScale similarity={similarity} threshold={threshold} isMatch={isMatch} />
          </div>

          <div className="relative mt-5 grid gap-3 border-t border-white/[0.06] pt-5 text-sm sm:grid-cols-2">
            <div>
              <div className="text-xs text-subtle">Configured threshold</div>
              <div className="font-mono">{threshold !== null ? threshold.toFixed(3) : 'Not reported by backend'}</div>
            </div>
            <div>
              <div className="text-xs text-subtle">Method</div>
              <div>{record.speakerMode === 'registered' ? 'Pre-registered speaker' : 'Reference + test audio'}</div>
            </div>
          </div>

          <p className="relative mt-5 flex items-start gap-2 rounded-xl border border-line bg-ink-900/60 p-3 text-xs leading-relaxed text-muted">
            <Info className="mt-0.5 size-3.5 shrink-0" />
            The similarity score measures how close the two speaker embeddings are. It is not a probability that the recordings come
            from the same person; the decision depends on a calibrated threshold.
          </p>
        </motion.section>

        <div className="space-y-5">
          <ResultCard title="Actions" icon={Gauge} accent={task.accent}>
            <div className="flex flex-col gap-2">
              <Button variant="secondary" icon={RotateCcw} to="/speaker" data-testid="compare-again">
                Compare Again
              </Button>
              <Button variant="secondary" icon={Download} onClick={() => downloadJSON(exportPayload(record), `${name}_speaker_verification.json`)}>
                Download Results
              </Button>
            </div>
          </ResultCard>
          <AnalysisDetails record={record} task={task} />
        </div>
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        {record.speakerMode === 'registered' ? (
          <RegisteredSpeakerCard speaker={record.speaker} />
        ) : (
          <ResultAudio meta={record.reference} entry={referenceEntry} role="Reference audio" accent="#00C2FF" />
        )}
        <ResultAudio meta={record.audio} entry={primaryEntry} role="Test audio" accent={task.accent} />
      </div>
    </div>
  );
}
