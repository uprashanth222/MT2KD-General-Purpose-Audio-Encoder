import { useState } from 'react';
import { Check, Copy, FileJson, FileText, Quote } from 'lucide-react';
import Button from '../ui/Button';
import ResultCard, { AnalysisDetails, ResultAudio } from '../ResultCard';
import { ASR_DECODING_OPTIONS } from '@/config/tasks';
import { baseName, copyToClipboard, downloadJSON, downloadText } from '@/utils/download';

export function exportPayload(record) {
  const { raw: _raw, ...result } = record.result || {};
  return {
    analysis_id: record.id,
    task: record.task,
    mode: record.mode,
    is_demo_data: !!record.isDemo,
    created_at: record.createdAt,
    audio: record.audio,
    reference_audio: record.reference || null,
    registered_speaker: record.speaker || null,
    options: record.options || null,
    result,
  };
}

export default function AsrResults({ record, task, primaryEntry }) {
  const { transcription, decodingMethod, language } = record.result;
  const [copied, setCopied] = useState(false);
  const words = transcription.trim() ? transcription.trim().split(/\s+/).length : 0;
  const name = baseName(record.audio?.name);
  const decodingLabel = ASR_DECODING_OPTIONS.find((o) => o.value === decodingMethod)?.label || decodingMethod;

  const copy = async () => {
    const ok = await copyToClipboard(transcription);
    if (ok) {
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    }
  };

  return (
    <div className="grid gap-5 lg:grid-cols-[1.6fr_1fr]">
      <div className="space-y-5">
        <ResultCard
          title="Recognized transcription"
          icon={Quote}
          accent={task.accent}
          actions={
            <>
              <Button size="sm" variant="secondary" icon={copied ? Check : Copy} onClick={copy} data-testid="copy-transcription">
                {copied ? 'Copied' : 'Copy'}
              </Button>
              <Button size="sm" variant="secondary" icon={FileText} onClick={() => downloadText(transcription, `${name}_transcription.txt`)}>
                TXT
              </Button>
              <Button size="sm" variant="secondary" icon={FileJson} onClick={() => downloadJSON(exportPayload(record), `${name}_asr.json`)}>
                JSON
              </Button>
            </>
          }
        >
          <div className="relative">
            {record.isDemo && (
              <span className="mb-4 inline-block rounded-md border border-amber/30 bg-amber/10 px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider text-amber">
                Sample text · not a model output
              </span>
            )}
            {transcription.trim() ? (
              <p className="max-w-[68ch] whitespace-pre-wrap text-[17px] leading-8 text-fg/95 sm:text-lg sm:leading-9" data-testid="transcription">
                {transcription}
              </p>
            ) : (
              <p className="text-muted">The model returned an empty transcription (no speech detected).</p>
            )}
          </div>
          <div className="mt-6 flex flex-wrap gap-x-6 gap-y-2 border-t border-white/[0.05] pt-4 font-mono text-xs text-muted">
            <span>
              <span className="text-fg">{words}</span> words
            </span>
            <span>
              <span className="text-fg">{transcription.length}</span> characters
            </span>
            {decodingLabel && <span>decoding: {decodingLabel}</span>}
            {language && <span>language: {language}</span>}
          </div>
        </ResultCard>
      </div>

      <div className="space-y-5">
        <ResultAudio meta={record.audio} entry={primaryEntry} role="Uploaded audio" accent={task.accent} />
        <AnalysisDetails record={record} task={task} />
      </div>
    </div>
  );
}
