import { useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { Bar, BarChart, Cell, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { ChartBar, ChevronDown, FileJson, FileSpreadsheet, ListOrdered } from 'lucide-react';
import Button from '../ui/Button';
import ResultCard, { AnalysisDetails, ResultAudio } from '../ResultCard';
import { exportPayload } from './AsrResults';
import { baseName, downloadCSV, downloadJSON } from '@/utils/download';
import { formatPercent, cn } from '@/utils/format';

const truncate = (s, n) => (s.length > n ? `${s.slice(0, n - 1)}…` : s);

function ChartTooltip({ active, payload }) {
  if (!active || !payload?.length) return null;
  const p = payload[0].payload;
  return (
    <div className="rounded-lg border border-line-strong bg-ink-900 px-3 py-2 text-xs shadow-xl">
      <div className="font-medium text-fg">{p.label}</div>
      <div className="mt-0.5 font-mono text-accent">{formatPercent(p.score)}</div>
    </div>
  );
}

function ConfidenceRow({ rank, label, score, accent, highlight }) {
  return (
    <li className="grid grid-cols-[2rem_1fr_auto] items-center gap-3 py-2" data-testid="prediction-row">
      <span className="font-mono text-xs text-subtle">{String(rank).padStart(2, '0')}</span>
      <div className="min-w-0">
        <div className={cn('truncate text-sm', highlight ? 'text-fg' : 'text-fg/80')} title={label}>
          {label}
        </div>
        <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-white/[0.06]">
          <motion.div
            className="h-full rounded-full"
            initial={{ width: 0 }}
            animate={{ width: `${Math.max(1, score * 100)}%` }}
            transition={{ duration: 0.7, delay: Math.min(rank, 12) * 0.03, ease: 'easeOut' }}
            style={{ width: `${Math.max(1, score * 100)}%`, background: highlight ? `linear-gradient(90deg, #7C5CFC, ${accent})` : 'rgb(148 163 184 / 0.45)' }}
          />
        </div>
      </div>
      <span className="w-14 text-right font-mono text-xs tabular-nums text-muted">{formatPercent(score)}</span>
    </li>
  );
}

export default function TaggingResults({ record, task, primaryEntry }) {
  const { predictions } = record.result;
  const topK = Math.min(record.options?.topK || record.result.topK || 10, predictions.length);
  const [expanded, setExpanded] = useState(false);
  const top = useMemo(() => predictions.slice(0, topK), [predictions, topK]);
  const name = baseName(record.audio?.name);
  const visible = expanded ? predictions : top;

  const exportCsv = () =>
    downloadCSV(
      predictions.map((p, i) => ({ ...p, rank: i + 1 })),
      [
        { label: 'rank', value: (r) => r.rank },
        { label: 'label', value: (r) => r.label },
        { label: 'score', value: (r) => r.score.toFixed(6) },
        { label: 'is_demo_data', value: () => !!record.isDemo },
      ],
      `${name}_audio_tags.csv`,
    );

  return (
    <div className="space-y-5">
      {/* Primary categories */}
      <div className="grid gap-3 sm:grid-cols-3">
        {predictions.slice(0, 3).map((p, i) => (
          <motion.div
            key={p.label}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.06 }}
            className="panel relative overflow-hidden p-5"
          >
            <div className="pointer-events-none absolute -right-10 -top-10 size-32 rounded-full blur-2xl" style={{ background: `rgb(${task.accentRgb} / ${0.25 - i * 0.07})` }} />
            <div className="relative font-mono text-[11px] uppercase tracking-widest text-subtle">#{i + 1} prediction</div>
            <div className="relative mt-2 truncate text-lg font-semibold" title={p.label}>
              {p.label}
            </div>
            <div className="relative mt-1 font-mono text-2xl text-accent">{formatPercent(p.score)}</div>
          </motion.div>
        ))}
      </div>

      <div className="grid gap-5 lg:grid-cols-[1.6fr_1fr]">
        <div className="space-y-5">
          <ResultCard
            title={`Top ${topK} predictions`}
            icon={ChartBar}
            accent={task.accent}
            actions={
              <>
                <Button size="sm" variant="secondary" icon={FileJson} onClick={() => downloadJSON(exportPayload(record), `${name}_audio_tags.json`)}>
                  JSON
                </Button>
                <Button size="sm" variant="secondary" icon={FileSpreadsheet} onClick={exportCsv}>
                  CSV
                </Button>
              </>
            }
          >
            {top.length ? (
              <div style={{ height: Math.max(180, top.length * 34 + 30) }} data-testid="tag-chart">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={top} layout="vertical" margin={{ top: 0, right: 16, bottom: 0, left: 0 }} barCategoryGap={6}>
                    <defs>
                      <linearGradient id="tagGrad" x1="0" y1="0" x2="1" y2="0">
                        <stop offset="0%" stopColor="#7C5CFC" />
                        <stop offset="100%" stopColor="#00C2FF" />
                      </linearGradient>
                    </defs>
                    <XAxis
                      type="number"
                      domain={[0, 1]}
                      tickFormatter={(v) => `${Math.round(v * 100)}%`}
                      tick={{ fill: '#64748B', fontSize: 11 }}
                      axisLine={false}
                      tickLine={false}
                    />
                    <YAxis
                      type="category"
                      dataKey="label"
                      width={150}
                      tick={{ fill: '#CBD5E1', fontSize: 12 }}
                      tickFormatter={(v) => truncate(v, 22)}
                      axisLine={false}
                      tickLine={false}
                    />
                    <Tooltip cursor={{ fill: 'rgb(255 255 255 / 0.03)' }} content={<ChartTooltip />} />
                    <Bar dataKey="score" radius={[0, 6, 6, 0]} isAnimationActive>
                      {top.map((p, i) => (
                        <Cell key={p.label} fill="url(#tagGrad)" fillOpacity={1 - i * (0.6 / Math.max(1, top.length))} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <p className="text-sm text-muted">No predictions were returned for this audio.</p>
            )}
            <p className="mt-4 text-xs text-subtle">
              Scores are independent per-class confidences (multi-label sigmoid outputs), so they do not sum to 100%.
            </p>
          </ResultCard>

          <ResultCard title={expanded ? `All ${predictions.length} predictions` : 'Confidence scores'} icon={ListOrdered}>
            <ol className="divide-y divide-white/[0.04]">
              {visible.map((p, i) => (
                <ConfidenceRow key={p.label} rank={i + 1} label={p.label} score={p.score} accent={task.accent} highlight={i < topK} />
              ))}
            </ol>
            {predictions.length > topK && (
              <button
                type="button"
                onClick={() => setExpanded((e) => !e)}
                className="mt-4 flex w-full items-center justify-center gap-1.5 rounded-xl border border-line py-2.5 text-sm text-muted transition hover:bg-white/[0.03] hover:text-fg"
                aria-expanded={expanded}
                data-testid="toggle-predictions"
              >
                {expanded ? 'Show top predictions only' : `Show all ${predictions.length} predictions`}
                <ChevronDown className={cn('size-4 transition-transform', expanded && 'rotate-180')} />
              </button>
            )}
          </ResultCard>
        </div>

        <div className="space-y-5">
          <ResultAudio meta={record.audio} entry={primaryEntry} role="Analysed audio" accent={task.accent} />
          <AnalysisDetails record={record} task={task} />
        </div>
      </div>
    </div>
  );
}
