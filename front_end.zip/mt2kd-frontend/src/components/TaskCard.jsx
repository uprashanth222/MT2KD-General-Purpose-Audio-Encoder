import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Check, CircleCheck, ArrowUpRight } from 'lucide-react';
import { cn } from '@/utils/format';

/** Interactive selectable capability card. */
export default function TaskCard({ task, selected, onSelect, lastResultId }) {
  const { icon: Icon, accent, accentRgb } = task;
  return (
    <motion.div
      role="radio"
      aria-checked={selected}
      tabIndex={0}
      onClick={() => onSelect(task.id)}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          onSelect(task.id);
        }
      }}
      whileHover={{ y: -4 }}
      transition={{ type: 'spring', stiffness: 320, damping: 26 }}
      className={cn(
        'group relative flex h-full cursor-pointer flex-col overflow-hidden rounded-2xl border bg-card p-6 transition-colors duration-300 outline-none',
        selected ? 'border-transparent' : 'border-line hover:border-line-strong',
      )}
      style={
        selected
          ? { boxShadow: `0 0 0 1.5px rgb(${accentRgb} / 0.9), 0 18px 48px -16px rgb(${accentRgb} / 0.55)` }
          : undefined
      }
      data-testid={`task-card-${task.id}`}
    >
      {/* identity glow */}
      <div
        className="pointer-events-none absolute -right-16 -top-16 size-48 rounded-full blur-3xl transition-opacity duration-500"
        style={{ background: `rgb(${accentRgb} / 0.22)`, opacity: selected ? 1 : 0.35 }}
      />
      <div className="relative flex items-start justify-between">
        <div
          className="flex size-14 items-center justify-center rounded-2xl border border-white/10 transition-transform duration-300 group-hover:scale-105"
          style={{ background: `linear-gradient(145deg, rgb(${accentRgb} / 0.35), rgb(${accentRgb} / 0.06))` }}
        >
          <Icon className="size-6" style={{ color: accent }} />
        </div>
        <div className="flex flex-col items-end gap-2">
          <span className="font-mono text-[11px] tracking-widest text-subtle">{task.short}</span>
          {selected && (
            <motion.span
              initial={{ scale: 0.6, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="flex size-6 items-center justify-center rounded-full text-ink-950"
              style={{ background: accent }}
            >
              <Check className="size-3.5" strokeWidth={3} />
            </motion.span>
          )}
        </div>
      </div>

      <h3 className="relative mt-6 text-xl font-semibold">{task.title}</h3>
      <p className="relative mt-2 text-sm leading-relaxed text-muted">{task.description}</p>

      <ul className="relative mt-5 space-y-2">
        {task.features.map((f) => (
          <li key={f} className="flex items-center gap-2.5 text-sm text-fg/90">
            <span className="size-1.5 rounded-full" style={{ background: accent }} />
            {f}
          </li>
        ))}
      </ul>

      <div className="relative mt-auto pt-6">
        {lastResultId && (
          <Link
            to={`/results/${lastResultId}`}
            onClick={(e) => e.stopPropagation()}
            className="mb-3 inline-flex items-center gap-1.5 text-xs text-success hover:underline"
          >
            <CircleCheck className="size-3.5" /> Already run on this audio · view result <ArrowUpRight className="size-3" />
          </Link>
        )}
        <button
          type="button"
          tabIndex={-1}
          onClick={(e) => {
            e.stopPropagation();
            onSelect(task.id);
          }}
          className={cn(
            'flex h-11 w-full items-center justify-center gap-2 rounded-xl border text-sm font-medium transition-all duration-200',
            selected ? 'border-transparent text-ink-950' : 'border-line-strong text-fg hover:bg-white/[0.05]',
          )}
          style={selected ? { background: accent } : undefined}
        >
          {selected ? (
            <>
              <Check className="size-4" strokeWidth={2.5} /> Selected
            </>
          ) : (
            task.cta
          )}
        </button>
      </div>
    </motion.div>
  );
}
