import { CircleCheck, CircleX, FlaskConical, LoaderCircle, Radio, Ban, CirclePause } from 'lucide-react';
import { cn } from '@/utils/format';

/** DEMO MODE / LIVE badge. */
export function ModeBadge({ mode, className, size = 'md' }) {
  const demo = mode === 'demo';
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 rounded-full border font-mono font-medium uppercase tracking-[0.12em]',
        size === 'sm' ? 'px-2 py-0.5 text-[10px]' : 'px-2.5 py-1 text-[11px]',
        demo ? 'border-amber/40 bg-amber/10 text-amber' : 'border-success/40 bg-success/10 text-success',
        className,
      )}
      title={demo ? 'Simulated processing with sample data – not model predictions' : 'Connected to the MT2KD backend'}
    >
      {demo ? <FlaskConical className="size-3" /> : <Radio className="size-3" />}
      {demo ? 'Demo Mode' : 'Live'}
    </span>
  );
}

const STATUS = {
  completed: { label: 'Completed', icon: CircleCheck, cls: 'text-success bg-success/10 border-success/30' },
  failed: { label: 'Failed', icon: CircleX, cls: 'text-danger bg-danger/10 border-danger/30' },
  running: { label: 'Running', icon: LoaderCircle, cls: 'text-accent bg-accent/10 border-accent/30', spin: true },
  queued: { label: 'Queued', icon: LoaderCircle, cls: 'text-accent bg-accent/10 border-accent/30', spin: true },
  cancelled: { label: 'Cancelled', icon: Ban, cls: 'text-muted bg-white/5 border-line-strong' },
  interrupted: { label: 'Interrupted', icon: CirclePause, cls: 'text-warning bg-warning/10 border-warning/30' },
};

/** Generic processing status pill. */
export default function StatusBadge({ status, className }) {
  const key = String(status || '').toLowerCase();
  const s = STATUS[key] || { label: status || 'Unknown', icon: CirclePause, cls: 'text-muted bg-white/5 border-line-strong' };
  const Icon = s.icon;
  return (
    <span className={cn('inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-xs font-medium', s.cls, className)}>
      <Icon className={cn('size-3.5', s.spin && 'animate-spin')} />
      {s.label}
    </span>
  );
}
