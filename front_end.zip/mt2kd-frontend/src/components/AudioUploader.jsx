import { useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { CloudUpload, CircleAlert, LoaderCircle } from 'lucide-react';
import { ACCEPT_ATTR, config } from '@/config/appConfig';
import { cn } from '@/utils/format';

/**
 * Drag-and-drop audio picker. Validation/decoding happens in `onFile`,
 * which must resolve to { ok: boolean, error?: string }.
 */
export default function AudioUploader({
  onFile,
  title = 'Upload Your Audio File',
  hint,
  compact = false,
  accent = '#7C5CFC',
  inputId = 'audio-upload',
}) {
  const inputRef = useRef(null);
  const [dragging, setDragging] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const dragDepth = useRef(0);

  const handleFiles = async (files) => {
    const list = Array.from(files || []);
    if (!list.length) return;
    if (list.length > 1) {
      setError('Please upload one file at a time.');
      return;
    }
    setBusy(true);
    setError(null);
    const res = await onFile(list[0]);
    setBusy(false);
    if (!res?.ok) setError(res?.error || 'This file could not be used.');
  };

  const onDrop = (e) => {
    e.preventDefault();
    dragDepth.current = 0;
    setDragging(false);
    if (!busy) handleFiles(e.dataTransfer.files);
  };

  return (
    <div>
      <motion.label
        htmlFor={inputId}
        onDragEnter={(e) => {
          e.preventDefault();
          dragDepth.current += 1;
          setDragging(true);
        }}
        onDragOver={(e) => e.preventDefault()}
        onDragLeave={() => {
          dragDepth.current -= 1;
          if (dragDepth.current <= 0) setDragging(false);
        }}
        onDrop={onDrop}
        whileHover={{ y: -2 }}
        transition={{ type: 'spring', stiffness: 300, damping: 24 }}
        className={cn(
          'group relative flex cursor-pointer flex-col items-center justify-center overflow-hidden rounded-2xl border-2 border-dashed text-center transition-colors duration-200',
          compact ? 'px-5 py-7' : 'px-6 py-12 sm:py-14',
          dragging ? 'border-accent bg-accent/[0.07]' : 'border-line-strong bg-ink-900/60 hover:border-primary/60 hover:bg-primary/[0.04]',
          busy && 'pointer-events-none',
        )}
        style={dragging ? { boxShadow: 'var(--shadow-glow-cyan)' } : undefined}
      >
        <div className="grid-bg pointer-events-none absolute inset-0 opacity-60" />
        <div
          className={cn(
            'relative flex items-center justify-center rounded-2xl border border-white/10 transition-transform duration-300 group-hover:scale-105',
            compact ? 'size-12' : 'size-16',
          )}
          style={{ background: `linear-gradient(140deg, ${accent}40, rgb(0 194 255 / 0.18))` }}
        >
          {busy ? (
            <LoaderCircle className={cn('animate-spin text-fg', compact ? 'size-5' : 'size-7')} />
          ) : (
            <CloudUpload className={cn('text-fg', compact ? 'size-5' : 'size-7')} />
          )}
        </div>
        <div className={cn('relative font-display font-semibold', compact ? 'mt-3 text-base' : 'mt-5 text-lg')}>
          {busy ? 'Reading audio…' : dragging ? 'Drop to upload' : title}
        </div>
        <p className="relative mt-1.5 text-sm text-muted">
          Drag and drop or <span className="font-medium text-accent underline-offset-4 group-hover:underline">Browse Files</span>
        </p>
        <div className="relative mt-4 flex flex-wrap items-center justify-center gap-1.5">
          {['WAV', 'MP3', 'FLAC'].map((f) => (
            <span key={f} className="rounded-md border border-line-strong bg-white/[0.03] px-2 py-0.5 font-mono text-[11px] text-muted">
              {f}
            </span>
          ))}
          <span className="ml-1 font-mono text-[11px] text-subtle">· max {config.maxFileSizeMB} MB</span>
        </div>
        {hint && <p className="relative mt-3 max-w-sm text-xs text-subtle">{hint}</p>}
        <input
          ref={inputRef}
          id={inputId}
          type="file"
          accept={ACCEPT_ATTR}
          className="sr-only"
          onChange={(e) => {
            handleFiles(e.target.files);
            e.target.value = '';
          }}
        />
      </motion.label>
      {error && (
        <motion.div
          role="alert"
          initial={{ opacity: 0, y: -4 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-3 flex items-start gap-2.5 rounded-xl border border-danger/30 bg-danger/10 px-4 py-3 text-sm text-red-200"
        >
          <CircleAlert className="mt-0.5 size-4 shrink-0 text-danger" />
          <span>{error}</span>
        </motion.div>
      )}
    </div>
  );
}
