import { useEffect } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import Navbar from '../Navbar';
import Sidebar from '../Sidebar';
import MobileNav, { MobileTopBar } from '../MobileNav';
import { useSession } from '@/context/AudioContext';

function PageTransition({ children }) {
  const { pathname } = useLocation();
  return (
    <motion.div
      key={pathname}
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.28, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </motion.div>
  );
}

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo({ top: 0 });
  }, [pathname]);
  return null;
}

/**
 * Before the user has entered the app: minimal top navbar.
 * After: desktop sidebar + mobile top bar & bottom navigation.
 */
export default function AppLayout() {
  const { hasEnteredApp } = useSession();

  if (!hasEnteredApp) {
    return (
      <div className="min-h-dvh">
        <ScrollToTop />
        <Navbar />
        <main className="mx-auto max-w-6xl px-4 py-10 sm:px-6 sm:py-14">
          <PageTransition>
            <Outlet />
          </PageTransition>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-dvh">
      <ScrollToTop />
      <Sidebar />
      <MobileTopBar />
      <main className="pb-28 lg:pb-12 lg:pl-[264px]">
        <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6 lg:px-10 lg:py-12">
          <PageTransition>
            <Outlet />
          </PageTransition>
        </div>
      </main>
      <MobileNav />
    </div>
  );
}
