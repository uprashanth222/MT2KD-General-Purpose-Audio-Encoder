import { cn } from '@/utils/format';

/**
 * Decorative animated waveform (CSS only). Not tied to real audio data.
 * `active=false` freezes it into a static silhouette.
 */
const PROFILE = [0.3, 0.5, 0.8, 0.45, 0.95, 0.6, 0.75, 0.35, 0.9, 0.55, 1, 0.65, 0.4, 0.85, 0.5, 0.7, 0.3, 0.6, 0.9, 0.45, 0.75, 0.35, 0.55, 0.25];

export default function AnimatedWave({ bars = 24, active = true, color = 'linear-gradient(180deg,#A18BFF,#00C2FF)', className, height = 56 }) {
  const items = Array.from({ length: bars }, (_, i) => PROFILE[i % PROFILE.length]);
  return (
    <div className={cn('flex items-center gap-[3px]', className)} style={{ height }} aria-hidden>
      {items.map((h, i) => (
        <span
          key={i}
          className="w-[3px] origin-center rounded-full"
          style={{
            height: `${Math.round(h * 100)}%`,
            background: color,
            animation: active ? `wave ${0.9 + (i % 5) * 0.12}s ease-in-out ${(i % 7) * -0.13}s infinite` : 'none',
            opacity: active ? 0.95 : 0.5,
          }}
        />
      ))}
    </div>
  );
}
