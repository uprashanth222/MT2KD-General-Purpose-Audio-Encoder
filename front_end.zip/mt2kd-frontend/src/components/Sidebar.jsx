import { useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { BookOpen, Cpu, FileAudio, History, House, Info, LayoutGrid, RotateCcw, CloudUpload } from 'lucide-react';
import Logo from './Logo';
import { ModeBadge } from './StatusBadge';
import ConfirmDialog from './ui/ConfirmDialog';
import { useSession } from '@/context/AudioContext';
import { useBackendHealth } from '@/hooks/useBackendHealth';
import { formatDuration, cn } from '@/utils/format';
import { config } from '@/config/appConfig';

export const NAV_ITEMS = [
  { to: '/', label: 'Home', short: 'Home', icon: House, end: true },
  { to: '/upload', label: 'Upload Audio', short: 'Upload', icon: CloudUpload },
  { to: '/tasks', label: 'Task Selection', short: 'Tasks', icon: LayoutGrid },
  { to: '/history', label: 'Analysis History', short: 'History', icon: History },
  { to: '/models', label: 'Model Information', short: 'Model', icon: Cpu },
  { to: '/about', label: 'About Project', short: 'About', icon: Info },
];

export function BackendStatus({ className }) {
  const health = useBackendHealth();
  if (health.status === 'demo') return null;
  const map = {
    checking: ['bg-muted', 'Checking backend…'],
    online: ['bg-success', 'Backend online'],
    offline: ['bg-danger', 'Backend unreachable'],
  };
  const [dot, text] = map[health.status] || map.checking;
  return (
    <button
      type="button"
      onClick={health.recheck}
      title={health.error || config.apiBaseUrl}
      className={cn('flex items-center gap-2 text-xs text-muted hover:text-fg', className)}
    >
      <span className={cn('size-2 rounded-full', dot, health.status === 'checking' && 'animate-pulse')} />
      {text}
    </button>
  );
}

/** Desktop sidebar (lg and up). */
export default function Sidebar() {
  const { mode, audio, clearSession } = useSession();
  const navigate = useNavigate();
  const [confirm, setConfirm] = useState(false);

  return (
    <aside className="fixed inset-y-0 left-0 z-30 hidden w-[264px] flex-col border-r border-white/[0.05] bg-ink-900/60 backdrop-blur-xl lg:flex">
      <div className="flex h-[72px] items-center px-6">
        <Logo />
      </div>
      <div className="flex items-center justify-between gap-2 px-6 pb-4">
        <ModeBadge mode={mode} size="sm" />
        <BackendStatus />
      </div>

      <nav className="flex-1 space-y-1 overflow-y-auto px-3 py-2" aria-label="Application">
        {NAV_ITEMS.map(({ to, label, icon: Icon, end }) => (
          <NavLink
            key={to}
            to={to}
            end={end}
            className={({ isActive }) =>
              cn(
                'group relative flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-colors',
                isActive ? 'bg-primary/[0.12] text-fg' : 'text-muted hover:bg-white/[0.04] hover:text-fg',
              )
            }
          >
            {({ isActive }) => (
              <>
                {isActive && <span className="absolute inset-y-2 left-0 w-[3px] rounded-r-full bg-primary shadow-[0_0_12px_#7C5CFC]" />}
                <Icon className={cn('size-[18px]', isActive ? 'text-primary-soft' : 'text-subtle group-hover:text-muted')} />
                {label}
              </>
            )}
          </NavLink>
        ))}
        <div className="my-3 border-t border-white/[0.05]" />
        <NavLink
          to="/docs"
          className={({ isActive }) =>
            cn(
              'flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-colors',
              isActive ? 'bg-primary/[0.12] text-fg' : 'text-muted hover:bg-white/[0.04] hover:text-fg',
            )
          }
        >
          <BookOpen className="size-[18px] text-subtle" />
          Documentation
        </NavLink>
      </nav>

      <div className="space-y-3 p-4">
        <div className="rounded-xl border border-line bg-card/70 p-3.5">
          <div className="eyebrow mb-2">Session audio</div>
          {audio ? (
            <div className="flex items-center gap-2.5">
              <div className="flex size-8 shrink-0 items-center justify-center rounded-lg bg-primary/15">
                <FileAudio className="size-4 text-primary-soft" />
              </div>
              <div className="min-w-0">
                <div className="truncate text-sm font-medium" title={audio.name}>
                  {audio.name}
                </div>
                <div className="font-mono text-[11px] text-muted">
                  {audio.format} · {formatDuration(audio.duration)}
                  {audio.missingFile && <span className="text-warning"> · re-select</span>}
                </div>
              </div>
            </div>
          ) : (
            <NavLink to="/upload" className="text-sm text-accent hover:underline">
              No audio yet — upload one
            </NavLink>
          )}
        </div>
        <button
          type="button"
          onClick={() => setConfirm(true)}
          className="flex w-full items-center justify-center gap-2 rounded-xl px-3 py-2 text-xs text-muted transition hover:bg-danger/10 hover:text-danger"
        >
          <RotateCcw className="size-3.5" /> Clear session
        </button>
      </div>

      <ConfirmDialog
        open={confirm}
        title="Clear this session?"
        message="This removes your uploaded audio, reference audio and current selections from this browser tab. Analysis history is kept."
        confirmLabel="Clear session"
        onCancel={() => setConfirm(false)}
        onConfirm={() => {
          setConfirm(false);
          clearSession();
          navigate('/');
        }}
      />
    </aside>
  );
}
