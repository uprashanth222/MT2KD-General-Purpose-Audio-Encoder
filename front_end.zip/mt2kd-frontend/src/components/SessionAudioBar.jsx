import { Link } from 'react-router-dom';
import { CircleAlert, FileAudio } from 'lucide-react';
import { formatBytes, formatDuration } from '@/utils/format';

/** Compact strip showing which session audio a task will run on. */
export default function SessionAudioBar({ audio, label = 'Analysing' }) {
  if (!audio) return null;
  return (
    <div className="mb-8 space-y-3">
      <div className="flex flex-wrap items-center gap-x-4 gap-y-2 rounded-2xl border border-line bg-card/70 px-4 py-3">
        <div className="flex min-w-0 items-center gap-3">
          <div className="flex size-9 shrink-0 items-center justify-center rounded-lg bg-primary/15">
            <FileAudio className="size-4 text-primary-soft" />
          </div>
          <div className="min-w-0">
            <div className="text-[11px] uppercase tracking-wider text-subtle">{label}</div>
            <div className="truncate text-sm font-medium" title={audio.name}>
              {audio.name}
            </div>
          </div>
        </div>
        <div className="flex items-center gap-3 font-mono text-xs text-muted">
          <span>{audio.format}</span>
          <span className="text-line-strong">|</span>
          <span>{formatDuration(audio.duration)}</span>
          <span className="text-line-strong">|</span>
          <span>{formatBytes(audio.size)}</span>
        </div>
        <Link to="/upload" className="ml-auto text-xs font-medium text-accent hover:underline">
          Change audio
        </Link>
      </div>
      {audio.missingFile && (
        <div className="flex items-start gap-2.5 rounded-xl border border-warning/30 bg-warning/10 px-4 py-3 text-sm text-amber-100">
          <CircleAlert className="mt-0.5 size-4 shrink-0 text-warning" />
          <span>
            After the refresh this audio could not be restored from temporary storage.{' '}
            <Link to="/upload" className="font-medium text-amber underline">
              Re-select the file
            </Link>{' '}
            to continue.
          </span>
        </div>
      )}
    </div>
  );
}
