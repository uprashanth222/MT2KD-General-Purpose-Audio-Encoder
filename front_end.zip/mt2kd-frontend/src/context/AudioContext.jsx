/* eslint-disable react-refresh/only-export-components */
import { createContext, useCallback, useContext, useEffect, useMemo, useReducer, useRef } from 'react';
import { APP_MODE, config, IS_DEMO } from '@/config/appConfig';
import { getTask } from '@/config/tasks';
import {
  audioMeta,
  clearPersistedAudio,
  createAudioEntry,
  deletePersistedAudio,
  persistAudioFile,
  releaseAudioEntry,
  restoreAudioFile,
} from '@/services/audioService';
import { runDemoAnalysis } from '@/services/demoService';
import { runLiveAnalysis, normalizeError } from '@/services/api';
import { createId } from '@/utils/id';

/* ------------------------------------------------------------------
   Storage keys
   - session (sessionStorage): current workflow, survives refresh, tab-scoped
   - history (localStorage):   analysis records kept in this browser
   - audio blobs (IndexedDB):  see audioService – temporary copies for refresh
   ------------------------------------------------------------------ */
const SESSION_KEY = 'mt2kd.session.v1';
const HISTORY_KEY = `mt2kd.history.${APP_MODE}.v1`;

const DEFAULT_OPTIONS = {
  asr: { decodingMethod: 'greedy_search' },
  tagging: { topK: 10 },
};

const readJSON = (storage, key, fallback) => {
  try {
    const raw = storage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
};

const writeJSON = (storage, key, value) => {
  try {
    storage.setItem(key, JSON.stringify(value));
  } catch {
    /* quota or privacy mode – non fatal */
  }
};

/* ------------------------------------------------------------------
   Initial state (rehydrated from storage)
   ------------------------------------------------------------------ */
function init() {
  const saved = typeof window !== 'undefined' ? readJSON(sessionStorage, SESSION_KEY, null) : null;
  const history = typeof window !== 'undefined' ? readJSON(localStorage, HISTORY_KEY, []) : [];
  const metaOnly = (m) => (m ? { ...m, file: null, url: null, missingFile: true } : null);

  let currentJob = saved?.currentJob || null;
  if (currentJob && currentJob.status === 'running') {
    currentJob = {
      ...currentJob,
      status: 'interrupted',
      error: 'The page was refreshed while this analysis was running, so it was stopped.',
    };
  }

  return {
    sessionId: saved?.sessionId || createId('ses'),
    hasEnteredApp: !!saved?.hasEnteredApp,
    restoring: !!(saved?.audio || saved?.referenceAudio),
    audio: metaOnly(saved?.audio),
    referenceAudio: metaOnly(saved?.referenceAudio),
    selectedTask: saved?.selectedTask || null,
    taskOptions: { ...DEFAULT_OPTIONS, ...(saved?.taskOptions || {}) },
    speakerMode: saved?.speakerMode || null,
    registeredSpeaker: saved?.registeredSpeaker || null,
    currentJob,
    remoteIds: saved?.remoteIds || {},
    history: Array.isArray(history) ? history : [],
  };
}

/* ------------------------------------------------------------------
   Reducer
   ------------------------------------------------------------------ */
function reducer(state, action) {
  switch (action.type) {
    case 'RESTORED':
      return {
        ...state,
        restoring: false,
        audio: action.audio !== undefined ? action.audio : state.audio,
        referenceAudio: action.referenceAudio !== undefined ? action.referenceAudio : state.referenceAudio,
      };
    case 'SET_AUDIO': {
      const remoteIds = { ...state.remoteIds };
      if (state.audio) delete remoteIds[state.audio.id];
      return { ...state, audio: action.entry, remoteIds };
    }
    case 'SET_REFERENCE': {
      const remoteIds = { ...state.remoteIds };
      if (state.referenceAudio) delete remoteIds[state.referenceAudio.id];
      return { ...state, referenceAudio: action.entry, remoteIds };
    }
    case 'ENTER_APP':
      return { ...state, hasEnteredApp: true };
    case 'SELECT_TASK':
      return { ...state, selectedTask: action.task };
    case 'SET_TASK_OPTION':
      return {
        ...state,
        taskOptions: {
          ...state.taskOptions,
          [action.task]: { ...state.taskOptions[action.task], [action.key]: action.value },
        },
      };
    case 'SET_SPEAKER_MODE':
      return { ...state, speakerMode: action.mode };
    case 'SET_REGISTERED_SPEAKER':
      return { ...state, registeredSpeaker: action.speaker };
    case 'SET_REMOTE_ID':
      return { ...state, remoteIds: { ...state.remoteIds, [action.entryId]: action.remoteId } };
    case 'JOB_START':
      return { ...state, currentJob: action.job };
    case 'JOB_UPDATE':
      if (!state.currentJob || state.currentJob.id !== action.id) return state;
      return { ...state, currentJob: { ...state.currentJob, ...action.patch } };
    case 'JOB_CLEAR':
      return { ...state, currentJob: null };
    case 'ADD_HISTORY':
      return {
        ...state,
        history: [action.record, ...state.history.filter((r) => r.id !== action.record.id)].slice(0, config.historyLimit),
      };
    case 'CLEAR_HISTORY':
      return { ...state, history: [] };
    case 'RESET_WORKFLOW':
      return {
        ...state,
        audio: null,
        referenceAudio: null,
        selectedTask: null,
        speakerMode: null,
        registeredSpeaker: null,
        currentJob: null,
        remoteIds: {},
      };
    case 'CLEAR_SESSION':
      return {
        ...state,
        sessionId: createId('ses'),
        hasEnteredApp: false,
        restoring: false,
        audio: null,
        referenceAudio: null,
        selectedTask: null,
        taskOptions: DEFAULT_OPTIONS,
        speakerMode: null,
        registeredSpeaker: null,
        currentJob: null,
        remoteIds: {},
      };
    default:
      return state;
  }
}

/* ------------------------------------------------------------------
   Helpers
   ------------------------------------------------------------------ */
function summarize(task, result) {
  if (!result) return '';
  if (task === 'asr') {
    const words = result.transcription.trim().split(/\s+/).filter(Boolean).length;
    const preview = result.transcription.length > 80 ? `${result.transcription.slice(0, 80)}…` : result.transcription;
    return `${words} words · “${preview}”`;
  }
  if (task === 'tagging') {
    const top = result.predictions.slice(0, 3).map((p) => p.label);
    return top.length ? `Top: ${top.join(', ')}` : 'No predictions returned';
  }
  if (task === 'speaker') {
    return `${result.decision === 'match' ? 'MATCH' : 'NON-MATCH'} · similarity ${result.similarity.toFixed(3)}`;
  }
  return '';
}

/* ------------------------------------------------------------------
   Provider
   ------------------------------------------------------------------ */
const SessionContext = createContext(null);

export function AudioProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, undefined, init);
  const stateRef = useRef(state);
  stateRef.current = state;
  const abortRef = useRef(null);

  /* Restore audio blobs from IndexedDB after a refresh. */
  useEffect(() => {
    const s = stateRef.current;
    if (!s.restoring) return undefined;
    let cancelled = false;
    const created = [];
    (async () => {
      const restoreSlot = async (slot, current) => {
        if (!current) return undefined;
        const restored = await restoreAudioFile(slot, s.sessionId);
        if (restored && restored.id === current.id) {
          created.push(restored);
          return { ...restored, missingFile: false };
        }
        return current; // stays metadata-only → UI asks to re-select
      };
      const audio = await restoreSlot('primary', s.audio);
      const referenceAudio = await restoreSlot('reference', s.referenceAudio);
      if (cancelled) {
        created.forEach(releaseAudioEntry);
        return;
      }
      dispatch({ type: 'RESTORED', audio, referenceAudio });
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  /* Persist workflow (metadata only) + history. */
  useEffect(() => {
    if (state.restoring) return;
    writeJSON(sessionStorage, SESSION_KEY, {
      sessionId: state.sessionId,
      hasEnteredApp: state.hasEnteredApp,
      audio: audioMeta(state.audio),
      referenceAudio: audioMeta(state.referenceAudio),
      selectedTask: state.selectedTask,
      taskOptions: state.taskOptions,
      speakerMode: state.speakerMode,
      registeredSpeaker: state.registeredSpeaker,
      currentJob: state.currentJob,
      remoteIds: state.remoteIds,
    });
  }, [state]);

  useEffect(() => {
    writeJSON(localStorage, HISTORY_KEY, state.history);
  }, [state.history]);

  /* Release object URLs on unmount. */
  useEffect(
    () => () => {
      releaseAudioEntry(stateRef.current.audio);
      releaseAudioEntry(stateRef.current.referenceAudio);
    },
    [],
  );

  /* ---------------- audio actions ---------------- */

  const setAudio = useCallback(async (file) => {
    try {
      const entry = await createAudioEntry(file);
      releaseAudioEntry(stateRef.current.audio);
      dispatch({ type: 'SET_AUDIO', entry });
      persistAudioFile('primary', stateRef.current.sessionId, entry);
      return { ok: true, entry };
    } catch (err) {
      return { ok: false, error: err.message };
    }
  }, []);

  const removeAudio = useCallback(() => {
    releaseAudioEntry(stateRef.current.audio);
    dispatch({ type: 'SET_AUDIO', entry: null });
    deletePersistedAudio('primary');
  }, []);

  const setReferenceAudio = useCallback(async (file) => {
    try {
      const entry = await createAudioEntry(file);
      releaseAudioEntry(stateRef.current.referenceAudio);
      dispatch({ type: 'SET_REFERENCE', entry });
      persistAudioFile('reference', stateRef.current.sessionId, entry);
      return { ok: true, entry };
    } catch (err) {
      return { ok: false, error: err.message };
    }
  }, []);

  const removeReferenceAudio = useCallback(() => {
    releaseAudioEntry(stateRef.current.referenceAudio);
    dispatch({ type: 'SET_REFERENCE', entry: null });
    deletePersistedAudio('reference');
  }, []);

  /* ---------------- workflow actions ---------------- */

  const enterApp = useCallback(() => dispatch({ type: 'ENTER_APP' }), []);
  const selectTask = useCallback((task) => dispatch({ type: 'SELECT_TASK', task }), []);
  const setTaskOption = useCallback((task, key, value) => dispatch({ type: 'SET_TASK_OPTION', task, key, value }), []);
  const setSpeakerMode = useCallback((mode) => dispatch({ type: 'SET_SPEAKER_MODE', mode }), []);
  const setRegisteredSpeaker = useCallback((speaker) => dispatch({ type: 'SET_REGISTERED_SPEAKER', speaker }), []);
  const clearHistory = useCallback(() => dispatch({ type: 'CLEAR_HISTORY' }), []);
  const clearCurrentJob = useCallback(() => dispatch({ type: 'JOB_CLEAR' }), []);

  const clearSession = useCallback(() => {
    abortRef.current?.abort();
    releaseAudioEntry(stateRef.current.audio);
    releaseAudioEntry(stateRef.current.referenceAudio);
    clearPersistedAudio();
    try {
      sessionStorage.removeItem(SESSION_KEY);
    } catch {
      /* ignore */
    }
    dispatch({ type: 'CLEAR_SESSION' });
  }, []);

  /** "Start New Analysis": drop the current audio + selections, stay in the app, keep history. */
  const resetWorkflow = useCallback(() => {
    abortRef.current?.abort();
    releaseAudioEntry(stateRef.current.audio);
    releaseAudioEntry(stateRef.current.referenceAudio);
    clearPersistedAudio();
    dispatch({ type: 'RESET_WORKFLOW' });
  }, []);

  /** Validate that the selected task has everything it needs. */
  const getReadiness = useCallback((s = stateRef.current) => {
    if (!s.audio) return { ok: false, reason: 'Upload an audio file first.' };
    if (s.audio.missingFile) return { ok: false, reason: 'Your audio file needs to be re-selected after the page refresh.' };
    if (!s.selectedTask) return { ok: false, reason: 'Select a task.' };
    if (s.selectedTask === 'speaker') {
      if (!s.speakerMode) return { ok: false, reason: 'Choose a verification method.' };
      if (s.speakerMode === 'pair') {
        if (!s.referenceAudio) return { ok: false, reason: 'Upload a reference audio file.' };
        if (s.referenceAudio.missingFile) return { ok: false, reason: 'Re-select the reference audio file.' };
      }
      if (s.speakerMode === 'registered' && !s.registeredSpeaker) return { ok: false, reason: 'Choose a registered speaker.' };
    }
    return { ok: true };
  }, []);

  /** Start the selected task. Runs independently of any page component. */
  const startAnalysis = useCallback((opts = {}) => {
    const s = opts.task ? { ...stateRef.current, selectedTask: opts.task } : stateRef.current;
    if (opts.task && opts.task !== stateRef.current.selectedTask) dispatch({ type: 'SELECT_TASK', task: opts.task });
    const ready = getReadiness(s);
    if (!ready.ok) return { ok: false, error: ready.reason };
    if (s.currentJob?.status === 'running') return { ok: false, error: 'An analysis is already running.' };

    const task = getTask(s.selectedTask);
    const isSpeaker = task.id === 'speaker';
    const usesReference = isSpeaker && s.speakerMode === 'pair';
    const stages = isSpeaker && s.speakerMode === 'registered'
      ? task.stages.map((st) => (st === 'Loading Reference Audio' ? 'Loading Registered Speaker Reference' : st))
      : task.stages;

    const job = {
      id: createId('job'),
      task: task.id,
      mode: APP_MODE,
      status: 'running',
      startedAt: new Date().toISOString(),
      stages,
      stageIndex: 0,
      live: null,
      options: s.taskOptions[task.id] || null,
      speakerMode: isSpeaker ? s.speakerMode : null,
      speaker: isSpeaker && s.speakerMode === 'registered' ? s.registeredSpeaker : null,
      audio: audioMeta(s.audio),
      reference: usesReference ? audioMeta(s.referenceAudio) : null,
      error: null,
      resultId: null,
    };
    dispatch({ type: 'JOB_START', job });

    const controller = new AbortController();
    abortRef.current = controller;
    const runInput = {
      task: job.task,
      options: job.options,
      speakerMode: job.speakerMode,
      speaker: job.speaker,
      audio: s.audio,
      referenceAudio: usesReference ? s.referenceAudio : null,
    };

    const run = IS_DEMO
      ? runDemoAnalysis(runInput, {
          stages,
          signal: controller.signal,
          onStage: (i) => dispatch({ type: 'JOB_UPDATE', id: job.id, patch: { stageIndex: i } }),
        })
      : runLiveAnalysis(runInput, {
          signal: controller.signal,
          onStatus: (live) => dispatch({ type: 'JOB_UPDATE', id: job.id, patch: { live } }),
          getRemoteId: (entry) => stateRef.current.remoteIds[entry.id],
          setRemoteId: (entry, remoteId) => dispatch({ type: 'SET_REMOTE_ID', entryId: entry.id, remoteId }),
        });

    run
      .then((result) => {
        const record = {
          id: result.analysisId ? String(result.analysisId) : createId('an'),
          task: job.task,
          mode: APP_MODE,
          source: 'browser',
          isDemo: IS_DEMO,
          status: 'completed',
          createdAt: new Date().toISOString(),
          audio: job.audio,
          reference: job.reference,
          speaker: job.speaker,
          speakerMode: job.speakerMode,
          options: job.options,
          result: { ...result, raw: undefined },
          summary: summarize(job.task, result),
        };
        dispatch({ type: 'ADD_HISTORY', record });
        dispatch({
          type: 'JOB_UPDATE',
          id: job.id,
          patch: { status: 'completed', stageIndex: stages.length, resultId: record.id, finishedAt: record.createdAt },
        });
      })
      .catch((err) => {
        const e = normalizeError(err);
        if (e.isCancel || controller.signal.aborted) {
          dispatch({ type: 'JOB_UPDATE', id: job.id, patch: { status: 'cancelled', error: 'Analysis cancelled.' } });
          return;
        }
        dispatch({
          type: 'JOB_UPDATE',
          id: job.id,
          patch: { status: 'failed', error: e.message, errorStatus: e.status, isNetwork: e.isNetwork },
        });
      })
      .finally(() => {
        if (abortRef.current === controller) abortRef.current = null;
      });

    return { ok: true, jobId: job.id };
  }, [getReadiness]);

  const cancelAnalysis = useCallback(() => abortRef.current?.abort(), []);

  /** Add a record fetched from the backend history into the local cache. */
  const importRecord = useCallback((record) => {
    dispatch({ type: 'ADD_HISTORY', record: { ...record, summary: record.summary || summarize(record.task, record.result) } });
  }, []);

  const getRecord = useCallback((id) => stateRef.current.history.find((r) => r.id === id) || null, []);

  const value = useMemo(
    () => ({
      ...state,
      mode: APP_MODE,
      isDemo: IS_DEMO,
      setAudio,
      removeAudio,
      setReferenceAudio,
      removeReferenceAudio,
      enterApp,
      selectTask,
      setTaskOption,
      setSpeakerMode,
      setRegisteredSpeaker,
      getReadiness,
      startAnalysis,
      cancelAnalysis,
      clearCurrentJob,
      clearHistory,
      clearSession,
      resetWorkflow,
      importRecord,
      getRecord,
    }),
    [
      state,
      setAudio,
      removeAudio,
      setReferenceAudio,
      removeReferenceAudio,
      enterApp,
      selectTask,
      setTaskOption,
      setSpeakerMode,
      setRegisteredSpeaker,
      getReadiness,
      startAnalysis,
      cancelAnalysis,
      clearCurrentJob,
      clearHistory,
      clearSession,
      resetWorkflow,
      importRecord,
      getRecord,
    ],
  );

  return <SessionContext.Provider value={value}>{children}</SessionContext.Provider>;
}

export function useSession() {
  const ctx = useContext(SessionContext);
  if (!ctx) throw new Error('useSession must be used inside <AudioProvider>');
  return ctx;
}
