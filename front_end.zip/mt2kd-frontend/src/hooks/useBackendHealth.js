import { useCallback, useEffect, useState } from 'react';
import { IS_LIVE } from '@/config/appConfig';
import { getHealth } from '@/services/api';

/**
 * Live Mode only: checks GET /api/health.
 * In Demo Mode it never touches the network and reports status "demo".
 */
export function useBackendHealth({ intervalMs = 30000 } = {}) {
  const [state, setState] = useState({ status: IS_LIVE ? 'checking' : 'demo', error: null, data: null, checkedAt: null });

  const check = useCallback(async (signal) => {
    if (!IS_LIVE) return;
    setState((s) => ({ ...s, status: 'checking' }));
    try {
      const data = await getHealth(signal);
      setState({ status: 'online', error: null, data, checkedAt: Date.now() });
    } catch (err) {
      if (err?.isCancel) return;
      setState({ status: 'offline', error: err.message, data: null, checkedAt: Date.now() });
    }
  }, []);

  useEffect(() => {
    if (!IS_LIVE) return undefined;
    const controller = new AbortController();
    check(controller.signal);
    const id = setInterval(() => check(), intervalMs);
    return () => {
      controller.abort();
      clearInterval(id);
    };
  }, [check, intervalMs]);

  return { ...state, recheck: () => check() };
}
