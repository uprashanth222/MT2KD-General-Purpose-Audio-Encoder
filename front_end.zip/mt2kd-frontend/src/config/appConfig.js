/**
 * Central runtime configuration.
 * All values come from Vite env variables (see .env.example).
 */
const env = import.meta.env;

const num = (value, fallback) => {
  const n = Number(value);
  return Number.isFinite(n) && n > 0 ? n : fallback;
};

const rawMode = (env.VITE_APP_MODE || (env.MODE === 'live' ? 'live' : 'demo')).toLowerCase();

export const APP_MODE = rawMode === 'live' ? 'live' : 'demo';
export const IS_DEMO = APP_MODE === 'demo';
export const IS_LIVE = APP_MODE === 'live';

export const config = {
  mode: APP_MODE,
  apiBaseUrl: (env.VITE_API_BASE_URL || 'http://localhost:8000').replace(/\/+$/, ''),
  apiTimeoutMs: num(env.VITE_API_TIMEOUT_MS, 120000),
  maxFileSizeMB: num(env.VITE_MAX_FILE_SIZE_MB, 50),
  pollIntervalMs: num(env.VITE_POLL_INTERVAL_MS, 1500),
  pollTimeoutMs: num(env.VITE_POLL_TIMEOUT_MS, 600000),
  demoStageDelayMs: num(env.VITE_DEMO_STAGE_DELAY_MS, 900),
  demoSvThreshold: Math.min(0.99, num(env.VITE_DEMO_SV_THRESHOLD, 0.5)),
  /** Largest file we keep in IndexedDB so a browser refresh can restore it. */
  persistFileLimitMB: 60,
  historyLimit: 50,
};

export const ACCEPTED_FORMATS = {
  wav: ['audio/wav', 'audio/x-wav', 'audio/wave', 'audio/vnd.wave'],
  mp3: ['audio/mpeg', 'audio/mp3', 'audio/mpeg3', 'audio/x-mpeg-3'],
  flac: ['audio/flac', 'audio/x-flac'],
};

export const ACCEPT_ATTR = '.wav,.mp3,.flac,audio/wav,audio/x-wav,audio/mpeg,audio/flac,audio/x-flac';
