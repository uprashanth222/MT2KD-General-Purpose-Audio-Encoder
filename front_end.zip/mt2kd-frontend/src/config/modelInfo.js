/**
 * Static description of the MT2KD architecture, taken from the base paper
 * (Yang, Li, Zhang & Woodland, "MT2KD: Toward a General-Purpose Encoder for
 * Speech, Speaker, and Audio Events", IEEE/ACM TASLP vol. 33, 2025).
 *
 * These are architectural facts only. No accuracy / performance metrics are
 * listed here – real figures must come from the project's own evaluation
 * (Live Mode reads GET /api/models/info).
 */
export const PROJECT = {
  name: 'MT2KD',
  fullName: 'MT2KD – Multi-Task Audio Encoder',
  tagline: 'Multi-Task Knowledge Distillation',
  paper: {
    title: 'MT2KD: Toward a General-Purpose Encoder for Speech, Speaker, and Audio Events',
    authors: 'X. Yang, Q. Li, C. Zhang, P. C. Woodland',
    venue: 'IEEE Transactions on Audio, Speech and Language Processing, vol. 33, 2025',
    doi: '10.1109/TASLPRO.2025.3594300',
  },
};

export const TEACHERS = [
  {
    task: 'asr',
    name: 'Whisper-large-v3',
    role: 'ASR teacher',
    input: '128-D log-mel spectrogram, 10 ms stride',
    output: '1280-D frame embeddings (~50 Hz)',
    kdLoss: 'Frame-level L1 distance',
    note: 'Pairs of frames are concatenated (2560-D, 25 Hz) to match the student frame rate.',
  },
  {
    task: 'tagging',
    name: 'BEATs',
    role: 'Audio tagging teacher',
    input: '16×16 patches of 128-D mel filterbanks',
    output: 'Clip-level logits over sound-event classes',
    kdLoss: 'Binary cross-entropy on sigmoid outputs',
    note: 'Distilled at clip level because the teacher works on patches, not frames.',
  },
  {
    task: 'speaker',
    name: 'ECAPA-TDNN',
    role: 'Speaker verification teacher',
    input: '80-D filterbank features',
    output: '192-D speaker embedding per clip',
    kdLoss: '1 − cosine similarity',
    note: 'Speaker module attaches to an intermediate encoder block, where speaker identity is preserved.',
  },
];

export const STUDENT = {
  name: 'Zipformer-M',
  input: '80-D filterbank features, 25 ms window / 10 ms stride',
  output: '512-D representations at 25 Hz',
  structure: 'Convolutional front-end followed by 6 encoder stacks with different downsampling ratios',
  heads: [
    { task: 'asr', name: 'ASR head', detail: 'Predictor + joiner (neural transducer), Pruned RNN-T loss' },
    { task: 'tagging', name: 'Audio tagging head', detail: 'Linear classifier + sigmoid (multi-label)' },
    { task: 'speaker', name: 'Speaker head', detail: 'Attentive pooling → 192-D embedding, cosine scoring' },
  ],
};

export const STAGES = [
  {
    id: 1,
    title: 'Multi-Teacher Knowledge Distillation',
    body: 'Three frozen teachers supervise one student encoder on unlabelled audio, aligning the feature spaces of ASR, audio tagging and speaker verification.',
    points: ['No ground-truth labels needed', 'One KD loss per teacher', 'Task heads tap different encoder depths'],
  },
  {
    id: 2,
    title: 'Multi-Task Supervised Fine-Tuning',
    body: 'The distilled encoder initialises a multi-task model that is fine-tuned on labelled data, keeping KD losses as auxiliary objectives.',
    points: ['Encoder frozen during warm-up', 'Reduced encoder learning rate', 'Speaker parameters can stay frozen'],
  },
];

/** Datasets configured for this project (from the project brief). */
export const PROJECT_DATASETS = [
  { task: 'asr', name: 'LibriSpeech' },
  { task: 'tagging', name: 'FSD50K' },
  { task: 'speaker', name: 'VoxCeleb1' },
];
