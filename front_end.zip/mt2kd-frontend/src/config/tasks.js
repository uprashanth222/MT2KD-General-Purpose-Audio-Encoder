import { AudioLines, Fingerprint, Mic } from 'lucide-react';

/**
 * Task registry – single source of truth for the three MT2KD capabilities.
 * `stages` are the user-facing pipeline steps shown on the processing screen.
 */
export const TASKS = {
  asr: {
    id: 'asr',
    short: 'ASR',
    title: 'Speech Recognition',
    resultsTitle: 'Speech Recognition Results',
    description: 'Convert spoken audio into readable text using advanced automatic speech recognition.',
    features: ['Speech-to-text', 'Audio transcription', 'Text extraction'],
    cta: 'Select ASR',
    icon: Mic,
    accent: '#7C5CFC',
    accentRgb: '124 92 252',
    teacher: 'Whisper-large-v3',
    head: 'Neural transducer (Pruned RNN-T) on final encoder layer',
    stages: [
      'Loading Audio',
      'Audio Preprocessing',
      'Feature Extraction',
      'Speech Recognition',
      'Generating Transcription',
      'Preparing Results',
    ],
  },
  tagging: {
    id: 'tagging',
    short: 'AT',
    title: 'Audio Tagging',
    resultsTitle: 'Audio Classification Results',
    description: 'Identify and classify sounds, acoustic events and different audio categories.',
    features: ['Sound event detection', 'Audio classification', 'Multiple predicted categories'],
    cta: 'Select Audio Tagging',
    icon: AudioLines,
    accent: '#00C2FF',
    accentRgb: '0 194 255',
    teacher: 'BEATs',
    head: 'Clip-level classification head on final encoder layer',
    stages: [
      'Loading Audio',
      'Audio Preprocessing',
      'Feature Extraction',
      'Audio Classification',
      'Generating Predictions',
      'Preparing Results',
    ],
  },
  speaker: {
    id: 'speaker',
    short: 'SV',
    title: 'Speaker Verification',
    resultsTitle: 'Speaker Verification Results',
    description: 'Compare voice characteristics and determine whether two recordings belong to the same speaker.',
    features: ['Speaker embeddings', 'Voice comparison', 'Match / Non-match decision'],
    cta: 'Select Speaker Verification',
    icon: Fingerprint,
    accent: '#F5B544',
    accentRgb: '245 181 68',
    teacher: 'ECAPA-TDNN',
    head: 'Attentive-pooling speaker module on intermediate encoder block',
    stages: [
      'Loading Reference Audio',
      'Loading Test Audio',
      'Audio Preprocessing',
      'Extracting Speaker Embeddings',
      'Calculating Similarity',
      'Applying Verification Threshold',
      'Preparing Results',
    ],
  },
};

export const TASK_LIST = [TASKS.asr, TASKS.tagging, TASKS.speaker];

export const getTask = (id) => TASKS[id] || null;

export const ASR_DECODING_OPTIONS = [
  { value: 'greedy_search', label: 'Greedy search', hint: 'Fastest decoding' },
  { value: 'modified_beam_search', label: 'Modified beam search', hint: 'Usually more accurate, slower' },
];

export const TAGGING_TOP_K_OPTIONS = [5, 10, 20];
