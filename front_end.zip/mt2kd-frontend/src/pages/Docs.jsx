import { FlaskConical, Radio, FileCode, ListChecks, Settings2 } from 'lucide-react';
import PageHeader from '@/components/ui/PageHeader';
import { ModeBadge } from '@/components/StatusBadge';
import { useSession } from '@/context/AudioContext';
import { config } from '@/config/appConfig';

const ENDPOINTS = [
  ['POST', '/api/audio/upload', 'multipart field "file"', '{ audio_id, filename?, duration? }'],
  ['POST', '/api/asr/process', '{ audio_id, decoding_method }', 'result or { job_id, status }'],
  ['POST', '/api/tagging/process', '{ audio_id, top_k }', 'result or { job_id, status }'],
  ['POST', '/api/speaker/verify', '{ mode, test_audio_id, reference_audio_id | speaker_id }', 'result or { job_id, status }'],
  ['GET', '/api/speaker/registered', '—', '[{ speaker_id, name, num_utterances, reference_available }]'],
  ['GET', '/api/analysis/{analysis_id}', '—', '{ analysis_id, task, status, stage?, stage_index?, result?, error? }'],
  ['GET', '/api/analysis/history', '—', '[{ analysis_id, task, status, created_at, filename, summary? }]'],
  ['GET', '/api/models/status', '—', 'free-form object, shown as reported'],
  ['GET', '/api/models/info', '—', 'free-form object, shown as reported'],
  ['GET', '/api/health', '—', '200 OK when the server is up'],
];

const RESULTS = [
  ['ASR', '{ "transcription": "…", "decoding_method": "greedy_search", "processing_time_ms": 412, "model": { "name": "…", "version": "…" } }'],
  ['Tagging', '{ "predictions": [{ "label": "Speech", "score": 0.91 }, …], "top_k": 10, "processing_time_ms": 230 }'],
  ['Speaker', '{ "similarity": 0.71, "threshold": 0.45, "decision": "match", "metric": "cosine", "processing_time_ms": 180 }'],
];

function Section({ icon: Icon, title, children }) {
  return (
    <section className="panel p-6">
      <h2 className="flex items-center gap-2 font-semibold">
        <Icon className="size-4 text-primary-soft" /> {title}
      </h2>
      <div className="mt-4 space-y-3 text-sm leading-relaxed text-muted">{children}</div>
    </section>
  );
}

const Code = ({ children }) => <code className="rounded bg-white/[0.06] px-1.5 py-0.5 font-mono text-[12.5px] text-fg">{children}</code>;

export default function Docs() {
  const { mode } = useSession();
  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Documentation"
        title="Using MT2KD"
        subtitle="How the interface works, the two runtime modes and the API contract the frontend expects from the FastAPI backend."
        actions={<ModeBadge mode={mode} />}
      />

      <Section icon={ListChecks} title="Quick start">
        <ol className="list-decimal space-y-1.5 pl-5">
          <li>Upload a WAV, MP3 or FLAC file (up to {config.maxFileSizeMB} MB). It is reused for all tasks in this session.</li>
          <li>Choose Speech Recognition, Audio Tagging or Speaker Verification and configure it.</li>
          <li>Start the analysis, follow the processing status and explore the results dashboard.</li>
          <li>Use “Explore Another Task” to run a different capability on the same audio.</li>
        </ol>
        <p>
          Refreshing the page keeps your workflow. Audio files are copied to temporary browser storage (IndexedDB) for this tab; if that
          copy is unavailable you will be asked to re-select the file.
        </p>
      </Section>

      <div className="grid gap-5 md:grid-cols-2">
        <Section icon={FlaskConical} title="Demo Mode (default)">
          <p>
            <Code>VITE_APP_MODE=demo</Code> — runs entirely in the browser. Processing stages are simulated with configurable delays and
            results are clearly labelled sample data, never model predictions. No network requests are made.
          </p>
        </Section>
        <Section icon={Radio} title="Live Mode">
          <p>
            <Code>VITE_APP_MODE=live</Code> with <Code>VITE_API_BASE_URL</Code> (currently <Code>{config.apiBaseUrl}</Code>). Audio is
            uploaded once and reused by id. Results, decisions and scores come only from the backend; if it is unreachable the UI shows
            an error instead of a result.
          </p>
        </Section>
      </div>

      <Section icon={FileCode} title="Expected API contract">
        <p>
          The frontend accepts either a synchronous result or a job id. With a job id it polls <Code>GET /api/analysis/{'{id}'}</Code>{' '}
          every {config.pollIntervalMs} ms until <Code>status</Code> is <Code>completed</Code> or <Code>failed</Code>. Optional{' '}
          <Code>stage</Code>/<Code>stage_index</Code> fields drive the step indicator; without them an indeterminate indicator is shown.
          Errors should use FastAPI&apos;s <Code>{'{ "detail": … }'}</Code> format.
        </p>
        <div className="-mx-2 overflow-x-auto">
          <table className="w-full min-w-[720px] text-left text-[13px]">
            <thead className="text-xs uppercase tracking-wider text-subtle">
              <tr>
                <th className="px-2 py-2 font-medium">Method</th>
                <th className="px-2 py-2 font-medium">Endpoint</th>
                <th className="px-2 py-2 font-medium">Request</th>
                <th className="px-2 py-2 font-medium">Response</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/[0.05]">
              {ENDPOINTS.map(([m, path, req, res]) => (
                <tr key={path}>
                  <td className="px-2 py-2.5 font-mono text-xs text-accent">{m}</td>
                  <td className="px-2 py-2.5 font-mono text-xs text-fg">{path}</td>
                  <td className="px-2 py-2.5 font-mono text-xs">{req}</td>
                  <td className="px-2 py-2.5 font-mono text-xs">{res}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="eyebrow pt-2">Result payloads</div>
        <div className="space-y-2">
          {RESULTS.map(([k, v]) => (
            <div key={k} className="rounded-xl border border-line bg-ink-900/60 p-3">
              <div className="mb-1 text-xs text-subtle">{k}</div>
              <pre className="overflow-x-auto whitespace-pre-wrap break-all font-mono text-xs text-fg/90">{v}</pre>
            </div>
          ))}
        </div>
        <p>
          A speaker verification result must include a backend <Code>decision</Code> (or boolean <Code>is_match</Code>). The frontend never
          derives the decision itself.
        </p>
      </Section>

      <Section icon={Settings2} title="Configuration">
        <p>
          All settings live in <Code>.env</Code> — see <Code>.env.example</Code>: mode, API URL, upload size limit, request timeout, polling
          interval and timeout, demo stage delay and demo threshold.
        </p>
      </Section>
    </div>
  );
}
