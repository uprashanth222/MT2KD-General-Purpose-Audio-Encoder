import { useCallback, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { ArrowLeft, ArrowRight, AudioLines, CircleAlert, CloudUpload, FlaskConical, RefreshCw, UserRound, Users, Check } from 'lucide-react';
import PageHeader from '@/components/ui/PageHeader';
import Button from '@/components/ui/Button';
import EmptyState, { LoadingBlock } from '@/components/ui/EmptyState';
import AudioPlayer, { AudioSlot } from '@/components/AudioPlayer';
import { ModeBadge } from '@/components/StatusBadge';
import { useSession } from '@/context/AudioContext';
import { TASKS } from '@/config/tasks';
import { DEMO_REGISTERED_SPEAKERS } from '@/services/demoService';
import { getRegisteredSpeakers } from '@/services/api';
import { cn } from '@/utils/format';

const SV = TASKS.speaker;
const REF_ACCENT = '#00C2FF';

function OptionCard({ selected, onClick, icon: Icon, label, title, body, testId }) {
  return (
    <motion.button
      type="button"
      role="radio"
      aria-checked={selected}
      onClick={onClick}
      whileHover={{ y: -3 }}
      data-testid={testId}
      className={cn(
        'relative flex h-full flex-col items-start rounded-2xl border bg-card p-6 text-left transition-colors',
        selected ? 'border-transparent' : 'border-line hover:border-line-strong',
      )}
      style={selected ? { boxShadow: `0 0 0 1.5px rgb(${SV.accentRgb}), 0 16px 40px -18px rgb(${SV.accentRgb} / 0.6)` } : undefined}
    >
      <div className="flex w-full items-center justify-between">
        <div className="flex size-12 items-center justify-center rounded-xl" style={{ background: `rgb(${SV.accentRgb} / 0.14)` }}>
          <Icon className="size-5" style={{ color: SV.accent }} />
        </div>
        <span
          className={cn(
            'flex size-6 items-center justify-center rounded-full border transition-colors',
            selected ? 'border-transparent text-ink-950' : 'border-line-strong',
          )}
          style={selected ? { background: SV.accent } : undefined}
        >
          {selected && <Check className="size-3.5" strokeWidth={3} />}
        </span>
      </div>
      <div className="eyebrow mt-5">{label}</div>
      <h3 className="mt-1.5 text-lg font-semibold">{title}</h3>
      <p className="mt-2 text-sm leading-relaxed text-muted">{body}</p>
    </motion.button>
  );
}

function SpeakerProfile({ speaker, selected, onSelect }) {
  const disabled = speaker.referenceAvailable === false;
  return (
    <button
      type="button"
      onClick={() => !disabled && onSelect(speaker)}
      disabled={disabled}
      aria-pressed={selected}
      className={cn(
        'flex w-full items-start gap-4 rounded-xl border p-4 text-left transition-colors disabled:opacity-50',
        selected ? 'bg-amber/[0.07]' : 'border-line hover:border-line-strong hover:bg-white/[0.02]',
      )}
      style={selected ? { borderColor: SV.accent } : undefined}
    >
      <div className="flex size-11 shrink-0 items-center justify-center rounded-full bg-white/[0.06]">
        <UserRound className="size-5 text-muted" />
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-2">
          <span className="font-medium">{speaker.displayName}</span>
          {speaker.isDemo && (
            <span className="inline-flex items-center gap-1 rounded-md border border-amber/40 bg-amber/10 px-1.5 py-0.5 font-mono text-[10px] uppercase tracking-wider text-amber">
              <FlaskConical className="size-3" /> Demo sample
            </span>
          )}
        </div>
        {speaker.description && <p className="mt-1 text-xs text-muted">{speaker.description}</p>}
        <dl className="mt-3 grid grid-cols-1 gap-x-6 gap-y-1.5 text-xs sm:grid-cols-3">
          <div>
            <dt className="text-subtle">Speaker ID</dt>
            <dd className="font-mono text-fg">{speaker.id}</dd>
          </div>
          <div>
            <dt className="text-subtle">Reference audio</dt>
            <dd className={disabled ? 'text-danger' : 'text-fg'}>{speaker.referenceStatus || '—'}</dd>
          </div>
          <div>
            <dt className="text-subtle">Enrolled utterances</dt>
            <dd className="font-mono text-fg">{speaker.enrolledUtterances ?? '—'}</dd>
          </div>
        </dl>
      </div>
      {selected && <Check className="size-5 shrink-0" style={{ color: SV.accent }} />}
    </button>
  );
}

function RegisteredSpeakers({ isDemo, selected, onSelect }) {
  const [state, setState] = useState({ status: isDemo ? 'ready' : 'loading', items: isDemo ? DEMO_REGISTERED_SPEAKERS : [], error: null });

  const load = useCallback(async (signal) => {
    if (isDemo) return;
    setState((s) => ({ ...s, status: 'loading', error: null }));
    try {
      const items = await getRegisteredSpeakers(signal);
      setState({ status: 'ready', items, error: null });
    } catch (err) {
      if (err?.isCancel) return;
      setState({ status: 'error', items: [], error: err.message });
    }
  }, [isDemo]);

  useEffect(() => {
    const c = new AbortController();
    load(c.signal);
    return () => c.abort();
  }, [load]);

  // Drop a stale selection that is not in the current list (e.g. demo profile after switching modes).
  useEffect(() => {
    if (state.status === 'ready' && selected && !state.items.some((s) => s.id === selected.id)) onSelect(null);
  }, [state, selected, onSelect]);

  if (state.status === 'loading') return <LoadingBlock label="Loading registered speakers from the backend…" />;
  if (state.status === 'error') {
    return (
      <div className="rounded-xl border border-danger/30 bg-danger/10 p-4 text-sm">
        <div className="flex items-start gap-2.5 text-red-200">
          <CircleAlert className="mt-0.5 size-4 shrink-0 text-danger" />
          <div>
            <div className="font-medium text-fg">Could not load registered speakers</div>
            <p className="mt-1">{state.error}</p>
          </div>
        </div>
        <Button variant="secondary" size="sm" icon={RefreshCw} className="mt-3" onClick={() => load()}>
          Retry
        </Button>
      </div>
    );
  }
  if (!state.items.length) {
    return <p className="rounded-xl border border-line p-4 text-sm text-muted">The backend has no registered speakers yet.</p>;
  }
  return (
    <div className="space-y-3">
      {isDemo && (
        <p className="flex items-center gap-2 text-xs text-amber">
          <FlaskConical className="size-3.5" /> These are sample profiles for Demo Mode — not real enrolled identities.
        </p>
      )}
      {state.items.map((s) => (
        <SpeakerProfile key={s.id} speaker={s} selected={selected?.id === s.id} onSelect={onSelect} />
      ))}
    </div>
  );
}

export default function SpeakerVerification() {
  const navigate = useNavigate();
  const {
    audio,
    restoring,
    selectedTask,
    selectTask,
    speakerMode,
    setSpeakerMode,
    referenceAudio,
    setReferenceAudio,
    removeReferenceAudio,
    setAudio,
    registeredSpeaker,
    setRegisteredSpeaker,
    getReadiness,
    startAnalysis,
    isDemo,
    mode,
    currentJob,
  } = useSession();
  const [error, setError] = useState(null);

  useEffect(() => {
    if (audio && selectedTask !== 'speaker') selectTask('speaker');
  }, [audio, selectedTask, selectTask]);

  if (restoring) return <LoadingBlock label="Restoring your session…" />;
  if (!audio) {
    return (
      <EmptyState
        icon={CloudUpload}
        title="Upload audio first"
        body="Speaker verification uses your session audio as the test recording."
        action={<Button to="/upload" icon={CloudUpload}>Upload audio</Button>}
      />
    );
  }

  const readiness = getReadiness();
  const running = currentJob?.status === 'running';

  const start = () => {
    setError(null);
    const res = startAnalysis();
    if (res.ok) navigate('/processing');
    else setError(res.error);
  };

  const testCard = (
    <AudioPlayer
      entry={audio}
      role="Test audio · session file"
      accent={SV.accent}
      onReplace={setAudio}
      replaceNote="Replacing the test audio also replaces your session audio for the other tasks."
      waveHeight={64}
    />
  );

  return (
    <div>
      <PageHeader
        eyebrow="Step 3 · Configure SV"
        title="Speaker Verification"
        subtitle="Choose how you want to verify the speaker."
        actions={
          <>
            <ModeBadge mode={mode} />
            <Button variant="ghost" icon={ArrowLeft} to="/tasks">
              Tasks
            </Button>
          </>
        }
      />

      <div role="radiogroup" aria-label="Verification method" className="grid gap-5 md:grid-cols-2">
        <OptionCard
          testId="sv-mode-pair"
          selected={speakerMode === 'pair'}
          onClick={() => setSpeakerMode('pair')}
          icon={AudioLines}
          label="Option A"
          title="Reference Audio + Test Audio"
          body="Provide a reference recording of the claimed speaker. Your session audio is used as the test audio."
        />
        <OptionCard
          testId="sv-mode-registered"
          selected={speakerMode === 'registered'}
          onClick={() => setSpeakerMode('registered')}
          icon={Users}
          label="Option B"
          title="Pre-Registered Speaker"
          body="Compare your uploaded audio against a predefined speaker reference stored in the system."
        />
      </div>

      <AnimatePresence mode="wait">
        {speakerMode && (
          <motion.section
            key={speakerMode}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 8 }}
            transition={{ duration: 0.25 }}
            className="mt-8"
          >
            {speakerMode === 'pair' ? (
              <div className="grid gap-5 lg:grid-cols-2">
                <div>
                  <h2 className="mb-3 text-sm font-semibold text-muted">Reference audio</h2>
                  <AudioSlot
                    entry={referenceAudio}
                    onFile={setReferenceAudio}
                    onRemove={removeReferenceAudio}
                    role="Reference audio"
                    accent={REF_ACCENT}
                    title="Upload Reference Audio"
                    hint="A recording of the speaker you want to verify against."
                    inputId="reference-audio-input"
                  />
                </div>
                <div>
                  <h2 className="mb-3 text-sm font-semibold text-muted">Test audio</h2>
                  {testCard}
                </div>
              </div>
            ) : (
              <div className="grid gap-5 lg:grid-cols-[1.25fr_1fr]">
                <div>
                  <h2 className="mb-3 text-sm font-semibold text-muted">Registered speaker</h2>
                  <RegisteredSpeakers isDemo={isDemo} selected={registeredSpeaker} onSelect={setRegisteredSpeaker} />
                </div>
                <div>
                  <h2 className="mb-3 text-sm font-semibold text-muted">Test audio</h2>
                  {testCard}
                </div>
              </div>
            )}
          </motion.section>
        )}
      </AnimatePresence>

      <div className="sticky bottom-20 z-10 mt-8 lg:bottom-6">
        <div className="glass flex flex-col gap-3 rounded-2xl p-4 sm:flex-row sm:items-center sm:justify-between">
          <p className={cn('flex items-center gap-2 text-sm', readiness.ok ? 'text-success' : 'text-muted')}>
            {readiness.ok ? <Check className="size-4" /> : <CircleAlert className="size-4" />}
            {readiness.ok ? 'Ready to verify.' : readiness.reason}
          </p>
          <Button
            size="lg"
            iconRight={ArrowRight}
            disabled={!readiness.ok || running}
            onClick={start}
            data-testid="start-verification"
          >
            Continue to Verification
          </Button>
        </div>
        {error && (
          <div role="alert" className="mt-2 flex items-center gap-2 text-sm text-danger">
            <CircleAlert className="size-4" /> {error}
          </div>
        )}
      </div>
    </div>
  );
}
