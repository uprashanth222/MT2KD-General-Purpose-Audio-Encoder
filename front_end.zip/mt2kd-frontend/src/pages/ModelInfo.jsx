import { useCallback, useEffect, useState } from 'react';
import { CircleAlert, Database, FlaskConical, GraduationCap, Layers, RefreshCw, Server, Snowflake, Cpu } from 'lucide-react';
import PageHeader from '@/components/ui/PageHeader';
import Button from '@/components/ui/Button';
import ArchitectureDiagram from '@/components/ArchitectureDiagram';
import ResultCard, { DetailList } from '@/components/ResultCard';
import { ModeBadge } from '@/components/StatusBadge';
import { useSession } from '@/context/AudioContext';
import { TASKS } from '@/config/tasks';
import { PROJECT, PROJECT_DATASETS, STAGES, STUDENT, TEACHERS } from '@/config/modelInfo';
import { getModelsInfo, getModelsStatus } from '@/services/api';

const stringify = (v) => {
  if (v === null || v === undefined) return '—';
  if (typeof v === 'boolean') return v ? 'yes' : 'no';
  if (typeof v === 'object') return JSON.stringify(v);
  return String(v);
};

/** Live Mode: show exactly what the backend reports – nothing more. */
function LiveModelPanel() {
  const [state, setState] = useState({ status: 'loading', info: null, modelStatus: null, error: null });

  const load = useCallback(async (signal) => {
    setState((s) => ({ ...s, status: 'loading', error: null }));
    const [info, status] = await Promise.allSettled([getModelsInfo(signal), getModelsStatus(signal)]);
    if (signal?.aborted) return;
    if (info.status === 'rejected' && status.status === 'rejected') {
      setState({ status: 'error', info: null, modelStatus: null, error: info.reason?.message || 'Backend unavailable.' });
      return;
    }
    setState({
      status: 'ready',
      info: info.status === 'fulfilled' ? info.value : null,
      modelStatus: status.status === 'fulfilled' ? status.value : null,
      error: null,
    });
  }, []);

  useEffect(() => {
    const c = new AbortController();
    load(c.signal);
    return () => c.abort();
  }, [load]);

  const toItems = (obj) =>
    obj && typeof obj === 'object' ? Object.entries(obj).slice(0, 14).map(([k, v]) => ({ label: k, value: stringify(v) })) : [];

  return (
    <ResultCard
      title="Backend model status"
      icon={Server}
      actions={
        <Button size="sm" variant="ghost" icon={RefreshCw} onClick={() => load()}>
          Refresh
        </Button>
      }
    >
      {state.status === 'loading' && <div className="skeleton h-24 rounded-xl" />}
      {state.status === 'error' && (
        <div className="flex items-start gap-2 text-sm text-red-200">
          <CircleAlert className="mt-0.5 size-4 shrink-0 text-danger" />
          {state.error}
        </div>
      )}
      {state.status === 'ready' && (
        <div className="grid gap-6 md:grid-cols-2">
          <div>
            <div className="eyebrow mb-3">GET /api/models/status</div>
            {state.modelStatus ? <DetailList items={toItems(state.modelStatus)} /> : <p className="text-sm text-muted">Not available.</p>}
          </div>
          <div>
            <div className="eyebrow mb-3">GET /api/models/info</div>
            {state.info ? <DetailList items={toItems(state.info)} /> : <p className="text-sm text-muted">Not available.</p>}
          </div>
        </div>
      )}
    </ResultCard>
  );
}

export default function ModelInfo() {
  const { isDemo, mode } = useSession();

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Model information"
        title={PROJECT.fullName}
        subtitle="One compact student encoder learns from three specialist teachers, then serves speech recognition, audio tagging and speaker verification through task-specific heads."
        actions={<ModeBadge mode={mode} />}
      />

      {isDemo ? (
        <div className="flex items-start gap-3 rounded-2xl border border-amber/30 bg-amber/[0.07] px-4 py-3.5 text-sm text-amber">
          <FlaskConical className="mt-0.5 size-4 shrink-0" />
          Demo Mode: no backend is connected, so live model status and checkpoint details are not shown. The architecture below is the
          design described in the base paper.
        </div>
      ) : (
        <LiveModelPanel />
      )}

      <ResultCard title="Architecture" icon={Layers}>
        <ArchitectureDiagram />
      </ResultCard>

      <div className="grid gap-5 md:grid-cols-2">
        {STAGES.map((s) => (
          <div key={s.id} className="panel p-6">
            <div className="flex items-center gap-3">
              <span className="flex size-9 items-center justify-center rounded-xl bg-primary/15 font-mono text-sm text-primary-soft">
                {s.id}
              </span>
              <h3 className="text-lg font-semibold">{s.title}</h3>
            </div>
            <p className="mt-3 text-sm leading-relaxed text-muted">{s.body}</p>
            <ul className="mt-4 space-y-1.5">
              {s.points.map((p) => (
                <li key={p} className="flex items-center gap-2 text-sm">
                  <span className="size-1.5 rounded-full bg-accent" /> {p}
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      <section>
        <h2 className="mb-4 flex items-center gap-2 text-lg font-semibold">
          <Snowflake className="size-4 text-accent" /> Teacher models
        </h2>
        <div className="grid gap-5 md:grid-cols-3">
          {TEACHERS.map((t) => {
            const task = TASKS[t.task];
            return (
              <div key={t.name} className="panel relative overflow-hidden p-6">
                <div className="absolute inset-x-0 top-0 h-[3px]" style={{ background: task.accent }} />
                <div className="flex items-center gap-2 text-xs" style={{ color: task.accent }}>
                  <task.icon className="size-3.5" /> {t.role}
                </div>
                <h3 className="mt-2 text-lg font-semibold">{t.name}</h3>
                <div className="mt-4">
                  <DetailList
                    items={[
                      { label: 'Input', value: t.input, mono: false },
                      { label: 'Output', value: t.output, mono: false },
                      { label: 'KD loss', value: t.kdLoss, mono: false },
                    ]}
                  />
                </div>
                <p className="mt-4 text-xs leading-relaxed text-subtle">{t.note}</p>
              </div>
            );
          })}
        </div>
      </section>

      <div className="grid gap-5 lg:grid-cols-[1.4fr_1fr]">
        <ResultCard title={`Student model · ${STUDENT.name}`} icon={GraduationCap}>
          <DetailList
            items={[
              { label: 'Input', value: STUDENT.input, mono: false },
              { label: 'Output', value: STUDENT.output, mono: false },
              { label: 'Structure', value: STUDENT.structure, mono: false },
            ]}
          />
          <div className="eyebrow mb-3 mt-6">Task-specific heads</div>
          <ul className="space-y-2.5">
            {STUDENT.heads.map((h) => {
              const task = TASKS[h.task];
              return (
                <li key={h.name} className="flex items-start gap-3 rounded-xl border border-line p-3">
                  <task.icon className="mt-0.5 size-4 shrink-0" style={{ color: task.accent }} />
                  <div>
                    <div className="text-sm font-medium">{h.name}</div>
                    <div className="text-xs text-muted">{h.detail}</div>
                  </div>
                </li>
              );
            })}
          </ul>
        </ResultCard>

        <div className="space-y-5">
          <ResultCard title="Project datasets" icon={Database}>
            <ul className="space-y-2.5">
              {PROJECT_DATASETS.map((d) => {
                const task = TASKS[d.task];
                return (
                  <li key={d.name} className="flex items-center justify-between gap-3 text-sm">
                    <span className="flex items-center gap-2 text-muted">
                      <task.icon className="size-3.5" style={{ color: task.accent }} /> {task.title}
                    </span>
                    <span className="font-mono text-[13px]">{d.name}</span>
                  </li>
                );
              })}
            </ul>
            <p className="mt-4 text-xs leading-relaxed text-subtle">
              The base paper used AudioSet for audio tagging and VoxCeleb1 + VoxCeleb2 for speaker verification.
            </p>
          </ResultCard>
          <ResultCard title="Evaluation results" icon={Cpu}>
            <p className="text-sm leading-relaxed text-muted">
              No accuracy figures are shown in this interface. Results (WER, mAP, EER) will be reported here once they are produced by
              this project&apos;s own evaluation{isDemo ? '' : ' and exposed by the backend'}.
            </p>
          </ResultCard>
        </div>
      </div>
    </div>
  );
}
