import { useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { ArrowRight, CloudUpload, Play, CircleAlert } from 'lucide-react';
import PageHeader from '@/components/ui/PageHeader';
import TaskCard from '@/components/TaskCard';
import Button from '@/components/ui/Button';
import EmptyState, { LoadingBlock } from '@/components/ui/EmptyState';
import SessionAudioBar from '@/components/SessionAudioBar';
import { useSession } from '@/context/AudioContext';
import { ASR_DECODING_OPTIONS, TAGGING_TOP_K_OPTIONS, TASK_LIST, getTask } from '@/config/tasks';
import { cn } from '@/utils/format';

function Segmented({ options, value, onChange, accentRgb, name }) {
  return (
    <div role="radiogroup" aria-label={name} className="flex flex-wrap gap-2">
      {options.map((o) => {
        const active = o.value === value;
        return (
          <button
            key={o.value}
            type="button"
            role="radio"
            aria-checked={active}
            onClick={() => onChange(o.value)}
            className={cn(
              'rounded-xl border px-4 py-2.5 text-left text-sm transition-colors',
              active ? 'text-fg' : 'border-line-strong text-muted hover:text-fg',
            )}
            style={active ? { borderColor: `rgb(${accentRgb})`, background: `rgb(${accentRgb} / 0.12)` } : undefined}
          >
            <div className="font-medium">{o.label}</div>
            {o.hint && <div className="mt-0.5 text-xs text-subtle">{o.hint}</div>}
          </button>
        );
      })}
    </div>
  );
}

export default function TaskSelection() {
  const navigate = useNavigate();
  const {
    audio,
    restoring,
    selectedTask,
    selectTask,
    taskOptions,
    setTaskOption,
    startAnalysis,
    getReadiness,
    history,
    currentJob,
  } = useSession();
  const [error, setError] = useState(null);
  const configRef = useRef(null);

  const lastResults = useMemo(() => {
    const map = {};
    if (!audio) return map;
    for (const r of history) {
      if (r.audio?.id === audio.id && r.status === 'completed' && !map[r.task]) map[r.task] = r.id;
    }
    return map;
  }, [history, audio]);

  if (restoring) return <LoadingBlock label="Restoring your session…" />;

  if (!audio) {
    return (
      <EmptyState
        icon={CloudUpload}
        title="Upload audio to get started"
        body="Every task runs on the audio you upload once at the start of the session."
        action={
          <Button to="/upload" icon={CloudUpload}>
            Upload audio
          </Button>
        }
      />
    );
  }

  const task = getTask(selectedTask);
  const running = currentJob?.status === 'running';

  const start = () => {
    setError(null);
    const res = startAnalysis();
    if (res.ok) navigate('/processing');
    else setError(res.error);
  };

  const readiness = getReadiness();
  const audioReady = !audio.missingFile;

  return (
    <div>
      <PageHeader
        eyebrow="Step 2 · Task"
        title="Choose Your Audio Intelligence Task"
        subtitle="Select the AI capability you want to perform on your uploaded audio."
      />
      <SessionAudioBar audio={audio} />

      <div role="radiogroup" aria-label="Audio intelligence task" className="grid gap-5 md:grid-cols-3">
        {TASK_LIST.map((t) => (
          <TaskCard
            key={t.id}
            task={t}
            selected={selectedTask === t.id}
            onSelect={(id) => {
              setError(null);
              selectTask(id);
              // On small screens the configuration panel sits below the cards – bring it into view.
              setTimeout(() => configRef.current?.scrollIntoView({ behavior: 'smooth', block: 'nearest' }), 80);
            }}
            lastResultId={lastResults[t.id]}
          />
        ))}
      </div>

      <AnimatePresence mode="wait">
        {task && (
          <motion.section
            key={task.id}
            ref={configRef}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 8 }}
            transition={{ duration: 0.25 }}
            className="panel mt-6 p-5 sm:p-6"
            aria-label={`${task.title} configuration`}
          >
            <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
              <div className="min-w-0 flex-1">
                <div className="eyebrow mb-2" style={{ color: task.accent }}>
                  Step 3 · Configure {task.short}
                </div>
                {task.id === 'asr' && (
                  <>
                    <h2 className="mb-4 text-lg font-semibold">Decoding method</h2>
                    <Segmented
                      name="Decoding method"
                      options={ASR_DECODING_OPTIONS}
                      value={taskOptions.asr?.decodingMethod}
                      onChange={(v) => setTaskOption('asr', 'decodingMethod', v)}
                      accentRgb={task.accentRgb}
                    />
                  </>
                )}
                {task.id === 'tagging' && (
                  <>
                    <h2 className="mb-4 text-lg font-semibold">Number of top predictions to highlight</h2>
                    <Segmented
                      name="Top predictions"
                      options={TAGGING_TOP_K_OPTIONS.map((k) => ({ value: k, label: `Top ${k}` }))}
                      value={taskOptions.tagging?.topK}
                      onChange={(v) => setTaskOption('tagging', 'topK', v)}
                      accentRgb={task.accentRgb}
                    />
                  </>
                )}
                {task.id === 'speaker' && (
                  <>
                    <h2 className="text-lg font-semibold">Choose a verification method next</h2>
                    <p className="mt-1.5 text-sm text-muted">
                      Compare your audio with a reference recording, or against a registered speaker profile.
                    </p>
                  </>
                )}
              </div>

              <div className="flex shrink-0 flex-col items-stretch gap-2 sm:items-end">
                {task.id === 'speaker' ? (
                  <Button size="lg" iconRight={ArrowRight} disabled={!audioReady} onClick={() => navigate('/speaker')}>
                    Configure Verification
                  </Button>
                ) : (
                  <Button size="lg" icon={Play} disabled={!readiness.ok || running} onClick={start} data-testid="start-analysis">
                    Start Analysis
                  </Button>
                )}
                {running && <span className="text-xs text-muted">An analysis is already running.</span>}
              </div>
            </div>
            {error && (
              <div role="alert" className="mt-4 flex items-center gap-2 text-sm text-danger">
                <CircleAlert className="size-4" /> {error}
              </div>
            )}
          </motion.section>
        )}
      </AnimatePresence>
    </div>
  );
}
