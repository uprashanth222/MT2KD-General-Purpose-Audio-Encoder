import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowRight, CloudUpload, LayoutGrid, ChartColumn, Sparkles } from 'lucide-react';
import UploadPanel from '@/components/UploadPanel';
import AnimatedWave from '@/components/AnimatedWave';
import { TASK_LIST } from '@/config/tasks';

const fade = (delay = 0) => ({
  initial: { opacity: 0, y: 14 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.5, delay, ease: [0.22, 1, 0.36, 1] },
});

const STEPS = [
  { icon: CloudUpload, title: 'Upload once', body: 'Drop a WAV, MP3 or FLAC file. It stays available for the whole session.' },
  { icon: LayoutGrid, title: 'Pick a capability', body: 'Run speech recognition, audio tagging or speaker verification on the same file.' },
  { icon: ChartColumn, title: 'Explore results', body: 'Read, chart and export results, then switch tasks without re-uploading.' },
];

export default function Landing() {
  return (
    <div className="space-y-20 sm:space-y-24">
      {/* Hero */}
      <section className="grid items-start gap-10 lg:grid-cols-[1.05fr_1fr] lg:gap-14">
        <div className="lg:pt-6">
          <motion.div {...fade(0)} className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-3 py-1 text-xs text-primary-soft">
            <Sparkles className="size-3.5" /> Multi-Task Knowledge Distillation
          </motion.div>
          <motion.h1 {...fade(0.05)} className="mt-6 text-[40px] font-semibold leading-[1.05] sm:text-[54px]">
            One Audio.
            <br />
            <span className="text-gradient">Three Intelligent Capabilities.</span>
          </motion.h1>
          <motion.p {...fade(0.1)} className="mt-6 max-w-xl text-lg leading-relaxed text-fg/85">
            Experience next-generation audio intelligence powered by a unified multi-task deep learning architecture.
          </motion.p>
          <motion.p {...fade(0.15)} className="mt-3 max-w-xl leading-relaxed text-muted">
            Upload your audio and unlock speech recognition, sound classification and speaker verification through one
            intelligent platform.
          </motion.p>

          <motion.div {...fade(0.2)} className="mt-8 flex flex-wrap gap-2.5">
            {TASK_LIST.map(({ id, title, icon: Icon, accent }) => (
              <span key={id} className="inline-flex items-center gap-2 rounded-xl border border-line bg-card/60 px-3 py-2 text-sm">
                <Icon className="size-4" style={{ color: accent }} />
                {title}
              </span>
            ))}
          </motion.div>

          <motion.div {...fade(0.25)} className="mt-10 hidden items-end gap-5 lg:flex">
            <AnimatedWave bars={40} height={64} />
            <div className="pb-1 font-mono text-[11px] leading-5 text-subtle">
              shared encoder
              <br />→ ASR · AT · SV
            </div>
          </motion.div>
        </div>

        <motion.div {...fade(0.15)} className="glass relative rounded-3xl p-4 sm:p-6">
          <div className="pointer-events-none absolute -inset-px -z-10 rounded-3xl bg-[linear-gradient(140deg,rgb(124_92_252/0.35),transparent_40%,rgb(0_194_255/0.25))] blur-2xl" />
          <div className="mb-4 flex items-center justify-between px-1">
            <h2 className="text-base font-semibold">Start with your audio</h2>
            <span className="font-mono text-[11px] text-subtle">STEP 1 / 3</span>
          </div>
          <UploadPanel />
        </motion.div>
      </section>

      {/* How it works */}
      <section>
        <div className="eyebrow mb-4">How it works</div>
        <div className="grid gap-4 md:grid-cols-3">
          {STEPS.map(({ icon: Icon, title, body }, i) => (
            <motion.div
              key={title}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ duration: 0.45, delay: i * 0.08 }}
              className="panel p-6"
            >
              <div className="flex items-center justify-between">
                <div className="flex size-10 items-center justify-center rounded-xl bg-white/[0.05]">
                  <Icon className="size-5 text-primary-soft" />
                </div>
                <span className="font-mono text-xs text-subtle">0{i + 1}</span>
              </div>
              <h3 className="mt-5 text-lg font-semibold">{title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted">{body}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Architecture teaser */}
      <section className="panel relative overflow-hidden p-6 sm:p-10">
        <div className="grid-bg pointer-events-none absolute inset-0" />
        <div className="relative grid gap-8 md:grid-cols-[1.2fr_1fr] md:items-center">
          <div>
            <div className="eyebrow mb-3">Under the hood</div>
            <h2 className="text-2xl font-semibold sm:text-3xl">Three specialist teachers. One compact student.</h2>
            <p className="mt-3 max-w-lg leading-relaxed text-muted">
              MT2KD distils Whisper-large-v3, BEATs and ECAPA-TDNN into a single Zipformer-M encoder, then fine-tunes it with
              task-specific heads for transcription, sound events and speaker identity.
            </p>
            <Link to="/models" className="mt-5 inline-flex items-center gap-2 text-sm font-medium text-accent hover:underline">
              Explore the architecture <ArrowRight className="size-4" />
            </Link>
          </div>
          <div className="flex flex-col gap-2 font-mono text-xs">
            {TASK_LIST.map((t) => (
              <div key={t.id} className="flex items-center gap-3">
                <span className="w-40 truncate rounded-lg border border-line bg-ink-900/80 px-3 py-2 text-muted">{t.teacher}</span>
                <span className="h-px flex-1 border-t border-dashed" style={{ borderColor: t.accent }} />
                <span className="rounded-lg px-3 py-2 text-fg" style={{ background: `rgb(${t.accentRgb} / 0.14)` }}>
                  {t.short} head
                </span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <footer className="flex flex-col items-center justify-between gap-3 border-t border-white/[0.05] pt-8 text-xs text-subtle sm:flex-row">
        <span>MT2KD – Multi-Task Audio Intelligence Platform · research project</span>
        <span className="flex gap-4">
          <Link to="/docs" className="hover:text-fg">Documentation</Link>
          <Link to="/about" className="hover:text-fg">About</Link>
          <Link to="/models" className="hover:text-fg">Model</Link>
        </span>
      </footer>
    </div>
  );
}
