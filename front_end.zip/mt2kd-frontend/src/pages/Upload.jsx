import PageHeader from '@/components/ui/PageHeader';
import UploadPanel from '@/components/UploadPanel';
import { useSession } from '@/context/AudioContext';

export default function Upload() {
  const { audio } = useSession();
  return (
    <div className="mx-auto max-w-3xl">
      <PageHeader
        eyebrow="Step 1 · Audio"
        title={audio ? 'Your Session Audio' : 'Upload Audio'}
        subtitle={
          audio
            ? 'This file is shared by all three tasks. Replace it to analyse a different recording.'
            : 'Upload a WAV, MP3 or FLAC file. You only need to do this once per session.'
        }
      />
      <UploadPanel />
    </div>
  );
}
