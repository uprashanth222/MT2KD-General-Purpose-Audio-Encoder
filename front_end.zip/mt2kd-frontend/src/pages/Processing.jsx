import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, CircleAlert, RotateCcw, ServerCrash, LayoutGrid, CirclePause } from 'lucide-react';
import ProcessingScreen from '@/components/ProcessingScreen';
import Button from '@/components/ui/Button';
import EmptyState from '@/components/ui/EmptyState';
import { ModeBadge } from '@/components/StatusBadge';
import { useSession } from '@/context/AudioContext';
import { getTask } from '@/config/tasks';
import { config } from '@/config/appConfig';

function ErrorPanel({ job, task, onRetry, onBack }) {
  const interrupted = job.status === 'interrupted';
  const cancelled = job.status === 'cancelled';
  const Icon = job.isNetwork ? ServerCrash : interrupted || cancelled ? CirclePause : CircleAlert;
  const title = cancelled
    ? 'Analysis cancelled'
    : interrupted
      ? 'Analysis interrupted'
      : job.isNetwork
        ? 'Backend unavailable'
        : 'Analysis failed';

  return (
    <div className="mx-auto max-w-2xl">
      <div className="panel p-6 sm:p-8">
        <div className="flex items-start gap-4">
          <div
            className={`flex size-12 shrink-0 items-center justify-center rounded-xl ${cancelled || interrupted ? 'bg-warning/10 text-warning' : 'bg-danger/10 text-danger'}`}
          >
            <Icon className="size-6" />
          </div>
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <h1 className="text-xl font-semibold">{title}</h1>
              <ModeBadge mode={job.mode} size="sm" />
            </div>
            <p className="mt-1 text-sm text-muted">{task.title} · {job.audio?.name}</p>
          </div>
        </div>

        {job.error && (
          <div className="mt-6 rounded-xl border border-line bg-ink-900/60 p-4 font-mono text-[13px] leading-relaxed text-fg/90" role="alert">
            {job.errorStatus ? `HTTP ${job.errorStatus} · ` : ''}
            {job.error}
          </div>
        )}

        {job.isNetwork && (
          <ul className="mt-5 list-disc space-y-1.5 pl-5 text-sm text-muted">
            <li>
              Start the FastAPI server and confirm it is reachable at <span className="font-mono text-fg">{config.apiBaseUrl}</span>.
            </li>
            <li>Check that the backend enables CORS for this frontend&apos;s origin.</li>
            <li>Verify <span className="font-mono text-fg">VITE_API_BASE_URL</span> in your .env file, then retry.</li>
          </ul>
        )}
        <p className="mt-5 text-sm text-muted">No results were produced. Nothing has been fabricated or saved for this run.</p>

        <div className="mt-8 flex flex-wrap gap-2">
          <Button icon={RotateCcw} onClick={onRetry}>
            Retry
          </Button>
          <Button variant="secondary" icon={ArrowLeft} onClick={onBack}>
            Back to configuration
          </Button>
        </div>
      </div>
    </div>
  );
}

export default function Processing() {
  const navigate = useNavigate();
  const { currentJob, cancelAnalysis, startAnalysis, clearCurrentJob } = useSession();

  useEffect(() => {
    if (currentJob?.status === 'completed' && currentJob.resultId) {
      navigate(`/results/${encodeURIComponent(currentJob.resultId)}`, { replace: true });
    }
  }, [currentJob, navigate]);

  if (!currentJob || currentJob.status === 'completed') {
    return (
      <EmptyState
        icon={LayoutGrid}
        title="No analysis in progress"
        body="Choose a task to start analysing your session audio."
        action={<Button to="/tasks">Go to task selection</Button>}
      />
    );
  }

  const task = getTask(currentJob.task);
  const backTo = currentJob.task === 'speaker' ? '/speaker' : '/tasks';

  if (currentJob.status !== 'running') {
    return (
      <ErrorPanel
        job={currentJob}
        task={task}
        onBack={() => {
          clearCurrentJob();
          navigate(backTo);
        }}
        onRetry={() => {
          const res = startAnalysis({ task: currentJob.task });
          if (!res.ok) navigate(backTo);
        }}
      />
    );
  }

  return <ProcessingScreen job={currentJob} task={task} onCancel={cancelAnalysis} />;
}
