import { useCallback, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowUpRight, CircleAlert, FlaskConical, History as HistoryIcon, Monitor, RefreshCw, Server, Trash2 } from 'lucide-react';
import PageHeader from '@/components/ui/PageHeader';
import Button from '@/components/ui/Button';
import EmptyState, { LoadingBlock } from '@/components/ui/EmptyState';
import ConfirmDialog from '@/components/ui/ConfirmDialog';
import StatusBadge, { ModeBadge } from '@/components/StatusBadge';
import { useSession } from '@/context/AudioContext';
import { getTask } from '@/config/tasks';
import { getHistory, loadBackendRecord, normalizeHistoryItem } from '@/services/api';
import { formatDateTime, cn } from '@/utils/format';

function TaskChip({ taskId }) {
  const t = getTask(taskId);
  if (!t) return <span className="text-sm text-muted">Unknown task</span>;
  return (
    <span className="inline-flex items-center gap-2 text-sm">
      <span className="flex size-7 items-center justify-center rounded-lg" style={{ background: `rgb(${t.accentRgb} / 0.15)` }}>
        <t.icon className="size-3.5" style={{ color: t.accent }} />
      </span>
      {t.title}
    </span>
  );
}

function SourceTag({ record }) {
  if (record.isDemo) {
    return (
      <span className="inline-flex items-center gap-1 rounded-md border border-amber/30 bg-amber/10 px-1.5 py-0.5 font-mono text-[10px] uppercase tracking-wider text-amber">
        <FlaskConical className="size-3" /> Simulated
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1 rounded-md border border-success/30 bg-success/10 px-1.5 py-0.5 font-mono text-[10px] uppercase tracking-wider text-success">
      <Server className="size-3" /> {record.source === 'backend' ? 'From backend' : 'Live · cached'}
    </span>
  );
}

function Row({ id, taskId, audioName, createdAt, status, summary, tag, action }) {
  return (
    <li className="grid gap-3 px-5 py-4 transition-colors hover:bg-white/[0.02] md:grid-cols-[minmax(0,1.1fr)_minmax(0,1.3fr)_minmax(0,2fr)_auto] md:items-center" data-testid="history-row">
      <div className="min-w-0">
        <TaskChip taskId={taskId} />
        <div className="mt-1.5 truncate font-mono text-[11px] text-subtle" title={id}>
          {id}
        </div>
      </div>
      <div className="min-w-0">
        <div className="truncate text-sm" title={audioName}>
          {audioName || '—'}
        </div>
        <div className="mt-1 text-xs text-muted">{formatDateTime(createdAt)}</div>
      </div>
      <div className="min-w-0">
        <div className="flex flex-wrap items-center gap-2">
          <StatusBadge status={status} />
          {tag}
        </div>
        {summary && <div className="mt-1.5 truncate text-xs text-muted" title={summary}>{summary}</div>}
      </div>
      <div className="md:text-right">{action}</div>
    </li>
  );
}

function BackendHistory() {
  const navigate = useNavigate();
  const { history, importRecord } = useSession();
  const [state, setState] = useState({ status: 'loading', items: [], error: null });
  const [opening, setOpening] = useState(null);
  const [openError, setOpenError] = useState(null);

  const load = useCallback(async (signal) => {
    setState((s) => ({ ...s, status: 'loading', error: null }));
    try {
      const items = (await getHistory(signal)).map(normalizeHistoryItem);
      setState({ status: 'ready', items, error: null });
    } catch (err) {
      if (err?.isCancel) return;
      setState({ status: 'error', items: [], error: err.message });
    }
  }, []);

  useEffect(() => {
    const c = new AbortController();
    load(c.signal);
    return () => c.abort();
  }, [load]);

  const open = async (id) => {
    if (history.some((r) => r.id === id)) {
      navigate(`/results/${encodeURIComponent(id)}`);
      return;
    }
    setOpening(id);
    setOpenError(null);
    try {
      const record = await loadBackendRecord(id);
      importRecord(record);
      navigate(`/results/${encodeURIComponent(record.id)}`);
    } catch (err) {
      setOpenError(`${id}: ${err.message}`);
    } finally {
      setOpening(null);
    }
  };

  if (state.status === 'loading') return <LoadingBlock label="Loading history from the backend…" />;
  if (state.status === 'error') {
    return (
      <div className="panel p-6">
        <div className="flex items-start gap-3 text-sm">
          <CircleAlert className="mt-0.5 size-5 shrink-0 text-danger" />
          <div>
            <div className="font-medium">Could not load backend history</div>
            <p className="mt-1 text-muted">{state.error}</p>
          </div>
        </div>
        <Button variant="secondary" size="sm" icon={RefreshCw} className="mt-4" onClick={() => load()}>
          Retry
        </Button>
      </div>
    );
  }
  if (!state.items.length) {
    return <EmptyState icon={Server} title="No analyses stored on the backend yet" />;
  }
  return (
    <>
      {openError && (
        <div role="alert" className="mb-3 flex items-center gap-2 text-sm text-danger">
          <CircleAlert className="size-4" /> {openError}
        </div>
      )}
      <ul className="panel divide-y divide-white/[0.05] overflow-hidden">
        {state.items.map((it) => (
          <Row
            key={it.id}
            id={it.id}
            taskId={it.task}
            audioName={it.audioName}
            createdAt={it.createdAt}
            status={it.status}
            summary={it.summary}
            tag={
              <span className="inline-flex items-center gap-1 rounded-md border border-success/30 bg-success/10 px-1.5 py-0.5 font-mono text-[10px] uppercase tracking-wider text-success">
                <Server className="size-3" /> Backend
              </span>
            }
            action={
              <Button
                size="sm"
                variant="secondary"
                iconRight={opening === it.id ? undefined : ArrowUpRight}
                loading={opening === it.id}
                disabled={!['completed', 'complete', 'done', 'success', 'succeeded', 'finished'].includes(it.status)}
                onClick={() => open(it.id)}
              >
                View
              </Button>
            }
          />
        ))}
      </ul>
    </>
  );
}

export default function History() {
  const { history, clearHistory, isDemo, mode } = useSession();
  const [tab, setTab] = useState('local');
  const [confirm, setConfirm] = useState(false);

  const tabs = [
    { id: 'local', label: 'This browser', icon: Monitor, count: history.length },
    ...(!isDemo ? [{ id: 'backend', label: 'Backend', icon: Server }] : []),
  ];

  return (
    <div>
      <PageHeader
        eyebrow="Records"
        title="Analysis History"
        subtitle={
          isDemo
            ? 'Analyses run in Demo Mode are simulated and stored only in this browser.'
            : 'Results cached in this browser, plus analyses persisted by the backend.'
        }
        actions={
          <>
            <ModeBadge mode={mode} />
            {tab === 'local' && history.length > 0 && (
              <Button variant="danger" icon={Trash2} onClick={() => setConfirm(true)} data-testid="clear-history">
                Clear History
              </Button>
            )}
          </>
        }
      />

      {tabs.length > 1 && (
        <div role="tablist" className="mb-5 inline-flex rounded-xl border border-line bg-card/60 p-1">
          {tabs.map((t) => (
            <button
              key={t.id}
              role="tab"
              type="button"
              aria-selected={tab === t.id}
              onClick={() => setTab(t.id)}
              className={cn(
                'flex items-center gap-2 rounded-lg px-3.5 py-1.5 text-sm transition-colors',
                tab === t.id ? 'bg-white/[0.08] text-fg' : 'text-muted hover:text-fg',
              )}
            >
              <t.icon className="size-4" />
              {t.label}
              {t.count !== undefined && <span className="font-mono text-xs text-subtle">{t.count}</span>}
            </button>
          ))}
        </div>
      )}

      {tab === 'backend' ? (
        <BackendHistory />
      ) : history.length === 0 ? (
        <EmptyState
          icon={HistoryIcon}
          title="No analyses yet"
          body="Results you generate in this browser will appear here so you can revisit them."
          action={<Button to="/tasks">Run an analysis</Button>}
        />
      ) : (
        <>
          <p className="mb-3 flex items-center gap-2 text-xs text-subtle">
            <Monitor className="size-3.5" /> Stored locally in this browser ({history.length}). Records are kept until you clear them.
          </p>
          <ul className="panel divide-y divide-white/[0.05] overflow-hidden">
            {history.map((r) => (
              <Row
                key={r.id}
                id={r.id}
                taskId={r.task}
                audioName={r.audio?.name}
                createdAt={r.createdAt}
                status={r.status}
                summary={r.summary}
                tag={<SourceTag record={r} />}
                action={
                  <Button size="sm" variant="secondary" iconRight={ArrowUpRight} to={`/results/${encodeURIComponent(r.id)}`}>
                    View
                  </Button>
                }
              />
            ))}
          </ul>
        </>
      )}

      <ConfirmDialog
        open={confirm}
        title="Clear analysis history?"
        message={`This permanently removes ${history.length} record${history.length === 1 ? '' : 's'} stored in this browser.${
          isDemo ? '' : ' Records stored on the backend are not affected.'
        }`}
        confirmLabel="Clear history"
        onCancel={() => setConfirm(false)}
        onConfirm={() => {
          clearHistory();
          setConfirm(false);
        }}
      />
    </div>
  );
}
