import { ArrowRight, BookMarked, Boxes, CodeXml, Target, Workflow } from 'lucide-react';
import PageHeader from '@/components/ui/PageHeader';
import Button from '@/components/ui/Button';
import { PROJECT } from '@/config/modelInfo';
import { TASK_LIST } from '@/config/tasks';

const OBJECTIVES = [
  'Build one compact audio encoder that performs ASR, audio tagging and speaker verification.',
  'Transfer knowledge from three specialist teachers through multi-teacher knowledge distillation.',
  'Keep performance close to single-task models while sharing parameters and computation.',
  'Deliver the capabilities through a web application with honest, verifiable outputs.',
];

const WORKFLOW = ['Upload audio', 'Select task', 'Configure', 'Process', 'View results', 'Switch task'];

const STACK = [
  { group: 'Frontend', items: ['React + Vite', 'Tailwind CSS', 'Framer Motion', 'WaveSurfer.js', 'Recharts', 'React Router', 'Axios'] },
  { group: 'Backend (planned)', items: ['Python', 'FastAPI', 'PyTorch', 'Torchaudio', 'Librosa', 'NumPy', 'SoundFile'] },
];

export default function About() {
  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="About project"
        title="MT2KD – Multi-Task Audio Intelligence Platform"
        subtitle="A research project exploring multi-teacher knowledge distillation to build a single general-purpose encoder for speech, speaker and audio-event understanding."
      />

      <div className="grid gap-5 md:grid-cols-3">
        {TASK_LIST.map((t) => (
          <div key={t.id} className="panel p-6">
            <div className="flex size-11 items-center justify-center rounded-xl" style={{ background: `rgb(${t.accentRgb} / 0.15)` }}>
              <t.icon className="size-5" style={{ color: t.accent }} />
            </div>
            <h3 className="mt-4 font-semibold">{t.title}</h3>
            <p className="mt-2 text-sm leading-relaxed text-muted">{t.description}</p>
          </div>
        ))}
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        <section className="panel p-6">
          <h2 className="flex items-center gap-2 font-semibold">
            <Target className="size-4 text-primary-soft" /> Objectives
          </h2>
          <ul className="mt-4 space-y-3">
            {OBJECTIVES.map((o, i) => (
              <li key={o} className="flex gap-3 text-sm leading-relaxed">
                <span className="font-mono text-xs text-subtle">0{i + 1}</span>
                <span className="text-fg/90">{o}</span>
              </li>
            ))}
          </ul>
        </section>

        <section className="panel p-6">
          <h2 className="flex items-center gap-2 font-semibold">
            <Workflow className="size-4 text-accent" /> Application workflow
          </h2>
          <ol className="mt-5 flex flex-wrap items-center gap-2">
            {WORKFLOW.map((w, i) => (
              <li key={w} className="flex items-center gap-2">
                <span className="rounded-lg border border-line bg-ink-900/70 px-3 py-1.5 text-sm">{w}</span>
                {i < WORKFLOW.length - 1 && <ArrowRight className="size-3.5 text-subtle" />}
              </li>
            ))}
          </ol>
          <p className="mt-5 text-sm leading-relaxed text-muted">
            Audio is uploaded once per session and reused by every task, so you can compare all three capabilities on the same
            recording.
          </p>
        </section>
      </div>

      <section className="panel p-6">
        <h2 className="flex items-center gap-2 font-semibold">
          <CodeXml className="size-4 text-amber" /> Technology
        </h2>
        <div className="mt-4 grid gap-6 md:grid-cols-2">
          {STACK.map((s) => (
            <div key={s.group}>
              <div className="eyebrow mb-3">{s.group}</div>
              <div className="flex flex-wrap gap-2">
                {s.items.map((i) => (
                  <span key={i} className="rounded-lg border border-line bg-white/[0.03] px-2.5 py-1 text-sm text-fg/90">
                    {i}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="panel p-6">
        <h2 className="flex items-center gap-2 font-semibold">
          <BookMarked className="size-4 text-primary-soft" /> Base paper
        </h2>
        <p className="mt-3 text-sm font-medium leading-relaxed">{PROJECT.paper.title}</p>
        <p className="mt-1 text-sm text-muted">{PROJECT.paper.authors}</p>
        <p className="mt-1 text-sm text-muted">{PROJECT.paper.venue}</p>
        <p className="mt-1 font-mono text-xs text-subtle">DOI {PROJECT.paper.doi}</p>
        <div className="mt-5 flex flex-wrap gap-2">
          <Button to="/models" variant="secondary" icon={Boxes}>
            Model architecture
          </Button>
          <Button to="/docs" variant="ghost">
            Documentation
          </Button>
        </div>
      </section>
    </div>
  );
}
