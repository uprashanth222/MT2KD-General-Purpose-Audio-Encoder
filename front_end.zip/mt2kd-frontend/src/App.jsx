import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { MapPinOff } from 'lucide-react';
import { AudioProvider } from '@/context/AudioContext';
import AppLayout from '@/components/layout/AppLayout';
import EmptyState from '@/components/ui/EmptyState';
import Button from '@/components/ui/Button';
import Landing from '@/pages/Landing';
import Upload from '@/pages/Upload';
import TaskSelection from '@/pages/TaskSelection';
import SpeakerVerification from '@/pages/SpeakerVerification';
import Processing from '@/pages/Processing';
import Results from '@/pages/Results';
import History from '@/pages/History';
import ModelInfo from '@/pages/ModelInfo';
import About from '@/pages/About';
import Docs from '@/pages/Docs';

function NotFound() {
  return (
    <EmptyState
      icon={MapPinOff}
      title="Page not found"
      body="The page you were looking for does not exist."
      action={<Button to="/">Back to home</Button>}
    />
  );
}

export default function App() {
  return (
    <AudioProvider>
      <BrowserRouter>
        <Routes>
          <Route element={<AppLayout />}>
            <Route index element={<Landing />} />
            <Route path="upload" element={<Upload />} />
            <Route path="tasks" element={<TaskSelection />} />
            <Route path="speaker" element={<SpeakerVerification />} />
            <Route path="processing" element={<Processing />} />
            <Route path="results/:analysisId" element={<Results />} />
            <Route path="history" element={<History />} />
            <Route path="models" element={<ModelInfo />} />
            <Route path="about" element={<About />} />
            <Route path="docs" element={<Docs />} />
            <Route path="*" element={<NotFound />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </AudioProvider>
  );
}
