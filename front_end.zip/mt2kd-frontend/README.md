# MT2KD – Multi-Task Audio Intelligence Platform (Frontend)

React + Vite frontend for **MT2KD (Multi-Task Knowledge Distillation)**: one audio upload, three capabilities:

- **Speech Recognition (ASR)**
- **Audio Tagging (AT)**
- **Speaker Verification (SV)**, with two modes: reference + test audio, or a pre-registered speaker

The app runs in two modes:

- **Demo Mode** (the default) works entirely in the browser and clearly labels every result as sample data.
- **Live Mode** talks to the FastAPI backend and never fabricates results.

---

## 1. Requirements

- Node.js **20.19+ or 22.12+** (required by Vite 7)
- npm 10+

## 2. Installation

```bash
cd mt2kd-frontend
npm install
cp .env.example .env        # optional – defaults to Demo Mode
```

## 3. Running

| Command | What it does |
|---|---|
| `npm run dev` | Dev server on http://localhost:5173, in Demo Mode unless `.env` says otherwise |
| `npm run dev:live` | Dev server in **Live Mode** (uses `VITE_API_BASE_URL`, default `http://localhost:8000`) |
| `npm run build` | Production build into `dist/` |
| `npm run preview` | Serve the production build locally |

To use Live Mode permanently, set `VITE_APP_MODE=live` in `.env`.

> When deploying `dist/` behind a static host, configure an SPA fallback that serves `index.html` for unknown paths, because routes such as `/tasks` and `/results/:id` are client-side.

## 4. Configuration (`.env`)

| Variable | Default | Purpose |
|---|---|---|
| `VITE_APP_MODE` | `demo` | `demo` or `live` |
| `VITE_API_BASE_URL` | `http://localhost:8000` | FastAPI base URL |
| `VITE_MAX_FILE_SIZE_MB` | `50` | Upload size limit |
| `VITE_API_TIMEOUT_MS` | `120000` | Axios request timeout |
| `VITE_POLL_INTERVAL_MS` | `1500` | Job polling interval (Live Mode) |
| `VITE_POLL_TIMEOUT_MS` | `600000` | Give up polling after this long |
| `VITE_DEMO_STAGE_DELAY_MS` | `900` | Delay per simulated stage (Demo Mode) |
| `VITE_DEMO_SV_THRESHOLD` | `0.5` | Threshold used by the demo speaker decision |

## 5. Folder structure

```
mt2kd-frontend/
├── index.html
├── package.json
├── vite.config.js
├── .env.example
├── public/favicon.svg
└── src/
    ├── main.jsx                  # entry, StrictMode
    ├── App.jsx                   # routes
    ├── index.css                 # Tailwind v4 + design tokens (@theme)
    ├── config/
    │   ├── appConfig.js          # env → runtime config, mode flags
    │   ├── tasks.js              # task registry: copy, icons, accents, stages
    │   └── modelInfo.js          # architecture facts (no metrics)
    ├── context/
    │   └── AudioContext.jsx      # global session state + analysis runner
    ├── services/
    │   ├── audioService.js       # validation, metadata, IndexedDB temp persistence
    │   ├── demoService.js        # DEMO ONLY – simulated stages + labelled sample data
    │   └── api.js                # LIVE ONLY – Axios client, normalisers, job polling
    ├── hooks/
    │   └── useBackendHealth.js   # GET /api/health (Live Mode only)
    ├── utils/                    # format, download/CSV/clipboard, ids
    ├── components/
    │   ├── layout/AppLayout.jsx  # navbar before entry, sidebar + bottom nav after
    │   ├── Navbar.jsx  Sidebar.jsx  MobileNav.jsx  Logo.jsx
    │   ├── AudioUploader.jsx     # drag & drop + validation errors
    │   ├── AudioPlayer.jsx       # file card: metadata, waveform, replace/remove (+ AudioSlot)
    │   ├── Waveform.jsx          # WaveSurfer.js waveform + transport
    │   ├── UploadPanel.jsx  SessionAudioBar.jsx
    │   ├── TaskCard.jsx  ProcessingScreen.jsx  ResultCard.jsx  StatusBadge.jsx
    │   ├── ArchitectureDiagram.jsx  AnimatedWave.jsx
    │   ├── results/              # AsrResults, TaggingResults, SpeakerResults
    │   └── ui/                   # Button, ConfirmDialog, PageHeader, EmptyState
    └── pages/
        Landing, Upload, TaskSelection, SpeakerVerification, Processing,
        Results, History, ModelInfo, About, Docs
```

## 6. How it works

**Upload once.** The file is validated by extension, MIME type, size, magic bytes (RIFF/WAVE, fLaC, ID3 or MPEG sync) and a successful browser decode. The player uses a local `URL.createObjectURL()` URL. All three tasks reuse the same file, and object URLs are revoked when a file is replaced, removed or the session is cleared.

**Session persistence.**
- Workflow state (selections, metadata, current job) is kept in `sessionStorage`.
- A temporary copy of each audio blob is kept in IndexedDB for the current tab session (files up to 60 MB). This lets a refresh restore the playable file.
- If the blob is missing, the UI keeps the metadata and asks the user to re-select the file. It never pretends the file is still there.
- An analysis that is running during a refresh is shown as *interrupted*.
- History is stored in `localStorage`, separately for Demo and Live.

**Processing.** The runner lives in the context, not in a page, so navigating away doesn't break it.
- In **Demo Mode**, the stages are simulated with configurable delays and the screen shows a DEMO badge.
- In **Live Mode**, the screen shows real upload progress, then the backend's reported `stage` or `stage_index`. If the backend reports no stage, it shows an honest indeterminate indicator, never a fake percentage.

**Results.**
- **ASR:** Copy, TXT and JSON export.
- **Tagging:** top-K chart (Recharts), expandable full list, JSON and CSV export.
- **SV:** MATCH / NON-MATCH card, similarity scale with threshold, and JSON export.

Every result can be revisited from **Analysis History**.

## 7. Expected backend API contract (Live Mode)

All paths are relative to `VITE_API_BASE_URL`. Errors should use FastAPI's `{"detail": ...}` format, which is shown to the user verbatim. CORS must allow the frontend origin.

| Method | Endpoint | Request | Response |
|---|---|---|---|
| POST | `/api/audio/upload` | multipart `file` | `{ audio_id }` |
| POST | `/api/asr/process` | `{ audio_id, decoding_method }` | result, or `{ job_id, status }` |
| POST | `/api/tagging/process` | `{ audio_id, top_k }` | result, or `{ job_id, status }` |
| POST | `/api/speaker/verify` | `{ mode: "pair", test_audio_id, reference_audio_id }` or `{ mode: "registered", test_audio_id, speaker_id }` | result, or `{ job_id, status }` |
| GET | `/api/speaker/registered` | – | `[{ speaker_id, name, num_utterances, reference_available }]` |
| GET | `/api/analysis/{id}` | – | `{ analysis_id, task, status, stage?, stage_index?, result?, error?, processing_time_ms? }` |
| GET | `/api/analysis/history` | – | `[{ analysis_id, task, status, created_at, filename, summary? }]` |
| GET | `/api/models/status` | – | any object (displayed as reported) |
| GET | `/api/models/info` | – | any object (displayed as reported) |
| GET | `/api/health` | – | 200 when up |

**Status values.**
- `status ∈ {queued, running, completed, failed}`.
- If a process endpoint returns a `job_id` with a non-terminal status, the frontend polls `/api/analysis/{id}`.

**Result payloads.**

```jsonc
// ASR
{ "transcription": "…", "decoding_method": "greedy_search", "model": { "name": "…", "version": "…" }, "processing_time_ms": 412 }
// Tagging
{ "predictions": [{ "label": "Speech", "score": 0.91 }], "top_k": 10 }
// Speaker verification – the decision MUST come from the backend
{ "similarity": 0.71, "threshold": 0.45, "decision": "match", "metric": "cosine" }
```

If a required field is missing, the frontend shows an error rather than inventing a value.

## 8. Pending backend integrations

1. Implement all endpoints in §7 with FastAPI, including CORS for the frontend origin.
2. `GET /api/speaker/registered` is **not in the original endpoint list**. The frontend needs it to list registered speakers in Live Mode, so add it, or tell me the real endpoint and I'll adapt `api.js`.
3. Audio decoding / resampling on the backend. Browsers send the original WAV/MP3/FLAC bytes; the models expect 16 kHz mono filterbank features.
4. Connect the inference endpoints to the trained Zipformer-M student checkpoint and its three heads.
5. Return a calibrated SV `threshold` and `decision`.
6. Optional: report `stage` / `stage_index` while jobs run, so Live Mode can show step-by-step progress.
7. Persist analyses so `/api/analysis/history` and `/api/analysis/{id}` work across sessions.
8. Expose real model/checkpoint details in `/api/models/info` and evaluation metrics once they exist. The UI deliberately shows no metrics until then.

Once the real API contract is fixed, adjust the field names in the normalisers in `src/services/api.js` (`normalizeAsr`, `normalizeTagging`, `normalizeSpeaker`, `normalizeHistoryItem`). Nothing else needs to change.

## 9. Notes

- Demo Mode makes **no** network requests to the backend.
- The demo speaker-verification decision is deterministic sample data derived from file names and sizes, labelled as such everywhere it appears.
- Fonts are loaded from Google Fonts: Sora, Inter and JetBrains Mono.
